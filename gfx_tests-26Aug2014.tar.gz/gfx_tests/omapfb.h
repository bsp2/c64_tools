/* ----
 * ---- file   : omapfb.h
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          Distributed under terms of the LESSER GNU GENERAL PUBLIC LICENSE (LGPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#LGPL or COPYING_LGPL for further information.
 * ----
 * ---- info   : This is part of the "c64_tools" package.
 * ----
 * ---- changed: 22Sep2013, 24Oct2013, 10Nov2013
 * ----
 * ----
 */

#ifndef __OMAPFB_UTILS_H__
#define __OMAPFB_UTILS_H__


#define OMAPFB_GFX   (0u)
#define OMAPFB_VID1  (1u)
#define OMAPFB_VID2  (2u)


/* (note) def. is 1 (VID1) */
S_EXTERN void omapfb_set_default_plane_idx(sUI _planeIdx);

S_EXTERN sBool omapfb_init (sUI _px, sUI _py,
                            sUI _w, sUI _h,
                            sUI _zoomedW, sUI _zoomedH,
                            sUI _vw,  sUI _vh,
                            sUI _bitsPerPixel,
                            sBool _bDisableDesktopLayer
                            );

S_EXTERN void omapfb_exit (void);

S_EXTERN sBool omapfb_plane_enable (sUI _planeIdx, sBool _bEnabled);

S_EXTERN sBool omapfb_plane_setup (sUI _planeIdx,
                                   sUI _px, sUI _py,
                                   sUI _w,  sUI _h,
                                   sUI _zoomedW, sUI _zoomedH,
                                   sUI _vw, sUI _vh,
                                   sUI _bitsPerPixel
                                   );

S_EXTERN dsp_mem_region_t omapfb_plane_get_dsp_mem (sUI _planeIdx);

S_EXTERN void omapfb_vsync (void);

S_EXTERN sBool omapfb_plane_offset (sUI _planeIdx, sU32 _offsetX, sU32 _offsetY);

S_EXTERN sBool omapfb_color_key_set(sU32 _colorKey, sBool _bVidSrc);


#endif /* __OMAPFB_UTILS_H__ */
