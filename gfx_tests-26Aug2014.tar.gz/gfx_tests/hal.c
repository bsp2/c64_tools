/* ----
 * ---- file   : hal.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          Distributed under terms of the LESSER GNU GENERAL PUBLIC LICENSE (LGPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#LGPL or COPYING_LGPL for further information.
 * ----
 * ---- info   : HAL main API. This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 28Oct2013, 10Nov2013, 11Nov2013, 20Nov2013
 * ----
 * ----
 */

#include "../include/types.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/fb.h>
#include <linux/omapfb.h>
#include <linux/ioctl.h>

#include <X11/Xlib.h>

#include <SDL/SDL.h>
#include <SDL/SDL_keysym.h>
#include <SDL/SDL_joystick.h>
#include <SDL/SDL_syswm.h>

#include "../include/log.h"

#include "hal.h"



/*--------------------------------------------------------------------------- module vars */
static sUI hal_init_flags = 0;

static SDL_Surface *sdl_surf_screen;

static int fd_fb0 = -1;

static int           nub0_joyidx;
static SDL_Joystick *nub0_joyhandle;

static int           nub1_joyidx;
static SDL_Joystick *nub1_joyhandle;

static sBool b_hal_running;

hal_event_key_fxn_t hal_event_key_fxn = NULL;


/*--------------------------------------------------------------------------- hal_event_process() */
void hal_event_process(void) {

   SDL_Event ev;
   int r;

   for(;;)
   {
      r = SDL_PollEvent(&ev);

      if(r)
      {
         sBool bPressed = S_FALSE;
         printf("[dbg] hal_event_process: ev.type=%d\n", ev.type);

         switch(ev.type)
         {
            case SDL_JOYBUTTONUP:
            case SDL_JOYBUTTONDOWN:
               printf("[dbg] hal_event_process: joybutton up/down, which=%d button=%d pressed=%d\n",
                      ev.jbutton.which,
                      ev.jbutton.button,
                      (SDL_PRESSED == ev.jbutton.state)
                      );

               break;

            case SDL_JOYAXISMOTION:
               printf("xxx joyaxismotion\n");
               break;

            case SDL_KEYDOWN:
               bPressed = S_TRUE;

            case SDL_KEYUP:
               printf("xxx key\n");

               if(NULL != hal_event_key_fxn)
               { 
                  hal_event_key_fxn(((sU32)ev.key.keysym.sym) >> 16, ev.key.keysym.mod, bPressed);
               }
               break;

            case SDL_MOUSEMOTION:
               printf("xxx mousemotion\n");
               break;
         }
      }
      else
      {
         break;
      }
   }
}


/*--------------------------------------------------------------------------- hal_video_flip() */
void hal_video_flip(void) {
   SDL_Flip(sdl_surf_screen);
   
   ioctl(fd_fb0, OMAPFB_WAITFORVSYNC);
}


/*--------------------------------------------------------------------------- hal_nub_init() */
int hal_nub_init(void) {
   /* Init joysticks */
   int ret;
   int joyIdx;
   int numJoy = SDL_NumJoysticks();

   printf("[dbg] hal_nub_init: numJoysticks=%d\n", numJoy);

   nub0_joyidx    = -1;
   nub0_joyhandle = NULL;
   nub1_joyidx    = -1;
   nub1_joyhandle = NULL;
   
   for(joyIdx=0; joyIdx < numJoy; joyIdx++)
   {
      const char *joyName = SDL_JoystickName(joyIdx);

      printf("[dbg] hal_nub_init: joy[%d] name=\"%s\".\n", joyIdx, joyName);

      if(!strcmp(joyName, "nub0"))
      {
         nub0_joyidx    = joyIdx;
         nub0_joyhandle = SDL_JoystickOpen(joyIdx);
      }
      else if(!strcmp(joyName, "nub1"))
      {
         nub1_joyidx    = joyIdx;
         nub1_joyhandle = SDL_JoystickOpen(joyIdx);
      }
   }

   ret = ((-1 != nub0_joyidx) && (-1 != nub1_joyidx)) ? 0 : 10;

   return ret;
}


/*--------------------------------------------------------------------------- hal_nub_exit() */
void hal_nub_exit(void) {

   if(NULL != nub0_joyhandle)
   {
      SDL_JoystickClose(nub0_joyhandle);
   }

   if(NULL != nub1_joyhandle)
   {
      SDL_JoystickClose(nub1_joyhandle);
   }
   
}


/*--------------------------------------------------------------------------- hal_video_window_move() */
void hal_video_window_move(sUI _x, sUI _y) {
   SDL_SysWMinfo wminfo;
   Window root;
   Window parent;
   Window *children;
   sUI numChildren;
   
   SDL_VERSION(&wminfo.version);
   
   if(SDL_GetWMInfo(&wminfo) > 0)
   {
      if(SDL_SYSWM_X11 == wminfo.subsystem)
      {
         XQueryTree(wminfo.info.x11.display,
                    wminfo.info.x11.window,
                    &root,
                    &parent,
                    &children,
                    &numChildren
                    );
         
         wminfo.info.x11.lock_func();
         
         XMoveWindow(wminfo.info.x11.display,
                     parent,
                     _x, _y
                     );
         
         wminfo.info.x11.unlock_func();
         
         if(NULL != children)
         {
            XFree(children);
         }
      }
      else
      {
         log_printf(LOG_WARN "hal_video_window_move: not using X11 SDL syswm\n");
      }
   }
   else
   {
      log_printf(LOG_ERROR "hal_video_window_move: SDL_GetWMInfo() failed.\n");
   }
}


/*--------------------------------------------------------------------------- hal_video_init() */
int hal_video_init(sUI _sdlWinW, sUI _sdlWinH) {
   int ret;

   fd_fb0 = open("/dev/fb0", O_RDWR);

   if(-1 != fd_fb0)
   {

#if 0
      setenv("SDL_VIDEODRIVER",     "omapdss", 1);  // select notaz' Pandora SDL driver
      setenv("SDL_OMAP_VSYNC",      "1", 1);
#endif
      
      ret = SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK);// | SDL_INIT_NOPARACHUTE);
      
      if(ret >= 0)
      {
         ret = 0;
         
         //sdl_surf_screen = SDL_SetVideoMode(800, 480, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
         //sdl_surf_screen = SDL_SetVideoMode(800, 480, 32, SDL_HWSURFACE);
         sdl_surf_screen = SDL_SetVideoMode(_sdlWinW, _sdlWinH, 16, SDL_SWSURFACE | SDL_NOFRAME);
         //sdl_surf_screen = SDL_SetVideoMode(800, 480, 32, 0);
         
         if(NULL != sdl_surf_screen)
         {
            log_printf(LOG_INFO "hal_video_init: SDL_SetVideoMode() ok. w=%d h=%d pixels=0x%p pitch=%u\n",
                   sdl_surf_screen->w,
                   sdl_surf_screen->h,
                   sdl_surf_screen->pixels,
                   sdl_surf_screen->pitch
                   );

            /* Move window to top/left screen corner */
            hal_video_window_move(0, 0);
         }
         else
         {
            log_printf(LOG_ERROR "hal_video_init: SDL_SetVideoMode() failed.\n");

            SDL_Quit();

            printf("xxx after SDL_quit\n");
            
            ret = 10;
         }
      }
      else
      {
         log_printf(LOG_ERROR "hal_video_init: SDL_Init() failed.\n");
         
         close(fd_fb0);
         fd_fb0 = -1;

         ret = 20;
      }
      
   }
   else
   {
      /* Failed: open /dev/fb0 */
      ret = 30;
   }

   return ret;
}


/*--------------------------------------------------------------------------- hal_video_exit() */
void hal_video_exit(void) {
   printf("ok, calling SDL_Quit()\n");

   SDL_Quit();

   close(fd_fb0);
   fd_fb0 = -1;
}


/*--------------------------------------------------------------------------- hal_init() */
int hal_init(sUI _halInitFlags, sUI _sdlWinW, sUI _sdlWinH) {
   int ret;

   hal_init_flags = _halInitFlags;

   ret = hal_video_init(_sdlWinW, _sdlWinH);

   if(0 == ret)
   {
      if(0 != (_halInitFlags & HAL_INIT_NUBS))
      {
         ret = hal_nub_init();
      }

      if(0 == ret)
      {
         /* Succeeded */
      }
      else
      {
         printf("[---] hal_nub_init() failed.\n");

         hal_video_exit();
      }
   }
   else
   {
      printf("[---] hal_video_init() failed.\n");
   }

   b_hal_running = S_TRUE;

   return ret;
}


/*--------------------------------------------------------------------------- hal_running() */
sBool hal_running(void) {
   return b_hal_running;
}


/*--------------------------------------------------------------------------- hal_stop() */
void hal_stop(void) {
   b_hal_running = S_FALSE;
}


/*--------------------------------------------------------------------------- hal_exit() */
void hal_exit(void) {

   if(0 != (hal_init_flags & HAL_INIT_NUBS))
   {
      hal_nub_exit();
   }

   hal_video_exit();
}
