/* ----
 * ---- file   : demo_fractal.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel.
 * ----          Distributed under terms of the MIT LICENSE (MIT).
 * ----
 * ---- Permission is hereby granted, free of charge, to any person obtaining a copy
 * ---- of this software and associated documentation files (the "Software"), to deal
 * ---- in the Software without restriction, including without limitation the rights
 * ---- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * ---- copies of the Software, and to permit persons to whom the Software is
 * ---- furnished to do so, subject to the following conditions:
 * ----
 * ---- The above copyright notice and this permission notice shall be included in
 * ---- all copies or substantial portions of the Software.
 * ----
 * ---- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * ---- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * ---- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * ---- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * ---- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * ---- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * ---- THE SOFTWARE.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 21Sep2013, 22Sep2013, 25Sep2013, 02Oct2013, 03Oct2013, 20Oct2013
 * ----
 * ----
 */

// If defined, render blue fractal. Otherwise a red one.
#define BLUE defined

//#define USE_FASTRTS_I defined

//#define USE_FASTRTS_62X64X defined

#define USE_IQMATH defined
#define USE_IQMATH_INLINE defined


#define SYSCALLS_C defined
#include <libc64_dsp/include/inc_overlay.h>

//#include <stdio.h>
//#include <std.h>
//#include <mem.h>

#include "demo_fractal.h"


#ifdef USE_FASTRTS_I
#include <fastrts_i.h>
#endif /* USE_FASTRTS_I */

#ifdef USE_FASTRTS_62X64X
#include <fastrts62x64x.h>
//"C:\ti\fastRTS_c62xc64x_1_42\c6400\mthlib\lib\fastrts64x.lib"
#endif /* USE_FASTRTS_62X64X */

#ifdef USE_IQMATH
#define GLOBAL_Q 16
#define MATH_TYPE  (IQ_MATH)
#ifdef USE_IQMATH_INLINE
#define _INLINE_IQMATH defined
#include <IQmath_inline.h>
#else
#include <IQmath.h>
#endif /* USE_IQMATH_INLINE */
#endif /* USE_IQMATH */


#ifndef _IQadd
#define _IQadd(a, b)  ((a) + (b))
#endif

#ifndef _IQsub
#define _IQsub(a, b)  ((a) - (b))
#endif


/* --------------------------------------------------------------------------- loc_process() */
static void loc_process(const demo_fractal_args_t *_args) {

   /* Invalidate DSP caches for the args memory area */
   syscalls.cache_inv((void*)_args, sizeof(demo_fractal_args_t), S_TRUE);

#ifdef USE_IQMATH
   /* */
   {
      _iq xx;
      _iq yy;
      _iq c1 = _IQ(_args->c1);
      _iq c2 = _IQ(_args->c2);
      _iq iq_start_x = _IQ((float)_args->start_x);
      _iq iq_start_y = _IQ((float)_args->start_y);
      _iq s_xx = _IQdiv(_IQ(1.0f), _IQ( ((float)(128 >> 2)) ) );  // 1.0f / ((float)(128 >> 2));
      _iq s_yy = _IQdiv(_IQ(1.0f), _IQ( ((float)(128 >> 2)) ) );  // 1.0f / ((float)(128 >> 2));
      _iq c_yy = _IQadd(_IQ(-1.8f), _IQmpy(s_yy, iq_start_y));
      sUI ly = _args->start_y;
      sUI iter;
      sUI di = 0;
      sUI cx;
      sUI cy;
      sU32 *d = _args->framebuffer.data;
      sU32 itd = _args->iter_depth;

      for(cy=0; cy<_args->framebuffer.h; cy++)
      {
         _iq c_xx = _IQadd(_IQ(-2.0f), _IQmpy(iq_start_x, s_xx));

         for(cx=0; cx<_args->framebuffer.w; cx++)
         {
            _iq qxx, qyy, qxxyy;

            qxx   = _IQmpy(c_xx, c_xx);
            qyy   = _IQmpy(c_yy, c_yy);
            xx    = c_xx;
            yy    = c_yy;
            qxxyy = _IQadd(qxx, qyy);

            for(iter=0; (iter < itd) && (qxxyy <= _IQ(4.0f)) ; iter++)
            {
               yy    = _IQadd(_IQmpy(_IQ(2.0f), _IQmpy(xx, yy)), c2);
               xx    = _IQadd(_IQsub(qxx, qyy), c1);
               qxx   = _IQmpy(xx, xx);
               qyy   = _IQmpy(yy, yy);
               qxxyy = _IQadd(qxx, qyy);
            }

            {
               sU32 c8;
               sU32 c32;

               c8 = (iter << 3);

               c32 = (ly + (c8 << 1));

               if(c32 > 255)
               {
                  c32 = 255;
               }

#ifdef BLUE
               c32 = (255u << 24) | (c8 << 16) | (c8 << 8) | c32;
#else
               c32 = (255u << 24) | (c32 << 16) | (c8 << 8) | c8;
#endif /* BLUE */

               d[di++] = c32;
            }

            c_xx = _IQadd(c_xx, s_xx);
         } /* loopy x */

         c_yy = _IQadd(c_yy, s_yy);
         ly++;

         di += (_args->framebuffer.pitch >> 2) - _args->framebuffer.w;

      } /* loop y */

   }
#endif

#if USE_FASTRTS_62X64X
   /* good, ~3.1 times slower than Cortex A8 hardware GPU (on DM3730 / Open Pandora) */
   {
      float xx;
      float yy;
      float c1 = _args->c1;
      float c2 = _args->c2;
      float s_xx = divsp(1.0f, ((float)(128 >> 2)));  // 1.0f / ((float)(128 >> 2));
      float s_yy = divsp(1.0f, ((float)(128 >> 2)));  // 1.0f / ((float)(128 >> 2));
      float c_yy = addsp(-1.8f, mpysp(s_yy, (float)_args->start_y));
      sUI ly = _args->start_y;
      sUI iter;
      sUI di = 0;
      sUI cx;
      sUI cy;
      sU32 *d = _args->framebuffer.data;
      sU32 itd = _args->iter_depth;

      for(cy=0; cy<_args->framebuffer.h; cy++)
      {
         float c_xx = addsp(-2.0f, mpysp((float)_args->start_x, s_xx));

         for(cx=0; cx<_args->framebuffer.w; cx++)
         {
            float qxx, qyy, qxxyy;

            qxx   = mpysp(c_xx, c_xx);
            qyy   = mpysp(c_yy, c_yy);
            xx    = c_xx;
            yy    = c_yy;
            qxxyy = addsp(qxx, qyy);

            for(iter=0; (iter < itd) && (qxxyy <= 4.0f) ; iter++)
            {
               yy    = addsp(mpysp(2.0f, mpysp(xx, yy)), c2);
               xx    = addsp(subsp(qxx, qyy), c1);
               qxx   = mpysp(xx, xx);
               qyy   = mpysp(yy, yy);
               qxxyy = addsp(qxx, qyy);
            }

            {
               sU32 c8;
               sU32 c32;

               c8 = (iter << 3);

               c32 = (ly + (c8 << 1));

               if(c32 > 255)
               {
                  c32 = 255;
               }

               c32 = (255u << 24) | (c8 << 16) | (c8 << 8) | c32;

               d[di++] = c32;
            }

            c_xx = addsp(c_xx, s_xx);
         } /* loopy x */

         c_yy = addsp(c_yy, s_yy);
         ly++;

         di += (_args->framebuffer.pitch >> 2) - _args->framebuffer.w;

      } /* loop y */

   }
#endif /* USE_FASTRTS_62X64X */

#ifdef USE_STD_FLOATEMU
   /* ~8 times slower than Cortex A8 hardware FPU */
   {
      float xx;
      float yy;
      float c1 = _args->c1;
      float c2 = _args->c2;
      float s_xx = 1.0f / ((float)(128 >> 2));
      float s_yy = 1.0f / ((float)(128 >> 2));
      float c_yy = -1.8f + s_yy * _args->start_y;
      sUI ly = _args->start_y;
      sUI iter;
      sUI di = 0;
      sUI cx;
      sUI cy;
      sU32 *d = _args->framebuffer.data;
      sU32 itd = _args->iter_depth;

      for(cy=0; cy<_args->framebuffer.h; cy++)
      {
         float c_xx = -2.0f + _args->start_x * s_xx;

         for(cx=0; cx<_args->framebuffer.w; cx++)
         {
            float qxx, qyy, qxxyy;

            qxx   = c_xx * c_xx;
            qyy   = c_yy * c_yy;
            xx    = c_xx;
            yy    = c_yy;
            qxxyy = qxx + qyy;

            for(iter=0; (iter < itd) && (qxxyy <= 4.0f) ; iter++)
            {
               yy    = 2.0f * xx * yy + c2;
               xx    = qxx - qyy + c1;
               qxx   = xx * xx;
               qyy   = yy * yy;
               qxxyy = qxx + qyy;
            }

            {
               sU32 c8;
               sU32 c32;

               c8 = (iter << 3);

               c32 = (ly + (c8 << 1));

               if(c32 > 255)
               {
                  c32 = 255;
               }

               c32 = (255u << 24) | (c8 << 16) | (c8 << 8) | c32;

               d[di++] = c32;
            }

            c_xx += s_xx;
         } /* loopy x */

         c_yy += s_yy;
         ly++;

         di += (_args->framebuffer.pitch >> 2) - _args->framebuffer.w;

      } /* loop y */

   }
#endif /* USE_STD_FLOATEMU */


#ifdef USE_FASTRTS_I
   /* wrong result */
   {
      sUI cx;
      sUI cy;
      float xx;
      float yy;
      //float c1 = (float) sin(_args->angle_i + sin(_args->angle_i) * 3.1415f * 2.0f) * 0.75f;
      //float c2 = (float) cos(_args->angle_j) * 0.7f;
      float c1 = _args->c1;
      float c2 = _args->c2;
      float s_xx = divsp_i(1.0f, ((float)(_args->framebuffer.w>>2)));
      float s_yy = divsp_i(1.0f, ((float)(_args->framebuffer.h>>2)));
      float c_yy = addsp_i(-1.8f, mpysp_i(s_yy, (float)_args->start_y));  // -1.8f + s_yy * _args->start_y
      sU32 ly = _args->start_y;
      sU32 iter;
      sU32 itd = _args->iter_depth;
      sU32 di = 0;
      sU32 *d = (sU32*)_args->framebuffer.data;

      for(cy=0; cy <_args->framebuffer.h; cy++)
      {
         float c_xx = addsp_i(-2.0f, mpysp_i((float)_args->start_x, s_xx)); //  -2.0f + _args->start_x * s_xx;

         for(cx=0; cx <_args->framebuffer.w; cx++)
         {
            float qxx;
            float qyy;
            float qxxyy;

            qxx   = mpysp_i(c_xx, c_xx);     // qxx   = c_xx * c_xx;
            qyy   = mpysp_i(c_yy, c_yy);     // qyy   = c_yy * c_yy;
            xx    = c_xx;                    // xx    = c_xx;
            yy    = c_yy;                    // yy    = c_yy;
            qxxyy = addsp_i(qxx, qyy);       // qxxyy = qxx + qyy;

            for(iter=0; (iter < itd) && (qxxyy <= 4.0f) ; iter++)
            {
               yy    = addsp_i(mpysp_i(2.0f, mpysp_i(xx, yy)), c2);  // yy    = 2.0 * xx * yy + c2;
               xx    = addsp_i(subsp_i(qxx, qyy), c1);               // xx    = qxx - qyy + c1;
               qxx   = mpysp_i(xx, xx);                              // qxx   = xx * xx;
               qyy   = mpysp_i(yy, yy);                              // qyy   = yy * yy;
               qxxyy = addsp_i(qxx, qyy);                            // qxxyy = qxx + qyy;
            }

            {
               sU32 c32;
               sU32 c8;

               c8 = (iter << 3);

               c32 = (ly + (c8 << 1));

               if(c32 > 255)
               {
                  c32 = 255;
               }

               //c32 = (255u << 24) | (c8 << 16) | (c8 << 8) | c8_clamptbl[ly + (c8 << 1)];
               c32 = (255u << 24) | (c8 << 16) | (c8 << 8) | c32;

               d[di++] = c32;
            }

            c_xx = addsp_i(c_xx, s_xx);  // c_xx += s_xx;

         } /* loop x */

         c_yy = addsp_i(c_yy, s_yy);  // c_yy += s_yy;
         ly++;

         di += (_args->framebuffer.pitch >> 2) - _args->framebuffer.w;

      } /* loop y */

   }
#endif /* USE_FASTRTS_I */

   syscalls.cache_wbAll();
}


/* --------------------------------------------------------------------------- exec */
static sU32 loc_exec(dsp_component_cmd_t _cmd,
                     sU32  _arg1, sU32  _arg2,
                     sU32 *_ret1, sU32 *_ret2
                     ) {
   sU32 ret;

   (void)_arg2;
   (void)_ret1;
   (void)_ret2;

   switch(_cmd)
   {
      default:
         /* Failed: illegal command id */
         ret = DEMO_FRACTAL_ERR_ILLCMD;
         break;

      case DEMO_FRACTAL_CMD_PROCESS:
      {
         //int tStart;
         //int tEnd;

         //tStart = clock();

         loc_process((const demo_fractal_args_t *)_arg1);

         //tEnd = clock();

         //*_ret1 = (sU32) (tEnd - tStart);

         /* Succeeded */
         ret = DEMO_FRACTAL_ERR_OK;
      }
      break;
   }

   return ret;
}


/* --------------------------------------------------------------------------- component_demo_fractal */
#pragma DATA_SECTION(component_demo_fractal,  ".sec_com");
dsp_component_t component_demo_fractal = {

   /* fxns: */
   {
      NULL,       /* init */
      &loc_exec,
      NULL,       /* exec fastcall RPC */
      NULL        /* exit */
   },

   COMPONENT_NAME_DEMO_FRACTAL
};


DSP_COMPONENT_MAIN
