/* ----
 * ---- file   : demo_fractal.h
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel.
 * ----          Distributed under terms of the MIT LICENSE (MIT).
 * ----
 * ---- Permission is hereby granted, free of charge, to any person obtaining a copy
 * ---- of this software and associated documentation files (the "Software"), to deal
 * ---- in the Software without restriction, including without limitation the rights
 * ---- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * ---- copies of the Software, and to permit persons to whom the Software is
 * ---- furnished to do so, subject to the following conditions:
 * ----
 * ---- The above copyright notice and this permission notice shall be included in
 * ---- all copies or substantial portions of the Software.
 * ----
 * ---- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * ---- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * ---- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * ---- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * ---- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * ---- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * ---- THE SOFTWARE.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 21Sep2013, 02Oct2013
 * ----
 * ----
 */

#ifndef __COMPONENT_DEMO_FRACTAL_H__
#define __COMPONENT_DEMO_FRACTAL_H__


#define COMPONENT_NAME_DEMO_FRACTAL  "demo_fractal"


typedef struct {
   struct {
      sU32 *data;
      sU32  pitch; /* num bytes per scanline */
      sU32  w;
      sU32  h;
   } framebuffer;

   sU32 start_x;
   sU32 start_y;

   ////float angle_i;
   ////float angle_j;
   float c1;
   float c2;
   sU32 iter_depth;

} demo_fractal_args_t;


enum {
   /*
    * arg1 = demo_fractal_args *
    */
   DEMO_FRACTAL_CMD_PROCESS = 1,

   NUM_DEMO_FRACTAL_COMMANDS
};


enum {
   DEMO_FRACTAL_ERR_OK      = 0,
   DEMO_FRACTAL_ERR_ILLCMD  = 1,

   NUM_DEMO_FRACTAL_ERROR_CODES
};


#ifndef MLB_COMPONENT_GPP

S_EXTERN dsp_component_t component_demo_fractal;

#endif /* MLB_COMPONENT_GPP */


#endif /* __COMPONENT_DEMO_FRACTAL_H__ */
