/* ----
 * ---- file   : dsprite.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel.
 * ----          Distributed under terms of the MIT LICENSE (MIT).
 * ----
 * ---- Permission is hereby granted, free of charge, to any person obtaining a copy
 * ---- of this software and associated documentation files (the "Software"), to deal
 * ---- in the Software without restriction, including without limitation the rights
 * ---- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * ---- copies of the Software, and to permit persons to whom the Software is
 * ---- furnished to do so, subject to the following conditions:
 * ----
 * ---- The above copyright notice and this permission notice shall be included in
 * ---- all copies or substantial portions of the Software.
 * ----
 * ---- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * ---- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * ---- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * ---- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * ---- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * ---- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * ---- THE SOFTWARE.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 23Oct2013, 24Oct2013, 25Oct2013, 27Oct2013, 12Nov2013, 13Nov2013, 08Dec2013
 * ----
 * ----
 */

#define SYSCALLS_C defined
#include <libc64_dsp/include/inc_overlay.h>

#include "dsprite.h"


#define SCRATCH_SIZE       (DSP_L1DSRAM_SCRATCHBUFFER_SIZE_DSP / 4)
#define SCRATCH_NUMPIX     (SCRATCH_SIZE >> 2)

#define SCRATCH1_ADDR  (DSP_L1DSRAM_SCRATCHBUFFER_BASE_DSP + 0u)
#define SCRATCH2_ADDR  (DSP_L1DSRAM_SCRATCHBUFFER_BASE_DSP + SCRATCH_SIZE)
#define SCRATCH3_ADDR  (DSP_L1DSRAM_SCRATCHBUFFER_BASE_DSP + SCRATCH_SIZE*2)
#define SCRATCH4_ADDR  (DSP_L1DSRAM_SCRATCHBUFFER_BASE_DSP + SCRATCH_SIZE*3)

typedef void (*multi_fxn_t) (sU32 *_s, sU32 *_d, sU32 _num, void *_ext);


/* --------------------------------------------------------------------------- loc_multi_alphatest_argb32() */
static void loc_multi_alphatest_argb32(sU32 *_s, sU32 *_d, sU32 _num, void *_ext) {
   sUI i;

   (void)_ext;

#pragma MUST_ITERATE(64, 1024, 8)   
   for(i=0; i<_num; i+=4)
   {
      sU32 src1 = _s[i];
      sU32 src2 = _s[i+1];
      sU32 src3 = _s[i+2];
      sU32 src4 = _s[i+3];
      sU32 dst1 = _d[i];
      sU32 dst2 = _d[i+1];
      sU32 dst3 = _d[i+2];
      sU32 dst4 = _d[i+3];
      _d[i+0] = (src1 >> 24) ? src1 : dst1;
      _d[i+1] = (src2 >> 24) ? src2 : dst2;
      _d[i+2] = (src3 >> 24) ? src3 : dst3;
      _d[i+3] = (src4 >> 24) ? src4 : dst4;
   }
}


/* --------------------------------------------------------------------------- loc_multi_premul_srcover_argb32() */
static void loc_multi_premul_srcover_argb32(sU32 *_s, sU32 *_d, sU32 _num, void *_ext) {
   sUI i;
   
   (void)_ext;

   /* Cd = Cs + Cd * (1-As) 
    * Ad = 0
    */

#pragma MUST_ITERATE(64, 1024, 8)
   for(i=0; i< _num; i+=2)
   {
      sU32 sa1, omsa1;
      sU32 sa2, omsa2;
      sU32 dr1, dg1, db1;
      sU32 dr2, dg2, db2;
      sU32 src1 = _s[i];
      sU32 src2 = _s[i];
      sU32 dst1 = _d[i+1];
      sU32 dst2 = _d[i+1];

      sa1   = (src1 >> 24);

      //sa1   = (((sU8)sa1) * ((sU8)dst1)) >> 8u; // test (==> does not affect pixel throughput)

      sa1   = sa1 + (sa1 & 1);
      omsa1 = 256u - sa1;

      sa2   = (src2 >> 24);
      sa2   = sa2 + (sa2 & 1);
      omsa2 = 256u - sa2;

      dr1 = (dst1 & 0x00FF0000u);
      dr1 = ((dr1 * omsa1) >> 8);
      dr1 = (dr1  & 0x00FF0000u);

      dr2 = (dst2 & 0x00FF0000u);
      dr2 = ((dr2 * omsa2) >> 8);
      dr2 = (dr2  & 0x00FF0000u);

      dg1 = (dst1 & 0x0000FF00u);
      dg1 = ((dg1 * omsa1) >> 8);
      dg1 = (dg1  & 0x0000FF00u);

      dg2 = (dst2 & 0x0000FF00u);
      dg2 = ((dg2 * omsa2) >> 8);
      dg2 = (dg2  & 0x0000FF00u);

      db1 = (dst1 & 0x000000FFu);
      db1 = ((db1 * omsa1) >> 8);
      db1 = (db1  & 0x000000FFu);

      db2 = (dst2 & 0x000000FFu);
      db2 = ((db2 * omsa2) >> 8);
      db2 = (db2  & 0x000000FFu);

      dst1 = dr1 | dg1 | db1;
      dst2 = dr2 | dg2 | db2;
     
      _d[i]   = _saddu4(src1, dst1);
      _d[i+1] = _saddu4(src2, dst2);
   }
}


/* --------------------------------------------------------------------------- loc_multi_srcover_argb32() */
static void loc_multi_srcover_argb32(sU32 *_s, sU32 *_d, sU32 _num, void *_ext) {
   sUI i;
   
   (void)_ext;

   /* Cd = Cs + Cd * (1-As) 
    * Ad = 0
    */

#pragma MUST_ITERATE(64, 1024, 8)
   for(i=0; i<_num; i++)
   {
      sU32 src = _s[i];
      sU32 dst = _d[i];
      sU16 sa;
#if 0
      sS16 sr, dr, sg, dg, sb, db;

      /* (note) optimize me */
      sa = (src >> 24);
      sa = sa + (sa & 1);

      sr = (src >> 16) & 255u;
      dr = (dst >> 16) & 255u;
      dr = (dr + (((sr - dr) * sa) >> 8));

      sg = (src >>  8) & 255u;
      dg = (dst >>  8) & 255u;
      dg = (dg + (((sg - dg) * sa) >> 8));

      sb = (src      ) & 255u;
      db = (dst      ) & 255u;
      db = (db + (((sb - db) * sa) >> 8));

      _d[i] =
         (((sU8)dr) << 16) |
         (((sU8)dg) <<  8) |
         (((sU8)db)      ) ;
#elif 0
      /* (note) slightly slower (40 vs. 42 fps) */
      sS32 sr, dr, sg, dg, sb, db;

      sa = (src >> 24);
      sa = sa + (sa & 1);

      sr = (src & 0x00FF0000u);
      dr = (dst & 0x00FF0000u);
      dr = (dr + (((sr - dr) * sa) >> 8)) & 0x00FF0000u;

      sg = (src & 0x0000FF00u);
      dg = (dst & 0x0000FF00u);
      dg = (dg + (((sg - dg) * sa) >> 8)) & 0x0000FF00u;

      sb = (src      ) & 255u;
      db = (dst      ) & 255u;
      db = (db + (((sb - db) * sa) >> 8)) & 0x000000FFu;

      _d[i] = (dr | dg | db);
#elif 0
      /* (note) same speed as first */
      sU8 sr, sg, sb;
      sU8 dr, dg, db;

      /* (note) optimize me */
      sa = (src >> 24);
      sa = sa + (sa & 1);

      sr = (sU8) (src >> 16);
      dr = (sU8) (dst >> 16);
      dr = (sU8) (dr + (((sr - dr) * sa) >> 8));

      sg = (sU8) (src >>  8);
      dg = (sU8) (dst >>  8);
      dg = (sU8) (dg + (((sg - dg) * sa) >> 8));

      sb = (sU8) (src);
      db = (sU8) (dst);
      db = (sU8) (db + (((sb - db) * sa) >> 8));

      _d[i] =
         (dr << 16) |
         (dg <<  8) |
         (db      ) ;
#elif 0
      /* minimally faster (42.3 vs. 41.3 FPS) */
      sU8 sg;
      sU8 dg;
      sU32 srb;
      sU32 drb;
      sU16 omsa;

      /* (note) optimize me */
      sa = (src >> 24);
      sa = sa + (sa & 1);

      omsa = 256u - sa;

      srb = (src & 0x00FF00FFu);
      drb = (dst & 0x00FF00FFu);

      drb = 
         (((sU32) (srb * sa  ) & 0xFF00FF00u) >> 8) +
         (((sU32) (drb * omsa) & 0xFF00FF00u) >> 8) ;

      sg = (sU8) (src >> 8u);
      dg = (sU8) (dst >> 8u);
      dg = (sU8) (dg + (((sg - dg) * sa) >> 8));

      _d[i] = (drb | (dg << 8u));
#else
      /* also same speed (~42.3 fps) */
      sU8 sg;
      sU8 dg;
      sU32 srb;
      sU32 drb;
      sU16 omsa;

      /* (note) optimize me */
      sa = (src >> 24);
      sa = sa + (sa & 1);

      omsa = 256u - sa;

      srb = (src & 0x00FF00FFu);
      drb = (dst & 0x00FF00FFu);

      if(srb > drb)
      {
         drb += 
            (((sU32) ((srb - drb) * sa  ) & 0xFF00FF00u) >> 8);
      }
      else
      {
         drb = srb +
            (((sU32) ((drb - srb) * omsa  ) & 0xFF00FF00u) >> 8);

      }

      sg = (sU8) (src >> 8u);
      dg = (sU8) (dst >> 8u);
      dg = (sU8) (dg + (((sg - dg) * sa) >> 8));

      _d[i] = (drb | (dg << 8u));
#endif

   }
}


/* --------------------------------------------------------------------------- loc_process() */
static sU32 loc_process(dsprite_op_ptr_t _union) {
   multi_fxn_t multi_fxn = NULL;

   syscalls.qdma_init();

   for(;;)
   {
      switch(_union.op[0])
      {
         default:
            /* illegal op */
            return _union.u32;

         case DSPRITE_OP_END:
            return 0;

         case DSPRITE_OP_COPY:
         {
            syscalls.qdma_copy2d(QDMA_0,
                                 (void*)_union.copy->sprite.dst_phys_addr,
                                 _union.copy->sprite.dst_pitch,
                                 (void*)_union.copy->sprite.src_phys_addr,
                                 _union.copy->sprite.src_pitch,
                                 _union.copy->num_bytes_x,
                                 _union.copy->num_y
                                 );
            
            syscalls.qdma_wait(QDMA_0);

            /* Next op */
            _union.copy++;
         }
         break;

         case DSPRITE_OP_ALPHATEST_ARGB32:
            multi_fxn = &loc_multi_alphatest_argb32;
            goto multiprocess;

         case DSPRITE_OP_PREMUL_SRCOVER_ARGB32:
            multi_fxn = &loc_multi_premul_srcover_argb32;
            goto multiprocess;

         case DSPRITE_OP_SRCOVER_ARGB32:
            multi_fxn = &loc_multi_srcover_argb32;
            goto multiprocess;

         multiprocess:
         {
            sU32 num = _union.multi->num;

            if(num > 0)
            {
               sU32 numPix = (_union.multi->w * _union.multi->h);
               
               if(numPix <= SCRATCH_NUMPIX)
               {
                  sU32 w4 = (_union.multi->w << 2);
                  sU32 h  = _union.multi->h;
                  sU32 *workSrc = (void*)SCRATCH1_ADDR;
                  sU32 *workDst = (void*)SCRATCH2_ADDR;
                  sU32 *workSrcNext = (void*)SCRATCH3_ADDR;
                  sU32 *workDstNext = (void*)SCRATCH4_ADDR;
                  sU32 *workSrcOverride = NULL;
                  sU32 *workSrcOverrideNext = NULL;
                  dsprite_t *spr;
                  sU32 extSz = _union.multi->ext_sz;

                  /* On to fxn specific extended data */
                  void *ext = ++_union.multi;

                  /* On to sprite entries */
                  _union.u32 += extSz;

                  spr = _union.sprite;
                  
                  /* Use QDMA0 to stream srcdata into workSrc */
                  if(spr->src_phys_addr < (IVA2_L1DSRAM_BASE_DSP + IVA2_L1DSRAM_SIZE))
                  {
                     /* Already in SRAM */
                     workSrcOverride = (sU32*) spr->src_phys_addr;
                  }
                  else
                  {
                     syscalls.qdma_copy2d(QDMA_0,
                                          workSrc,
                                          w4,
                                          (void*)spr->src_phys_addr,
                                          spr->src_pitch,
                                          w4,
                                          h
                                          );

                     workSrcOverride = NULL;
                  }
                  
                  /* Use QDMA1 to stream dest into workDst */
                  syscalls.qdma_copy2d(QDMA_1,
                                       workDst,
                                       w4,
                                       (void*)spr->dst_phys_addr,
                                       spr->dst_pitch,
                                       w4,
                                       h
                                       );

                  while(num-- > 0)
                  {
                     
                     syscalls.qdma_wait(QDMA_0);
                     syscalls.qdma_wait(QDMA_1);

                     if(num > 0)
                     {
                        if(spr[1].src_phys_addr < (IVA2_L1DSRAM_BASE_DSP + IVA2_L1DSRAM_SIZE))
                        {
                           /* Already in SRAM */
                           workSrcOverrideNext = (sU32*) spr[1].src_phys_addr;
                        }
                        else
                        {
                           /* Use QDMA0 to stream srcdata into next iteration workSrc */
                           syscalls.qdma_copy2d(QDMA_0,
                                                workSrcNext,
                                                w4,
                                                (void*)spr[1].src_phys_addr,
                                                spr[1].src_pitch,
                                                w4,
                                                h
                                                );

                           workSrcOverrideNext = NULL;
                        }
                        
                        /* Use QDMA1 to stream dest into next iteration workDst */
                        syscalls.qdma_copy2d(QDMA_1,
                                             workDstNext,
                                             w4,
                                             (void*)spr[1].dst_phys_addr,
                                             spr[1].dst_pitch,
                                             w4,
                                             h
                                             );
                     }
                     
                     /* Process current work buf */
                     if(1)
                     {
                        multi_fxn(workSrcOverride ? workSrcOverride : workSrc, workDst, numPix, ext);
                     }
                     
                     /* Wait until last iteration DMA write-out finished */
                     syscalls.qdma_wait(QDMA_2);
                     
                     /* Use QDMA2 to stream workDst to actual dest. buffer */
                     syscalls.qdma_copy2d(QDMA_2,
                                          (void*)spr->dst_phys_addr,
                                          spr->dst_pitch,
                                          workDst,
                                          w4,
                                          w4,
                                          h
                                          );

                     /* Swap ping-pong buffers */
                     {
                        void *t;

                        t = workSrc;
                        workSrc = workSrcNext;
                        workSrcNext = t;

                        t = workDst;
                        workDst = workDstNext;
                        workDstNext = t;
                     }

                     workSrcOverride = workSrcOverrideNext;
                     
                     /* Next sprite */
                     spr = ++_union.sprite;

                  } /* loop entries */

                  /* Wait until last iteration DMA write-out finished */
                  syscalls.qdma_wait(QDMA_2);

               } /* if fits into scratchbuffer */
               else
               {
                  /* Failed: does not fit into scratchbuffer */
                  return _union.u32;
               }
            }
            else
            {
               /* Nothing to draw (num == 0) */
               _union.multi++;
            }
         }
         break;

      } /* switch op */
   }
}


/* --------------------------------------------------------------------------- exec */
static sU32 loc_exec(dsp_component_cmd_t _cmd,
                     sU32  _arg1, sU32  _arg2,
                     sU32 *_ret1, sU32 *_ret2
                     ) {
   sU32 ret;

   switch(_cmd)
   {
      default:
         /* Failed: illegal command id */
         ret = DSPRITE_ERR_ILLCMD;
         break;

      case DSPRITE_CMD_PROCESS:
      {
         dsprite_op_ptr_t ptr;
         ptr.u32 = _arg1;
         
         *_ret1 = ret = loc_process(ptr);
      }
      break;

   }

   return ret;
}


/* --------------------------------------------------------------------------- component_dsprite */
#pragma DATA_SECTION(component_dsprite,  ".sec_com");
dsp_component_t component_dsprite = {

   /* fxns: */
   {
      NULL,       /* init() */
      &loc_exec,
      NULL,       /* exec fastcall RPC */
      NULL        /* exit() */
   },
   
   COMPONENT_NAME_DSPRITE,
};


DSP_COMPONENT_MAIN
