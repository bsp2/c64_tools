/* ----
 * ---- file   : dsprite.h
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel.
 * ----          Distributed under terms of the MIT LICENSE (MIT).
 * ----
 * ---- Permission is hereby granted, free of charge, to any person obtaining a copy
 * ---- of this software and associated documentation files (the "Software"), to deal
 * ---- in the Software without restriction, including without limitation the rights
 * ---- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * ---- copies of the Software, and to permit persons to whom the Software is
 * ---- furnished to do so, subject to the following conditions:
 * ----
 * ---- The above copyright notice and this permission notice shall be included in
 * ---- all copies or substantial portions of the Software.
 * ----
 * ---- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * ---- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * ---- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * ---- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * ---- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * ---- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * ---- THE SOFTWARE.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 23Oct2013, 12Nov2013, 13Nov2013, 14Nov2013
 * ----
 * ----
 */

#ifndef __COMPONENT_DSPRITE_H__
#define __COMPONENT_DSPRITE_H__


#define COMPONENT_NAME_DSPRITE  "dsprite"


/* (note) if not stated otherwise, destination buffer uses RGB32 format */

typedef enum {
     /* end of dlist */
   DSPRITE_OP_END                   = 0,

   /* copy sprite data w/o blending */
   DSPRITE_OP_COPY                  = 1,

   /* copy ARGB32 sprite data with alphatesting (0 = discard) */
   DSPRITE_OP_ALPHATEST_ARGB32      = 2,

   /* blend premultiplied ARGB32 sprite data with background */
   DSPRITE_OP_PREMUL_SRCOVER_ARGB32 = 3,

   /* blend non-premultiplied ARGB32 sprite data with background */
   DSPRITE_OP_SRCOVER_ARGB32        = 4,

   NUM_DSPRITE_OPS
} dsprite_op_t;


// ---------------------------------------------------------------------------- sprite
typedef struct {
   sU32 dst_phys_addr;
   sS32 dst_pitch;
   sU32 src_phys_addr;
   sS32 src_pitch;
} dsprite_t;


// ---------------------------------------------------------------------------- op: copy
typedef struct {
   dsprite_op_t op;

   sU32      num_bytes_x;
   sU32      num_y;
   dsprite_t sprite;
} dsprite_op_copy_t;


// ---------------------------------------------------------------------------- dsprite_multi_t
typedef struct {
   dsprite_op_t op;

   sU32 w;
   sU32 h;
   sU32 num;
   sU32 ext_sz;
   /* ext_bytes fxn specific data follows */
   /* dsprite_t[num] array follows */
} dsprite_multi_t;


// ---------------------------------------------------------------------------- dsprite_op_ptr_t
typedef union {
   sU32                u32;
   void               *any;
   dsprite_op_t       *op;
   dsprite_op_copy_t  *copy;
   dsprite_multi_t    *multi;
   dsprite_t          *sprite;
} dsprite_op_ptr_t;


enum {
   DSPRITE_CMD_PROCESS                   =  1,

   NUM_DSPRITE_COMMANDS
};


enum {
   DSPRITE_ERR_OK        = 0,
   DSPRITE_ERR_ILLCMD    = 1,

   NUM_DSPRITE_ERROR_CODES
};


#ifndef MLB_COMPONENT_GPP

S_EXTERN dsp_component_t component_dsprite;

#endif /* MLB_COMPONENT_GPP */


#endif /* __COMPONENT_DSPRITE_H__ */
