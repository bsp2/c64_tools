
 /*
  * planar to chunky code borrowed from UAE "drawing.cpp" 
  *
  * Copyright 1995-2000 Bernd Schmidt
  * Copyright 1995 Alessandro Bissacco
  * Copyright 2000,2001 Toni Wilen
  */

#include <stdio.h>
#include <string.h>

typedef unsigned int sU32;
typedef unsigned char sU8;


#define MERGE(a,b,mask,shift) {\
    sU32 tmp = mask & (a ^ (b >> shift)); \
    a ^= tmp; \
    b ^= (tmp << shift); \
}

#define MERGE_0(a,b,mask,shift) {\
   sU32 tmp = mask & (b>>shift); \
   a = tmp; \
   b ^= (tmp << shift); \
}

#define DO_SWLONG(A,V) {\
	sU8 *b = (sU8 *)(A); \
	sU32 v = (V); \
	*b++ = v >> 24; \
	*b++ = v >> 16; \
	*b++ = v >> 8; \
	*b = v; \
}



sU32 bpl = 0xaaaaAAAA;
sU8 pix_data[32];

int main(int argc, char**argv) {
   
   sU32 b0 = bpl;
   sU32 b1 = bpl;
   sU32 b2 = bpl;
   sU32 b3 = bpl;
   sU32 b4 = bpl;
   sU32 b5 = bpl;
   sU32 b6 = bpl;
   sU32 b7 = bpl;
   sU32 *pixels = (sU32*)pix_data;

   memset(pixels, 0, sizeof(sU8) * 32);

   MERGE (b0, b1, 0x55555555, 1);
	MERGE (b2, b3, 0x55555555, 1);
	MERGE (b4, b5, 0x55555555, 1);
	MERGE (b6, b7, 0x55555555, 1);

	MERGE (b0, b2, 0x33333333, 2);
	MERGE (b1, b3, 0x33333333, 2);
	MERGE (b4, b6, 0x33333333, 2);
	MERGE (b5, b7, 0x33333333, 2);

	MERGE (b0, b4, 0x0f0f0f0f, 4);
	MERGE (b1, b5, 0x0f0f0f0f, 4);
	MERGE (b2, b6, 0x0f0f0f0f, 4);
	MERGE (b3, b7, 0x0f0f0f0f, 4);

	MERGE (b0, b1, 0x00ff00ff, 8);
	MERGE (b2, b3, 0x00ff00ff, 8);
	MERGE (b4, b5, 0x00ff00ff, 8);
	MERGE (b6, b7, 0x00ff00ff, 8);

	MERGE (b0, b2, 0x0000ffff, 16);
	DO_SWLONG(pixels, b0);
	DO_SWLONG(pixels + 4, b2);
	MERGE (b1, b3, 0x0000ffff, 16);
	DO_SWLONG(pixels + 2, b1);
	DO_SWLONG(pixels + 6, b3);
	MERGE (b4, b6, 0x0000ffff, 16);
	DO_SWLONG(pixels + 1, b4);
	DO_SWLONG(pixels + 5, b6);
	MERGE (b5, b7, 0x0000ffff, 16);
	DO_SWLONG(pixels + 3, b5);
	DO_SWLONG(pixels + 7, b7);
	pixels += 8;   

   {
      sU32 i;

      for(i=0; i<32; i++)
      {
         printf("pix_data[%2u] = 0x%02x\n", i, pix_data[i]);
      }
   }

   return 0;
}
