/* ----
 * ---- file   : age_int.h
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel.
 * ----          Distributed under terms of the MIT LICENSE (MIT).
 * ----
 * ---- Permission is hereby granted, free of charge, to any person obtaining a copy
 * ---- of this software and associated documentation files (the "Software"), to deal
 * ---- in the Software without restriction, including without limitation the rights
 * ---- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * ---- copies of the Software, and to permit persons to whom the Software is
 * ---- furnished to do so, subject to the following conditions:
 * ----
 * ---- The above copyright notice and this permission notice shall be included in
 * ---- all copies or substantial portions of the Software.
 * ----
 * ---- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * ---- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * ---- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * ---- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * ---- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * ---- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * ---- THE SOFTWARE.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 18Nov2013, 24Nov2013, 30Nov2013, 01Dec2013, 04Dec2013
 * ----
 * ----
 */

/// If defined, use look up table for planar to chunky conversion (~175fps)
/// If not defined, calc. on-the-fly (~126 fps)
///   (note) only applies if USE_BITMERGE is not defined
#define USE_LUTEXP4 defined


/// If defined, use UAE-style bit twiddling for planar to chunky conversion (~235fps w/ state in sram, ~203 w/o)
#define USE_BITMERGE defined


/// If defined, place age_state in SRAM (~14% faster when USE_BITMERGE is defined)
//#define USE_STATE_IN_SRAM defined


#ifdef USE_BITMERGE
#undef USE_LUTEXP4
#else
#undef USE_STATE_IN_SRAM
#endif


/* ---------------------------------------------------------------------------- */
typedef struct {
   void (*preload_current_first) (void);  /* preload first scanline of current procstate */
   void (*preload_next_first) (void);     /* preload first scanline of next procstate */
   void (*render) (void);
} age_render_class_t;


/* ---------------------------------------------------------------------------- */
typedef struct {
   sU32 *dest_addr;
   sS32  dest_stride;  /* num dwords per destination scanline */

   sU16  w;   /* current number of pixels to process per scanline */
   sU16  h;   /* current number of scanlines to process */
   sU16  vid_mode;
   sU16  blend_mode;
   sU16  flags;
   sU16  bpl_num;

   const sU32 *pal;

   sU16 *bpl_addr       [AGE_MAX_BITPLANES];
   sU8   bpl_shift      [AGE_MAX_BITPLANES];  /* (16 - shift), actually */
   sS16  bpl_mod        [AGE_MAX_BITPLANES];

   age_render_class_t *render_class;

} age_process_state_t;


/* ---------------------------------------------------------------------------- */
#define AGE_NPROC_DIRTY_PAL         (1u <<  0)



/* ---------------------------------------------------------------------------- */
typedef struct {

   sU32 bpl_shift_mask [AGE_MAX_BITPLANES];

   /* swapped after each scanline */
   sU32 *dest_workbuf_cur;
   sU32 *dest_workbuf_last;

   /* swapped after each scanline */
   sU16 *src_workbuf_cur[8];
   sU16 *src_workbuf_next[8];

   age_process_state_t process_states[2];

   /* swapped after each AGE_OP_PROCESS */
   age_process_state_t *cur_process_state;
   age_process_state_t *next_process_state;

   sU32 next_procstate_dirty_flags;

   sS32  dl_stack_idx;  /* 0..AGE_DL_STACK_SIZE-1 */
   sU32 *dl_stack[AGE_DL_STACK_SIZE];
   sU32 *dl_err_addr;   /* points to faulty displaylist op in case an error occured */

   /* colors that have changed since last OP_PROCESS / OP_PAL */
   sU32 next_procstate_dirty_flags_color[8];

} age_state_t;


S_EXTERN sU32 next_procstate_colors[256];

S_EXTERN sBool b_preloading_first_scanline;


/* ---------------------------------------------------------------------------- */
#ifdef USE_STATE_IN_SRAM
#define AGE_STATE(a)  AGE_SCRATCH(state).a
#else
#define AGE_STATE(a)  (age_state).a
#endif /* USE_STATE_IN_SRAM */


#define AGE_NPROCSTATE(a)  AGE_STATE(next_process_state)->a
#define AGE_CPROCSTATE(a)  AGE_STATE(cur_process_state)->a


/* ---------------------------------------------------------------------------- */
typedef struct { // 9024 bytes
#ifndef USE_BITMERGE
#ifdef USE_LUTEXP4
   sU32 exp4to4x8_lut[AGE_MAX_BITPLANES * 16u];
#endif /* USE_LUTEXP4 */
#endif /* !USE_BITMERGE */

   sU32 pal8_lut[256];

   sU32 dest_work1[AGE_MAX_W];
   sU32 dest_work2[AGE_MAX_W];

   sU16 bpl_work1[AGE_MAX_BITPLANES][AGE_MAX_W >> 4];
   sU16 bpl_work2[AGE_MAX_BITPLANES][AGE_MAX_W >> 4];

#ifdef USE_STATE_IN_SRAM
   age_state_t state;
#endif
   
} age_scratch_t;

#define AGE_SCRATCH(a)  (((age_scratch_t*)(DSP_L1DSRAM_SCRATCHBUFFER_BASE_DSP))->a)


/* ---------------------------------------------------------------------------- */
#ifndef USE_STATE_IN_SRAM
S_EXTERN age_state_t age_state;
#endif


/* ---------------------------------------------------------------------------- */
S_EXTERN void age_procstate_copytocurrent (void);

S_EXTERN sU32 age_dl_parse (sBool _bPrefetchOnly);


/* ---------------------------------------------------------------------------- render classes */
S_EXTERN age_render_class_t age_render_class_argb32_bpl8;
