
 /*
  * planar to chunky code based on UAE "drawing.cpp" 
  *
  * Copyright 1995-2000 Bernd Schmidt
  * Copyright 1995 Alessandro Bissacco
  * Copyright 2000,2001 Toni Wilen
  */

#include <stdio.h>
#include <string.h>

typedef unsigned char  sU8;
typedef unsigned short sU16;
typedef unsigned int   sU32;


/* also see http://graphics.stanford.edu/~seander/bithacks.html#InterleaveBMN */

#define MERGE(a,b,mask,shift) {\
    sU16 tmp = mask & (a ^ (b >> shift)); \
    a ^= tmp; \
    b ^= (tmp << shift); \
}

sU16 bpl = 0xAAAA;
sU8 pix_data[16];

int main(int argc, char**argv) {

   /* bitplane data (b0..7 <=> planes 7..0) */
   sU16 b0 = 3 <<  0;
   sU16 b1 = 3 <<  2;
   sU16 b2 = 3 <<  4;
   sU16 b3 = 3 <<  6;
   sU16 b4 = 3 <<  8;
   sU16 b5 = 3 << 10;
   sU16 b6 = 3 << 12;
   sU16 b7 = 0x5555;//3 << 14;
   sU32 *pixels = (sU32*)pix_data;

   memset(pixels, 0xCC, sizeof(sU8) * 16);

   MERGE(b0, b1, 0x5555u, 1);
	MERGE(b2, b3, 0x5555u, 1);
	MERGE(b4, b5, 0x5555u, 1);
	MERGE(b6, b7, 0x5555u, 1);

	MERGE(b0, b2, 0x3333u, 2);
	MERGE(b1, b3, 0x3333u, 2);
	MERGE(b4, b6, 0x3333u, 2);
	MERGE(b5, b7, 0x3333u, 2);

	MERGE(b0, b4, 0x0f0fu, 4);
	MERGE(b1, b5, 0x0f0fu, 4);
	MERGE(b2, b6, 0x0f0fu, 4);
	MERGE(b3, b7, 0x0f0fu, 4);

	MERGE(b0, b1, 0x00ffu, 8);
	MERGE(b2, b3, 0x00ffu, 8);
	MERGE(b4, b5, 0x00ffu, 8);
	MERGE(b6, b7, 0x00ffu, 8);

	pixels[0] = (b0 << 16) | b2;
	pixels[2] = (b1 << 16) | b3;
	pixels[1] = (b4 << 16) | b6;
	pixels[3] = (b5 << 16) | b7;

   /* pixel byte order in memory: 
    * 
    *  ( 3,  2,  1,  0,
    *    7,  6,  5,  4,
    *   11, 10,  9,  8,
    *   15, 14, 13, 12  )
    *
    */

   {
      sU32 i;

      for(i=0; i<16; i++)
      {
         printf("pix_data[%2u] = 0x%02x\n", i, pix_data[i]);
      }
   }

   return 0;
}
