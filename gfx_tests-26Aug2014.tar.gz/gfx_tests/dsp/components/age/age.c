/* ----
 * ---- file   : age.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel.
 * ----          Distributed under terms of the MIT LICENSE (MIT).
 * ----
 * ---- Permission is hereby granted, free of charge, to any person obtaining a copy
 * ---- of this software and associated documentation files (the "Software"), to deal
 * ---- in the Software without restriction, including without limitation the rights
 * ---- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * ---- copies of the Software, and to permit persons to whom the Software is
 * ---- furnished to do so, subject to the following conditions:
 * ----
 * ---- The above copyright notice and this permission notice shall be included in
 * ---- all copies or substantial portions of the Software.
 * ----
 * ---- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * ---- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * ---- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * ---- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * ---- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * ---- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * ---- THE SOFTWARE.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 18Nov2013, 24Nov2013, 30Nov2013, 01Dec2013, 04Dec2013
 * ----
 * ----
 */

#define SYSCALLS_C defined
#include <libc64_dsp/include/inc_overlay.h>

#include "age.h"
#include "age_int.h"


/* --------------------------------------------------------------------------- module vars */
#ifndef USE_STATE_IN_SRAM
age_state_t age_state;
#endif

sU32 next_procstate_colors[256];

sBool b_preloading_first_scanline;


/* --------------------------------------------------------------------------- lutexp4_init() */
#ifdef USE_LUTEXP4
static void loc_lutexp4_init(void) {
   sU32 *lutEXP4 = AGE_SCRATCH(exp4to4x8_lut);
   
   sU32 bitIdx;
   
   for(bitIdx=0; bitIdx < 8u; bitIdx++)
   {
      sSI i;
      
      for(i=0; i<16u; i++)
         //for(i=15; i>=0; i--)
      {
         sU32 v = 0u;
         
         if(i & 1u)
         {
            v |= ( (1u << 24u) << bitIdx); 
         }
         
         if(i & 2u)
         {
            v |= ( (1u << 16u) << bitIdx);
         }
         
         if(i & 4u)
         {
            v |= ( (1u <<  8u) << bitIdx);
         }
         
         if(i & 8u)
         {
            v |= ( (1u <<  0u) << bitIdx);
         }
         
         *lutEXP4++ = v;
      }
      
   }
}
#endif /* USE_LUTEXP4 */


/* --------------------------------------------------------------------------- age_procstate_copytocurrent() */
void age_procstate_copytocurrent(void) {
   /* (note) called immediately before pixel process() */

   sU32 dirtyFlags = AGE_STATE(next_procstate_dirty_flags);

   memcpy(AGE_STATE(cur_process_state),
          AGE_STATE(next_process_state),
          sizeof(age_process_state_t)
          );

   if(0 != (dirtyFlags & AGE_NPROC_DIRTY_PAL))
   {
      if(NULL != AGE_CPROCSTATE(pal))
      {
         if(0 != (AGE_CPROCSTATE(flags) & AGE_FLAG_COPY_PAL))
         {
            /* Copy PAL to L1DSRAM */
#if 0
            syscalls.cache_inv((void*)_args->pal_addr, sizeof(sU32) * 256, S_TRUE/*wait*/);
#endif
            
            syscalls.memcpy(AGE_SCRATCH(pal8_lut), (const void*)AGE_CPROCSTATE(pal), sizeof(sU32) * 256);

            /* Reset palette to internal */
            AGE_CPROCSTATE(pal) = AGE_SCRATCH(pal8_lut);
         }
         else
         {
            /* Access palette by reference (slow if placed in shared memory) */
         }
      }
      else
      {
         /* Reset palette to internal */
         AGE_CPROCSTATE(pal) = AGE_SCRATCH(pal8_lut);
      }
   }

   /* Prepare bitplane shift masks */
   if(AGE_VIDMODE_BITMAP == AGE_CPROCSTATE(vid_mode))
   {
      sUI i;

      for(i=0; i<AGE_MAX_BITPLANES; i++)
      {
         AGE_STATE(bpl_shift_mask) [i] =
            ~(((sU32)0xFFFFu) << AGE_CPROCSTATE(bpl_shift)[i]);
      }
   }

   /* Update individual palette entries */
   {
      sUI col32Idx;
      sUI colIdx = 0;

      for(col32Idx=0; col32Idx<8; col32Idx++)
      {
         sU32 colFlags = AGE_STATE(next_procstate_dirty_flags_color)[col32Idx];

         if(0 != colFlags)
         {
            sUI i;
            sU32 mask = (1u << 0);

            for(i=0; i<32; i++)
            {
               if(0 != (colFlags & mask))
               {
                  AGE_SCRATCH(pal8_lut)[colIdx] = next_procstate_colors[colIdx];
               }

               colIdx++;
            }
         }
         else
         {
            colIdx += 32u;
         }
      }
   }

   /* Reset dirty flags */
   AGE_STATE(next_procstate_dirty_flags) = 0;

   /* Estimate bpl source addresses for next process() call 
    *  (may be overriden by OP_BPLnADDR)
    */
   {
      sUI i;

      for(i=0; i<AGE_MAX_BITPLANES; i++)
      {
         AGE_NPROCSTATE(bpl_addr)[i] =
            ((sU16*)AGE_CPROCSTATE(bpl_addr)[i]) + 
            (AGE_CPROCSTATE(h) * AGE_CPROCSTATE(bpl_mod)[i])
            ;
      }
   }

   /* Estimate destination address for next process() call
    *  (may be overriden by OP_DEST_ADDR)
    */
   AGE_NPROCSTATE(dest_addr) =
      AGE_CPROCSTATE(dest_addr) + 
      (AGE_CPROCSTATE(h) * AGE_CPROCSTATE(dest_stride))
      ;

   /* Updated when/if parsing next OP_PROCESS */
   AGE_NPROCSTATE(render_class) = NULL;
}


/* --------------------------------------------------------------------------- age_dl_parse() */
sU32 age_dl_parse(sBool _bPrefetchOnly) {
   sU32 *dl = AGE_STATE(dl_stack[AGE_STATE(dl_stack_idx)]);

   for(;;)
   {
      sU32 op = dl[0];

      switch(op)
      {
         default:
            if((op >= AGE_OP_COLOR) && (op < (AGE_OP_COLOR + 256u)))
            {
               sUI colIdx = (op - AGE_OP_COLOR);

               if(_bPrefetchOnly)
               {
                  /* Will be merged with palette when loc_procstate_copytocurrent() is called */
                  next_procstate_colors[colIdx] = dl[1];
                  AGE_STATE(next_procstate_dirty_flags_color)[colIdx >> 5] |= (1u << (colIdx & 31));
               }
               else
               {
                  /* Update palette immediately */
                  AGE_SCRATCH(pal8_lut)[(op - AGE_OP_COLOR)] = dl[1];
               }
            }
            else
            {
               /* Error: invalid op */
               AGE_STATE(dl_err_addr) = dl;

               return AGE_ERR_PROCESS_INVALIDOP;
            }
            break;
            
         case AGE_OP_LINK:
            if(0 != dl[1])
            {
               if((AGE_STATE(dl_stack_idx) + 1) < AGE_DL_STACK_SIZE)
               {
                  /* Store return address on stack */
                  AGE_STATE(dl_stack)[AGE_STATE(dl_stack_idx)] = (dl + 2);

                  /* Push callee address onto stack */
                  dl = (sU32*)dl[1];
                  AGE_STATE(dl_stack_idx)++;
                  AGE_STATE(dl_stack)[AGE_STATE(dl_stack_idx)] = dl;

                  continue;
               }
               else
               {
                  /* Error: Displaylist stack overflow */
                  AGE_STATE(dl_err_addr) = dl;

                  return AGE_ERR_PROCESS_DLSTACKOVERFLOW;
               }
            }
            else
            {
               /* Displaylist finished, return from call */
               if(AGE_STATE(dl_stack_idx) > 0)
               {
                  AGE_STATE(dl_stack_idx)--;
                  dl = AGE_STATE(dl_stack)[AGE_STATE(dl_stack_idx)];

                  continue;
               }
               else
               {
                  /* Root displaylist finished */
                  AGE_STATE(dl_stack)[0] = NULL;

                  return AGE_ERR_OK;
               }
            }
            //break;

         case AGE_OP_PROCESS:

            AGE_NPROCSTATE(w) = (sU16) (dl[1] >> 16);
            AGE_NPROCSTATE(h) = (sU16) (dl[1] & 65535u);

            /* (todo) select state-dependent render fxn */
            AGE_NPROCSTATE(render_class) = &age_render_class_argb32_bpl8;

            if(!_bPrefetchOnly)
            {
               /* Update display list stack (parsing continues there) */
               AGE_STATE(dl_stack)[AGE_STATE(dl_stack_idx)] = (dl + 2);

               /* Copy updated states, merge palette */
               age_procstate_copytocurrent();

               if(NULL != AGE_CPROCSTATE(dest_addr))
               {
                  sU32 err;

                  /* Stream bitplanes for first scanline into workbuffers */
                  if(S_FALSE == b_preloading_first_scanline)
                  {
                     AGE_CPROCSTATE(render_class)->preload_current_first();
                  }
                  else
                  {
                     /* Preload already started at last scanline of last process OP */
                     b_preloading_first_scanline = S_FALSE;
                  }
                  
                  /* Prefetch/parse next process state while src buffers are being loaded */
                  {
                     err = age_dl_parse(S_TRUE/*bPrefetchOnly*/);
                     
                     if(AGE_ERR_OK != err)
                     {
                        /* Parse error */
                        return err;
                     }
                  }

                  AGE_CPROCSTATE(render_class)->render();

                  if(NULL == AGE_STATE(dl_stack)[0])
                  {
                     /* Prefetch hit end of root displaylist => nothing more to parse */
                     return AGE_ERR_OK;
                  }
                  
                  /* Reload display list stack */
                  dl = AGE_STATE(dl_stack)[AGE_STATE(dl_stack_idx)];
                     
                  continue;
               }
               else
               {
                  AGE_STATE(dl_err_addr) = dl;

                  return AGE_ERR_PROCESS_INVALIDDESTADDR;
               }
            }
            else
            {
               /* Update display list stack */
               AGE_STATE(dl_stack)[AGE_STATE(dl_stack_idx)] = dl;

               /* Succeeded */
               return AGE_ERR_OK;
            }
            //break;

         case AGE_OP_BLEND:
            AGE_NPROCSTATE(blend_mode) = (sU16) dl[1];
            break;

         case AGE_OP_VIDMODE:
            if(dl[1] < NUM_AGE_VIDMODES)
            {
               AGE_NPROCSTATE(vid_mode) = (sU16) dl[1];
            }
            else
            {
               /* Failed: invalid video mode */
               AGE_STATE(dl_err_addr) = dl;

               return AGE_ERR_PROCESS_INVALIDVIDMODE;
            }
            break;

         case AGE_OP_FLAGS:
            AGE_NPROCSTATE(flags) = (sU16) dl[1];
            break;

         case AGE_OP_BPL_NUM:
            AGE_NPROCSTATE(bpl_num) = (sU16) dl[1];
            break;

         case AGE_OP_PAL_ADDR:
            AGE_NPROCSTATE(pal) = (sU32*) dl[1];

            AGE_STATE(next_procstate_dirty_flags) |= AGE_NPROC_DIRTY_PAL;
            
            /* Discard all color updates */
            AGE_STATE(next_procstate_dirty_flags_color)[0] = 0;
            AGE_STATE(next_procstate_dirty_flags_color)[1] = 0;
            AGE_STATE(next_procstate_dirty_flags_color)[2] = 0;
            AGE_STATE(next_procstate_dirty_flags_color)[3] = 0;
            AGE_STATE(next_procstate_dirty_flags_color)[4] = 0;
            AGE_STATE(next_procstate_dirty_flags_color)[5] = 0;
            AGE_STATE(next_procstate_dirty_flags_color)[6] = 0;
            AGE_STATE(next_procstate_dirty_flags_color)[7] = 0;
            break;

         case AGE_OP_REPEAT:
            /* (todo) */
            //AGE_NPROCSTATE(bpl_shift)[0] = (sU8) (16u - dl[1]);
            break;

         case AGE_OP_BPL0_ADDR:
            AGE_NPROCSTATE(bpl_addr)[0] = (void*) dl[1];
            break;

         case AGE_OP_BPL1_ADDR:
            AGE_NPROCSTATE(bpl_addr)[1] = (void*) dl[1];
            break;

         case AGE_OP_BPL2_ADDR:
            AGE_NPROCSTATE(bpl_addr)[2] = (void*) dl[1];
            break;

         case AGE_OP_BPL3_ADDR:
            AGE_NPROCSTATE(bpl_addr)[3] = (void*) dl[1];
            break;

         case AGE_OP_BPL4_ADDR:
            AGE_NPROCSTATE(bpl_addr)[4] = (void*) dl[1];
            break;

         case AGE_OP_BPL5_ADDR:
            AGE_NPROCSTATE(bpl_addr)[5] = (void*) dl[1];
            break;

         case AGE_OP_BPL6_ADDR:
            AGE_NPROCSTATE(bpl_addr)[6] = (void*) dl[1];
            break;

         case AGE_OP_BPL7_ADDR:
            AGE_NPROCSTATE(bpl_addr)[7] = (void*) dl[1];
            break;

         case AGE_OP_BPL0_MOD:
            AGE_NPROCSTATE(bpl_mod)[0] = (sS16) dl[1];
            break;

         case AGE_OP_BPL1_MOD:
            AGE_NPROCSTATE(bpl_mod)[1] = (sS16) dl[1];
            break;

         case AGE_OP_BPL2_MOD:
            AGE_NPROCSTATE(bpl_mod)[2] = (sS16) dl[1];
            break;

         case AGE_OP_BPL3_MOD:
            AGE_NPROCSTATE(bpl_mod)[3] = (sS16) dl[1];
            break;

         case AGE_OP_BPL4_MOD:
            AGE_NPROCSTATE(bpl_mod)[4] = (sS16) dl[1];
            break;

         case AGE_OP_BPL5_MOD:
            AGE_NPROCSTATE(bpl_mod)[5] = (sS16) dl[1];
            break;

         case AGE_OP_BPL6_MOD:
            AGE_NPROCSTATE(bpl_mod)[6] = (sS16) dl[1];
            break;

         case AGE_OP_BPL7_MOD:
            AGE_NPROCSTATE(bpl_mod)[7] = (sS16) dl[1];
            break;

         case AGE_OP_BPL0_SHIFT:
            AGE_NPROCSTATE(bpl_shift)[0] = (16u - dl[1]);
            break;

         case AGE_OP_BPL1_SHIFT:
            AGE_NPROCSTATE(bpl_shift)[1] = (16u - dl[1]);
            break;

         case AGE_OP_BPL2_SHIFT:
            AGE_NPROCSTATE(bpl_shift)[2] = (16u - dl[1]);
            break;

         case AGE_OP_BPL3_SHIFT:
            AGE_NPROCSTATE(bpl_shift)[3] = (16u - dl[1]);
            break;

         case AGE_OP_BPL4_SHIFT:
            AGE_NPROCSTATE(bpl_shift)[4] = (16u - dl[1]);
            break;

         case AGE_OP_BPL5_SHIFT:
            AGE_NPROCSTATE(bpl_shift)[5] = (16u - dl[1]);
            break;

         case AGE_OP_BPL6_SHIFT:
            AGE_NPROCSTATE(bpl_shift)[6] = (16u - dl[1]);
            break;

         case AGE_OP_BPL7_SHIFT:
            AGE_NPROCSTATE(bpl_shift)[7] = (16u - dl[1]);
            break;

         case AGE_OP_DEST_ADDR:
            AGE_NPROCSTATE(dest_addr)   = (void*) dl[1];
            break;

         case AGE_OP_DEST_STRIDE:
            AGE_NPROCSTATE(dest_stride) = (sS32) dl[1];
            break;
      }
      
      /* Next op */
      dl += 2;
   }
        
}


/* --------------------------------------------------------------------------- loc_exec() */
static sU32 loc_exec(dsp_component_cmd_t _cmd,
                     sU32  _arg1, sU32  _arg2,
                     sU32 *_ret1, sU32 *_ret2
                     ) {
   sU32 ret;

   switch(_cmd)
   {
      default:
         /* Failed: illegal command id */
         ret = AGE_ERR_ILLCMD;
         break;

      case AGE_CMD_PROCESS:
      {
         syscalls.cache_wbInvAll();
         syscalls.qdma_init();

#ifdef USE_LUTEXP4
         /* Prepare bit expand LUTs */
         loc_lutexp4_init();
#endif  /* USE_LUTEXP4 */

         AGE_STATE(cur_process_state)  = &AGE_STATE(process_states[0]);
         AGE_STATE(next_process_state) = &AGE_STATE(process_states[1]);

         /* Initialize palette */
         AGE_SCRATCH(pal8_lut[0]) = 0xFF000000u;
         AGE_SCRATCH(pal8_lut[1]) = 0xFFffffffu;

         /* Load default state */
         AGE_NPROCSTATE(dest_addr)    = NULL;
         AGE_NPROCSTATE(dest_stride)  = 0;
         AGE_NPROCSTATE(w)            = 0;
         AGE_NPROCSTATE(h)            = 0;
         AGE_NPROCSTATE(vid_mode)     = AGE_VIDMODE_BITMAP;
         AGE_NPROCSTATE(blend_mode)   = AGE_BLEND_NONE;
         AGE_NPROCSTATE(flags)        = AGE_FLAG_NONE;
         AGE_NPROCSTATE(bpl_num)      = 8;
         AGE_NPROCSTATE(pal)          = AGE_SCRATCH(pal8_lut);
         AGE_NPROCSTATE(render_class) = NULL;
         AGE_NPROCSTATE(bpl_shift)[0] = 16u;
         AGE_NPROCSTATE(bpl_shift)[1] = 16u;
         AGE_NPROCSTATE(bpl_shift)[2] = 16u;
         AGE_NPROCSTATE(bpl_shift)[3] = 16u;
         AGE_NPROCSTATE(bpl_shift)[4] = 16u;
         AGE_NPROCSTATE(bpl_shift)[5] = 16u;
         AGE_NPROCSTATE(bpl_shift)[6] = 16u;
         AGE_NPROCSTATE(bpl_shift)[7] = 16u;

         /* Init displaylist stack and error address */
         AGE_STATE(dl_stack_idx) = 0;
         AGE_STATE(dl_stack)[0]  = (sU32*)_arg1;
         AGE_STATE(dl_err_addr)  = NULL;

         AGE_STATE(dest_workbuf_last) = AGE_SCRATCH(dest_work1);
         AGE_STATE(dest_workbuf_cur)  = AGE_SCRATCH(dest_work2);
         
         b_preloading_first_scanline = S_FALSE;

         {
            sUI i;
            
            for(i=0; i<AGE_MAX_BITPLANES; i++)
            {
               AGE_STATE(src_workbuf_cur[i])  = AGE_SCRATCH(bpl_work1[i]);
               AGE_STATE(src_workbuf_next[i]) = AGE_SCRATCH(bpl_work2[i]);
            }
         }

         AGE_STATE(next_procstate_dirty_flags) = 0;

         AGE_STATE(next_procstate_dirty_flags_color)[0] = 0;
         AGE_STATE(next_procstate_dirty_flags_color)[1] = 0;
         AGE_STATE(next_procstate_dirty_flags_color)[2] = 0;
         AGE_STATE(next_procstate_dirty_flags_color)[3] = 0;
         AGE_STATE(next_procstate_dirty_flags_color)[4] = 0;
         AGE_STATE(next_procstate_dirty_flags_color)[5] = 0;
         AGE_STATE(next_procstate_dirty_flags_color)[6] = 0;
         AGE_STATE(next_procstate_dirty_flags_color)[7] = 0;

         ret = *_ret1 = age_dl_parse(S_FALSE/*bPrefetchOnly*/);

         *_ret2 = (sU32)AGE_STATE(dl_err_addr);

         /* Wait until all destination pixels have been written */
         syscalls.qdma_wait(QDMA_0);
      }
      break;
   }

   return ret;
}


/* --------------------------------------------------------------------------- component_age */
#pragma DATA_SECTION(component_age,  ".sec_com");
dsp_component_t component_age = {

   /* fxns: */
   {
      NULL,       /* init() */
      &loc_exec,
      NULL,       /* exec fastcall RPC */
      NULL        /* exit() */
   },
   
   COMPONENT_NAME_AGE,
};


DSP_COMPONENT_MAIN
