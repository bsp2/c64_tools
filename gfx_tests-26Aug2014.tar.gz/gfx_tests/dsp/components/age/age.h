/* ----
 * ---- file   : age.h
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel.
 * ----          Distributed under terms of the MIT LICENSE (MIT).
 * ----
 * ---- Permission is hereby granted, free of charge, to any person obtaining a copy
 * ---- of this software and associated documentation files (the "Software"), to deal
 * ---- in the Software without restriction, including without limitation the rights
 * ---- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * ---- copies of the Software, and to permit persons to whom the Software is
 * ---- furnished to do so, subject to the following conditions:
 * ----
 * ---- The above copyright notice and this permission notice shall be included in
 * ---- all copies or substantial portions of the Software.
 * ----
 * ---- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * ---- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * ---- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * ---- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * ---- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * ---- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * ---- THE SOFTWARE.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 18Nov2013, 30Nov2013, 01Dec2013, 04Dec2013
 * ----
 * ----
 */

#ifndef __COMPONENT_AGE_H__
#define __COMPONENT_AGE_H__


#define COMPONENT_NAME_AGE  "age"


#define AGE_MAX_BITPLANES  (8u)

#define AGE_MAX_W  (832u)

#define AGE_DL_STACK_SIZE  (8u)


/* ---------------------------------------------------------------------------- commands */
enum {
   AGE_CMD_PROCESS   =  1,

   NUM_AGE_COMMANDS
};


/* ---------------------------------------------------------------------------- */
typedef struct {
   sU32 w;             // width
   sU32 h;             // height
   sU32 dst_addr;
   sU32 dst_stride;    // #pixels per scanline (incl. invis. pixels)

   sU32 num_bpls;      // number of bitplanes (1..8)
   sU32 bpl_addr [AGE_MAX_BITPLANES];  // bitplane address
   sU32 bpl_shift[AGE_MAX_BITPLANES];  // pixel delay (shift right) (0..15)
   sS32 bpl_mod  [AGE_MAX_BITPLANES];  // words per scanline

   sU32 pal_addr;      // palette address (up to 256 ARGB32 entries)
} age_bpl2argb32_args_t;


/* ---------------------------------------------------------------------------- video modes */
enum {
   /* off / don't write any pixels */
   AGE_VIDMODE_NONE     = 0,

   /* fill with bgcolor
    *
    */
   AGE_VIDMODE_FILLBG   = 1,

   /* bitmap / bitplane graphics (up to 8 planes)
    * 
    *  (note) AGE_OP_BPL_NUM controls number of active planes (1..8)
    *  (note) BPL0..7_ADDR points to pixel/bitmap data (1bit per plane)
    *  (note) BPL0..7_MOD stores number of 16bit words per scanline
    *  (note) BPL0..7_SHIFT range is 0..15
    *  (note) active palette must contain at least (1 << BPL_NUM) colors
    *  (note) srcalpha is modulated by fgcolor alpha if AGE_FLAGS_MODULATE_SRC_ALPHA is set
    *
    */
   AGE_VIDMODE_BITMAP   = 2,

   /* 8bits per pixel chunky mode (w/ palette lookup)
    *  (note) BPL0_ADDR points to pixel data (8bits per pixel)
    *  (note) BPL0_ADDR must be even (word aligned)
    *  (note) BPL0_MOD stores number of 16bit words per scanline
    *  (note) BPL0_SHIFT range is 0..15?
    *  (note) active palette must contain at least 256 colors
    *  (note) srcalpha is modulated by fgcolor alpha if AGE_FLAGS_MODULATE_SRC_ALPHA is set
    */
   AGE_VIDMODE_CHUNKY8  = 3,

   NUM_AGE_VIDMODES
};


/* ---------------------------------------------------------------------------- flags */
enum {
   AGE_FLAG_NONE               = 0,

   /* Zoom pixels horizontally (low-res)
    *
    */
   AGE_FLAG_DBLX               = (1 << 1),

   /* Copy palette to internal RAM 
    *  
    *  (note) if set, the palette entries can be updated using AGE_OP_COLOR (+0..+255) afterwards
    *
    *  (note) if unset, use palette by reference
    */
   AGE_FLAG_COPY_PAL           = (1 << 2),

   /* Read destination pixels (must enable for blending/colorkeying) 
    *
    *  (note) if dest. reading is disabled but dest pixels are required,
    *          the last seen (buffered) dest. data is used
    */
   AGE_FLAG_READ_DEST          = (1 << 3),

   __AGE_FLAGS_PAD__
};


/* ---------------------------------------------------------------------------- blend modes */
enum {
   AGE_BLEND_NONE           =  0,

   /* enable color keying. pal entry 0 or hicolor pixeldata 0 == don't draw pixel */
   AGE_BLEND_COLORKEY        = 1,

   /* enable premultiplied, saturated srcover blending
    *
    *  (note) alpha value is read from palette entry
    */
   AGE_BLEND_PREMUL_SRCOVER  = 2,

   NUM_AGE_BLEND_MODES
};


/* ---------------------------------------------------------------------------- displaylist ops */
enum {
   AGE_OP_LINK       =  0,  /* call other display list. 0=return from call */
   AGE_OP_PROCESS    =  1,  /* process "n" scanlines (lower 16bits) a "m" srcpixels (upper 10bits)
                             *  before reading next displaylist data
                             */
   AGE_OP_BLEND      =  2,  /* select blendmodem, see AGE_BLEND_xxx */
   AGE_OP_VIDMODE    =  3,  /* select video mode, see AGE_VIDMODE_xxx */
   AGE_OP_FLAGS      =  4,  /* see AGE_FLAGS_xxx */
   AGE_OP_BPL_NUM    =  5,  /* set number of bitplanes for BITMAP mode */
   AGE_OP_PAL_ADDR   =  6,  /* set palette address. 0=use bg/fg color */
   AGE_OP_REPEAT     =  7,  /* enable/disable repeat-last-scanline mode
                             *  (if enabled, don't reread source pixels, and recalc destpixels only if
                             *   palette or pixel/bpl shift(s) have changed)
                             */
   AGE_OP_BPL0_ADDR  =  8,  /* set bitplane 0 or chunky/hicolor pixeldata address */
   AGE_OP_BPL1_ADDR  =  9,  /* set bitplane 1 address (BITMAP mode only) */
   AGE_OP_BPL2_ADDR  = 10,  /* set bitplane 2 address (BITMAP mode only) */
   AGE_OP_BPL3_ADDR  = 11,  /* set bitplane 3 address (BITMAP mode only) */
   AGE_OP_BPL4_ADDR  = 12,  /* set bitplane 4 address (BITMAP mode only) */
   AGE_OP_BPL5_ADDR  = 13,  /* set bitplane 5 address (BITMAP mode only) */
   AGE_OP_BPL6_ADDR  = 14,  /* set bitplane 6 address (BITMAP mode only) */
   AGE_OP_BPL7_ADDR  = 15,  /* set bitplane 7 address (BITMAP mode only) */

   AGE_OP_BPL0_MOD   = 16,  /* set number of 16bit words per scanline (bitplane 0 or chunky) */
   AGE_OP_BPL1_MOD   = 17,  /* set number of 16bit words per scanline (bitplane 1 in BITMAP mode) */
   AGE_OP_BPL2_MOD   = 18,  /* set number of 16bit words per scanline (bitplane 2 in BITMAP mode) */
   AGE_OP_BPL3_MOD   = 19,  /* set number of 16bit words per scanline (bitplane 3 in BITMAP mode) */
   AGE_OP_BPL4_MOD   = 20,  /* set number of 16bit words per scanline (bitplane 4 in BITMAP mode) */
   AGE_OP_BPL5_MOD   = 21,  /* set number of 16bit words per scanline (bitplane 5 in BITMAP mode) */
   AGE_OP_BPL6_MOD   = 22,  /* set number of 16bit words per scanline (bitplane 6 in BITMAP mode) */
   AGE_OP_BPL7_MOD   = 23,  /* set number of 16bit words per scanline (bitplane 7 in BITMAP mode) */

   AGE_OP_BPL0_SHIFT = 24,  /* set scrolling / pixel delay (bitplane 0 or chunky) */
   AGE_OP_BPL1_SHIFT = 25,  /* set scrolling / pixel delay (bitplane 1 in BITMAP mode) */
   AGE_OP_BPL2_SHIFT = 26,  /* set scrolling / pixel delay (bitplane 2 in BITMAP mode) */
   AGE_OP_BPL3_SHIFT = 27,  /* set scrolling / pixel delay (bitplane 3 in BITMAP mode) */
   AGE_OP_BPL4_SHIFT = 28,  /* set scrolling / pixel delay (bitplane 4 in BITMAP mode) */
   AGE_OP_BPL5_SHIFT = 29,  /* set scrolling / pixel delay (bitplane 5 in BITMAP mode) */
   AGE_OP_BPL6_SHIFT = 30,  /* set scrolling / pixel delay (bitplane 6 in BITMAP mode) */
   AGE_OP_BPL7_SHIFT = 31,  /* set scrolling / pixel delay (bitplane 7 in BITMAP mode) */

   AGE_OP_DEST_ADDR   = 40, /* set destination pixel address (must be 16bit-word-aligned) */
   AGE_OP_DEST_STRIDE = 41, /* set number of 32bit dwords per destination scanline (signed) */

   AGE_OP_COLOR      = 48,  /* set ARGB32 color:
                             *  +  0 = bgcolor
                             *  +  1 = fgcolor
                             *  +  2 = color002,
                             *  ...
                             *  +255 (303) = color255
                             */

   NUM_AGE_OPS
};


/* ---------------------------------------------------------------------------- error codes */
enum {
   AGE_ERR_OK                      = 0,
   AGE_ERR_ILLCMD                  = 1,
   AGE_ERR_PROCESS_INVALIDOP       = 2,  /* error processing displaylist, ret2 contains address of faulty cmd/op */
   AGE_ERR_PROCESS_DLSTACKOVERFLOW = 3,
   AGE_ERR_PROCESS_INVALIDVIDMODE  = 4,
   AGE_ERR_PROCESS_INVALIDDESTADDR = 5,

   NUM_AGE_ERROR_CODES
};


#ifndef MLB_COMPONENT_GPP

S_EXTERN dsp_component_t component_age;

#endif /* MLB_COMPONENT_GPP */


#endif /* __COMPONENT_AGE_H__ */
