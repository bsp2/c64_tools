/* ----
 * ---- file   : age_bpl.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel.
 * ----          Distributed under terms of the MIT LICENSE (MIT).
 * ----
 * ---- Permission is hereby granted, free of charge, to any person obtaining a copy
 * ---- of this software and associated documentation files (the "Software"), to deal
 * ---- in the Software without restriction, including without limitation the rights
 * ---- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * ---- copies of the Software, and to permit persons to whom the Software is
 * ---- furnished to do so, subject to the following conditions:
 * ----
 * ---- The above copyright notice and this permission notice shall be included in
 * ---- all copies or substantial portions of the Software.
 * ----
 * ---- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * ---- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * ---- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * ---- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * ---- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * ---- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * ---- THE SOFTWARE.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 18Nov2013, 24Nov2013, 30Nov2013, 01Dec2013, 04Dec2013
 * ----
 * ----
 */

#include <libc64_dsp/include/inc_overlay.h>

#include "age.h"
#include "age_int.h"


/* also see UAE drawing.cpp and
 *  http://graphics.stanford.edu/~seander/bithacks.html#InterleaveBMN
 */
#define MERGE(a, b, mask, shift) {\
    sU16 tmp = mask & (a ^ (b >> shift)); \
    a ^= tmp; \
    b ^= (tmp << shift); \
}


/* --------------------------------------------------------------------------- loc_preload_current_first() */
static void loc_preload_current_first(void) {
   sUI numWords = (AGE_CPROCSTATE(w) >> 4);
   sUI i;

   for(i=7u; i>0; i--)
   {
      syscalls.qdma_link1d(QDMA_1,
                           (8 + i - 1),
                           (1 == i) ? 0xFFFFu : (8 + i - 2),
                           AGE_STATE(src_workbuf_cur[i]),
                           AGE_CPROCSTATE(bpl_addr)[i],
                           (numWords << 1)
                           );
   }
   
   syscalls.qdma_link1d(QDMA_1,
                        QDMA_1,
                        (8 + 7 - 1),
                        AGE_STATE(src_workbuf_cur[0]),
                        AGE_CPROCSTATE(bpl_addr)[0],
                        (numWords << 1)
                        );
}


/* --------------------------------------------------------------------------- loc_preload_next_first() */
static void loc_preload_next_first(void) {
   sUI numWords = (AGE_NPROCSTATE(w) >> 4);
   sUI i;

   for(i=7u; i>0; i--)
   {
      syscalls.qdma_link1d(QDMA_1,
                           (8 + i - 1),
                           (1 == i) ? 0xFFFFu : (8 + i - 2),
                           AGE_STATE(src_workbuf_next[i]),
                           AGE_NPROCSTATE(bpl_addr)[i],
                           (numWords << 1)
                           );
   }
   
   syscalls.qdma_link1d(QDMA_1,
                        QDMA_1,
                        (8 + 7 - 1),
                        AGE_STATE(src_workbuf_next[0]),
                        AGE_NPROCSTATE(bpl_addr)[0],
                        (numWords << 1)
                        );

   b_preloading_first_scanline = S_TRUE;
}


/* --------------------------------------------------------------------------- loc_render() */
static void loc_render(void) {
   sUI y;
   sUI i;
   sUI numWords = (AGE_CPROCSTATE(w) >> 4);
   sU32 *dReal = AGE_CPROCSTATE(dest_addr);
   const sU32 *pal = AGE_CPROCSTATE(pal);

   for(y=0; y<AGE_CPROCSTATE(h); y++)
   {
      sUI wi;
      sU32 cbits0;
      sU32 cbits1;
      sU32 cbits2;
      sU32 cbits3;
      sU32 cbits4;
      sU32 cbits5;
      sU32 cbits6;
      sU32 cbits7;
      
      sU32 *d = AGE_STATE(dest_workbuf_cur);

      cbits0 = cbits1 = cbits2 = cbits3 = cbits4 = cbits5 = cbits6 = cbits7 = 0u;

      /* Wait until scanline bitplanes have been read to SRAM */
      syscalls.qdma_wait(QDMA_1);

      if(y != (AGE_CPROCSTATE(h)-1))
      {
         /* Advance to next source bitplane scanlines */
         for(i=0; i<AGE_MAX_BITPLANES; i++)
         {
            (AGE_CPROCSTATE(bpl_addr)[i]) += AGE_CPROCSTATE(bpl_mod)[i];
         }

         /* Stream bitplanes for next scanline into workbuffers */
         {
            for(i=7u; i>0; i--)
            {
               syscalls.qdma_link1d(QDMA_1,
                                    (8 + i - 1),
                                    (1 == i) ? 0xFFFFu : (8 + i - 2),
                                    AGE_STATE(src_workbuf_next[i]),
                                    AGE_CPROCSTATE(bpl_addr)[i],
                                    (numWords << 1)
                                    );
            }

            syscalls.qdma_link1d(QDMA_1,
                                 QDMA_1,
                                 (8 + 7 - 1),
                                 AGE_STATE(src_workbuf_next[0]),
                                 AGE_CPROCSTATE(bpl_addr)[0],
                                 (numWords << 1)
                                 );
         }
      }
      else
      {
         if(NULL != AGE_NPROCSTATE(render_class))
         {
            AGE_NPROCSTATE(render_class)->preload_next_first();
         }
      }

      for(wi=0; wi<numWords; wi++)
      {
#ifndef USE_BITMERGE
         sU8 pgShift;
#ifdef USE_LUTEXP4
         const sU32 *lutEXP4 = AGE_SCRATCH(exp4to4x8_lut);
#endif /* USE_LUTEXP4 */
#endif /* !USE_BITMERGE */

#ifdef USE_BITMERGE
#if 1
         /* (note) ~5.5% faster than 16bit version */
         sU32 tbits0;
         sU32 tbits1;
         sU32 tbits2;
         sU32 tbits3;
         sU32 tbits4;
         sU32 tbits5;
         sU32 tbits6;
         sU32 tbits7;
#else
         sU16 tbits0;
         sU16 tbits1;
         sU16 tbits2;
         sU16 tbits3;
         sU16 tbits4;
         sU16 tbits5;
         sU16 tbits6;
         sU16 tbits7;
#endif
#endif

         /* Fetch bitplane bits and convert planar to chunky */
#define GETBITS(bplidx) \
         cbits##bplidx <<= 16;                                          \
         cbits##bplidx  &= AGE_STATE(bpl_shift_mask)[bplidx];           \
         cbits##bplidx  |= (((sU32)AGE_STATE(src_workbuf_cur[bplidx][wi])) << AGE_CPROCSTATE(bpl_shift)[bplidx]) \

         GETBITS(0);
         GETBITS(1);
         GETBITS(2);
         GETBITS(3);
         GETBITS(4);
         GETBITS(5);
         GETBITS(6);
         GETBITS(7);

#ifndef USE_BITMERGE
         /* Process 16 pixels in 4 groups */
         for(pgShift=(0+28u); pgShift >= (0+16u); pgShift -= 4u)
         {
            sU32 pix3210;

#ifdef USE_LUTEXP4
            pix3210  = lutEXP4[(0*16u) + ((cbits0 >> pgShift) & 15u)];
            pix3210 |= lutEXP4[(1*16u) + ((cbits1 >> pgShift) & 15u)];
            pix3210 |= lutEXP4[(2*16u) + ((cbits2 >> pgShift) & 15u)];
            pix3210 |= lutEXP4[(3*16u) + ((cbits3 >> pgShift) & 15u)];
            pix3210 |= lutEXP4[(4*16u) + ((cbits4 >> pgShift) & 15u)];
            pix3210 |= lutEXP4[(5*16u) + ((cbits5 >> pgShift) & 15u)];
            pix3210 |= lutEXP4[(6*16u) + ((cbits6 >> pgShift) & 15u)];
            pix3210 |= lutEXP4[(7*16u) + ((cbits7 >> pgShift) & 15u)];
#else
            {
               /* same speed as LUT version */
               sU8 cb;

               pix3210 = 0;

#define CKBITS(bplidx) \
               cb = (cbits##bplidx >> pgShift) & 15u; \
                                                                        \
               pix3210 |= (cb & (1u << 0u)) << (24u + bplidx); \
               pix3210 |= (cb & (1u << 1u)) << (15u + bplidx); \
               pix3210 |= (cb & (1u << 2u)) << ( 6u + bplidx); \
               pix3210 |= ((cb & (1u << 3u)) >> 3) << bplidx

               CKBITS(0);
               CKBITS(1);
               CKBITS(2);
               CKBITS(3);
               CKBITS(4);
               CKBITS(5);
               CKBITS(6);
               CKBITS(7);
            }
#endif /* USE_LUTEXP4 */

            /////pix3210 = 0xFFCC9966u;

            /* Write 4 ARGB32 pixels */
            {
               sU32 c32_0 = pal[ pix3210        & 255u];
               sU32 c32_1 = pal[(pix3210 >>  8) & 255u];
               sU32 c32_2 = pal[(pix3210 >> 16) & 255u];
               sU32 c32_3 = pal[(pix3210 >> 24) & 255u];
               
               *d++ = c32_0;
               *d++ = c32_1;
               *d++ = c32_2;
               *d++ = c32_3;
            }

         } /* process 4-pixel groups */
#endif /* !USE_BITMERGE */

      
#ifdef USE_BITMERGE   
         tbits7 =  cbits0 >> 16;
         tbits6 =  cbits1 >> 16;
         tbits5 =  cbits2 >> 16;
         tbits4 =  cbits3 >> 16;
         tbits3 =  cbits4 >> 16;
         tbits2 =  cbits5 >> 16;
         tbits1 =  cbits6 >> 16;
         tbits0 =  cbits7 >> 16;

         {
            MERGE(tbits0, tbits1, 0x5555u, 1);
            MERGE(tbits2, tbits3, 0x5555u, 1);
            MERGE(tbits4, tbits5, 0x5555u, 1);
            MERGE(tbits6, tbits7, 0x5555u, 1);
            
            MERGE(tbits0, tbits2, 0x3333u, 2);
            MERGE(tbits1, tbits3, 0x3333u, 2);
            MERGE(tbits4, tbits6, 0x3333u, 2);
            MERGE(tbits5, tbits7, 0x3333u, 2);
            
            MERGE(tbits0, tbits4, 0x0f0fu, 4);
            MERGE(tbits1, tbits5, 0x0f0fu, 4);
            MERGE(tbits2, tbits6, 0x0f0fu, 4);
            MERGE(tbits3, tbits7, 0x0f0fu, 4);
            
            MERGE(tbits0, tbits1, 0x00ffu, 8);
            MERGE(tbits2, tbits3, 0x00ffu, 8);
            MERGE(tbits4, tbits5, 0x00ffu, 8);
            MERGE(tbits6, tbits7, 0x00ffu, 8);

            /* pixel byte order in memory: 
             * 
             *  ( 3,  2,  1,  0,
             *    7,  6,  5,  4,
             *   11, 10,  9,  8,
             *   15, 14, 13, 12  )
             *
             */

            /* pixels[0] = (tbits[0] << 16) | tbits[2]; */
            /* pixels[2] = (tbits[1] << 16) | tbits[3]; */
            /* pixels[1] = (tbits[4] << 16) | tbits[6]; */
            /* pixels[3] = (tbits[5] << 16) | tbits[7]; */

            /* Write 16 ARGB32 pixels */
            {
               sU32 c32_0;
               sU32 c32_1;
               sU32 c32_2;
               sU32 c32_3;

               c32_0 = pal[(tbits0 >> 8) & 255u];
               c32_1 = pal[(tbits0     ) & 255u];
               c32_2 = pal[(tbits2 >> 8) & 255u];
               c32_3 = pal[(tbits2     ) & 255u];
               
               *d++ = c32_0;
               *d++ = c32_1;
               *d++ = c32_2;
               *d++ = c32_3;

               c32_0 = pal[(tbits4 >> 8) & 255u];
               c32_1 = pal[(tbits4     ) & 255u];
               c32_2 = pal[(tbits6 >> 8) & 255u];
               c32_3 = pal[(tbits6     ) & 255u];
               
               *d++ = c32_0;
               *d++ = c32_1;
               *d++ = c32_2;
               *d++ = c32_3;

               c32_0 = pal[(tbits1 >> 8) & 255u];
               c32_1 = pal[(tbits1     ) & 255u];
               c32_2 = pal[(tbits3 >> 8) & 255u];
               c32_3 = pal[(tbits3     ) & 255u];
               
               *d++ = c32_0;
               *d++ = c32_1;
               *d++ = c32_2;
               *d++ = c32_3;

               c32_0 = pal[(tbits5 >> 8) & 255u];
               c32_1 = pal[(tbits5     ) & 255u];
               c32_2 = pal[(tbits7 >> 8) & 255u];
               c32_3 = pal[(tbits7     ) & 255u];
               
               *d++ = c32_0;
               *d++ = c32_1;
               *d++ = c32_2;
               *d++ = c32_3;
            }
            
         }
#endif /* USE_BITMERGE */


      } /* for(wi..numWords) */

      /* Wait until last scanline has been written to memory */
      syscalls.qdma_wait(QDMA_0);

      /* Start writing workbuffer to memory */
      syscalls.qdma_copy1d(QDMA_0,
                           (void*)dReal,
                           AGE_STATE(dest_workbuf_cur),
                           (numWords << (4 + 2))
                           );

      
      /* Advance to next ARGB32 destination scanline */
      dReal += AGE_CPROCSTATE(dest_stride);

      /* Swap destination ping-pong buffers */
      {
         sU32 *t = AGE_STATE(dest_workbuf_cur);
         AGE_STATE(dest_workbuf_cur)  = AGE_STATE(dest_workbuf_last);
         AGE_STATE(dest_workbuf_last) = t;
      }

      /* Swap source ping-pong buffers */
      {
         for(i=0; i<AGE_MAX_BITPLANES; i++)
         {
            sU16 *t = AGE_STATE(src_workbuf_cur[i]);
            AGE_STATE(src_workbuf_cur[i])  = AGE_STATE(src_workbuf_next[i]);
            AGE_STATE(src_workbuf_next[i]) = t;
         }
      }

   } /* for(y.. */
}


/* --------------------------------------------------------------------------- render class */
age_render_class_t age_render_class_argb32_bpl8 = {
   &loc_preload_current_first,
   &loc_preload_next_first,
   &loc_render
};
