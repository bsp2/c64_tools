/* ----
 * ---- file   : dss.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel.
 * ----          Distributed under terms of the MIT LICENSE (MIT).
 * ----
 * ---- Permission is hereby granted, free of charge, to any person obtaining a copy
 * ---- of this software and associated documentation files (the "Software"), to deal
 * ---- in the Software without restriction, including without limitation the rights
 * ---- to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * ---- copies of the Software, and to permit persons to whom the Software is
 * ---- furnished to do so, subject to the following conditions:
 * ----
 * ---- The above copyright notice and this permission notice shall be included in
 * ---- all copies or substantial portions of the Software.
 * ----
 * ---- THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * ---- IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * ---- FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * ---- AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * ---- LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * ---- OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * ---- THE SOFTWARE.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 21Sep2013, 02Oct2013
 * ----
 * ----
 */

/* (note) this is a stub resp. just a test */

#include <std.h>
#include <mem.h>
#include <hwi.h>
#include <bcache.h>

#include <c64.h>

#include "../../../include/types.h"

#include <libc64_dsp/include/com.h>
#include <libc64_dsp/include/mlb.h>

#include "dss.h"


#define DSS_VID0_BA0  (0x480504bc + 0u)
#define DSS_VID0_BA1  (0x480504bc + 4u)


#define DSS_REG(a) (*(volatile sU32*)(a))


/* --------------------------------------------------------------------------- exec */
static sU32 loc_exec(dsp_component_cmd_t _cmd,
                     sU32  _arg1, sU32  _arg2,
                     sU32 *_ret1, sU32 *_ret2
                     ) {
   sU32 ret;

   switch(_cmd)
   {
      default:
         /* Failed: illegal command id */
         ret = DSS_ERR_ILLCMD;
         break;

      case DSS_VID0_ADDR:
         DSS_REG(DSS_VID0_BA0) = _arg1;
         DSS_REG(DSS_VID0_BA1) = _arg2;

         mlb_debug_usr(2, 0x900df00d);

         /* Succeeded */
         ret = DSS_ERR_OK;
         break;
   }

   return ret;
}


/* --------------------------------------------------------------------------- component_dss */
dsp_component_t component_dss = {
   0, /* component id, assigned in mlb_component_register() */

   /* fxns: */
   {
      NULL,       /* init */
      &loc_exec,
      NULL,       /* exec fastcall RPC */
      NULL        /* exit */
   },
   
   COMPONENT_NAME_DSS
};
