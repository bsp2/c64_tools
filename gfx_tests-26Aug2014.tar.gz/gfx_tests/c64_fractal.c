/* ----
 * ---- file   : c64_fractal.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          ARM fixpoint optimized code contributed by M-HT.
 * ----          Distributed under terms of the GNU GENERAL PUBLIC LICENSE (GPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#GPL or COPYING for further information.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 21Sep2013, 22Sep2013, 23Sep2013, 26Sep2013, 29Sep2013, 01Oct2013, 03Oct2013
 * ----          09Oct2013, 15Oct2013, 24Oct2013, 10Nov2013, 11Dec2013
 * ----
 * ----
 */

#define USE_FIXEDPOINT defined

#define USE_VIDEO defined


#define USE_GPP defined

#define USE_DSP defined

/* (note) if both GPP and DSP are used, the GPP renders the top quarter of the framebuffer */


/* if defined, render directly into the omapfb (requires USE_VIDEO).
 * if undefined, DSP renders into CMA mem, GPP renders into different (cached) offscreen buffer.
 *
 */
#define USE_OMAPFB defined


/* keep undefined for now */
//#define USE_SDL defined


/* just for some testcode */
//#define REG_ACCESS defined


//#define NUM_ITERATIONS  (0u)
//#define NUM_ITERATIONS  (1u)
//#define NUM_ITERATIONS  (10u)
//#define NUM_ITERATIONS  (5 * 60u)
//#define NUM_ITERATIONS  (20 * 60u)
#define NUM_ITERATIONS  (60 * 60u)

#define SHM_SIZE (4u * 1024u * 1024u)

#define ARGS_MEM_SIZE  (4096u)


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <math.h>

#include <unistd.h>

#ifdef USE_SDL
#include <SDL/SDL.h>
#endif /* USE_SDL */

#include <inc_libc64.h>

#include "dsp/components/demo_fractal/demo_fractal.h"

#ifdef USE_OMAPFB
#include "omapfb.h"
#endif /* USE_OMAPFB */


#ifdef REG_ACCESS
#define DSS_GFX_BA0  (0x48050480u + 0u)
#define DSS_GFX_BA1  (0x48050480u + 4u)

#define DSS_VID0_BA0  (0x480504bcu + 0u)
#define DSS_VID0_BA1  (0x480504bcu + 4u)
#endif /* REG_ACCESS */


#ifdef USE_OMAPFB
#define DSP_FB ((shm_vid.phys_addr) + 128u * 4u * dsp_args->start_y)
#else
#define DSP_FB ((shm.phys_addr) + ARGS_MEM_SIZE + 128u * 4u * dsp_args->start_y)
#endif /* USE_OMAPFB */


#ifdef USE_FIXEDPOINT
#include <stdint.h>
typedef   int32_t    _fp;
#define   _FP(A)      ((_fp) ((A) * 65536u))

//#define   _FPmpy(A,B)  ((((int64_t)(A)) * (B)) / 65536u)
#define   _FPmpy(A,B)  ((((int64_t)(A)) * (B)) >> 16u)
#define   _FPdiv(A,B)  ((((int64_t)(A)) * 65536u) / (B))
#endif


/*--------------------------------------------------------------------------- module vars */
static dsp_component_id_t compid_demo_fractal;

#ifdef USE_DSP
static dsp_mem_region_t shm;
#endif

#ifdef USE_OMAPFB
static dsp_mem_region_t shm_vid;
#endif /* USE_OMAPFB */

static demo_fractal_args_t gpp_args;

#ifdef USE_DSP
static demo_fractal_args_t *dsp_args;
#endif /* USE_DSP */

static float angle_i;
static float angle_j;

static sUI it_depth;

#ifdef USE_VIDEO
#ifdef USE_SDL
static SDL_Surface *sdl_surf_screen;
#endif /* USE_SDL */

#ifdef USE_GPP
sU32 gpp_fb[128 * 128];
#endif /* USE_GPP */

/* for the effect to look more nicely. _NOT_ for benchmarking.. */
static sBool b_vsync = 0;
#endif /* USE_VIDEO */


/*--------------------------------------------------------------------------- loc_lazy_load_components() */
sBool loc_lazy_load_components(void) {
   sBool ret;

   ret = S_FALSE;

   if(0 == dsp_component_load(NULL, COMPONENT_NAME_DEMO_FRACTAL, &compid_demo_fractal))
   {
      /* Succeeded */
      ret = S_TRUE;
   }

   return ret;
}


/*--------------------------------------------------------------------------- loc_video_init() */
#ifdef USE_VIDEO
static sBool loc_video_init(void) {
   sBool ret;

#ifdef USE_SDL
/*    setenv("SDL_VIDEODRIVER",     "omapdss", 1);  // select notaz' Pandora SDL driver (-> SDL_Init() crashes. why?)*/
/*    printf("xxx loc_video_init 2\n"); */

/*    setenv("SDL_OMAP_LAYER_SIZE", "pixelperfect", 1); */
/*    setenv("SDL_OMAP_LAYER_SIZE", "pixelperfect", 1); */
/*    setenv("SDL_OMAP_VSYNC",      "1", 1); */
#endif /* USE_SDL */


#ifdef REG_ACCESS
   {
      sU32 val;
      
      //if(0 == dsp_reg_read_32(DSS_VID0_BA0, &val))
      if(0 == dsp_reg_read_32(DSS_GFX_BA0, &val))
         //if(0 == dsp_reg_read_32(0x48050000u, &val))
      {
         printf("xxx desktop fbaddr=0x%08x\n", val);
      }
      else
      {
         log_printf(LOG_ERROR "dsp_reg_read_32() failed.\n");
      }
   }
#endif /* REG_ACCESS */


#ifdef USE_SDL
   ///if(SDL_Init(SDL_INIT_EVERYTHING) >= 0)
   if(SDL_Init(SDL_INIT_VIDEO) >= 0)
   {
      log_printf(LOG_DEBUG "SDL_Init() ok\n");
#endif /* USE_SDL */

#ifdef USE_OMAPFB
      if(omapfb_init(0, 0, // position
                     128, 128,
                     //128*3, 128*3, // zoomed size
                     800, 480, // zoomed size
                     128, 128, // virtual size
                     32,
                     S_TRUE  /* disable desktop layer */
                     )
         )
      {
         shm_vid = omapfb_plane_get_dsp_mem(1);
#endif /* USE_OMAPFB */

         
#ifdef USE_SDL
         //sdl_surf_screen = SDL_SetVideoMode(800, 480, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
         sdl_surf_screen = SDL_SetVideoMode(800, 480, 32, SDL_HWSURFACE);
         
         if(NULL != sdl_surf_screen)
         {
            log_printf(LOG_DEBUG "SDL_SetVideoMode() ok. w=%d h=%d pixels=0x%p pitch=%u\n",
                       sdl_surf_screen->w,
                       sdl_surf_screen->h,
                       sdl_surf_screen->pixels,
                       sdl_surf_screen->pitch
                       );
#endif /* USE_SDL */       
            

#ifdef REG_ACCESS
            {
               sU32 val;

               //if(0 == dsp_reg_read_32(DSS_VID0_BA0, &val))
               if(0 == dsp_reg_read_32(DSS_GFX_BA0, &val))
                  //if(0 == dsp_reg_read_32(0x48050000u, &val))
               {
                  printf("xxx SDL fbaddr=0x%08x\n", val);
               }
               else
               {
                  log_printf(LOG_ERROR "dsp_reg_read_32() failed.\n");
               }
            }
#endif /* REG_ACCESS */
            
            
            /* Succeeded */
            ret = S_TRUE;
#ifdef USE_SDL
         }
         else
         {
            /* Failed: SDL_SetVideoMode() */
            log_printf(LOG_ERROR "SDL_SetVideoMode() failed.\n");
            
            ret = S_FALSE;
         }
#endif /* USE_SDL */

#ifdef USE_OMAPFB
      }
      else
      {
         /* Failed: omapfb_init() */
         log_printf(LOG_ERROR "omapfb_init() failed.\n");
         
         ret = S_FALSE;
      }
#endif /* USE_OMAPFB */

#ifdef USE_SDL
      SDL_Quit();
   }
   else
   {
      /* Failed: SDL_Init() */
      log_printf(LOG_ERROR "SDL_Init() failed.\n");

      ret = S_FALSE;
   }
#endif /* USE_SDL */
      
   return ret;
}
#endif /* USE_VIDEO */


/*--------------------------------------------------------------------------- loc_video_exit() */
#ifdef USE_VIDEO
static void loc_video_exit(void) {

#ifdef USE_SDL
   SDL_Quit();
#endif /* USE_SDL */

#ifdef USE_OMAPFB
   omapfb_exit();
#endif /* USE_OMAPFB */
}

#endif /* USE_VIDEO */


/*--------------------------------------------------------------------------- loc_init() */
static void loc_init(void) {

   angle_i  = 0.0f;
   angle_j  = 0.26854f;
   it_depth = 24;
   
   gpp_args.start_x = 0;
   gpp_args.start_y = 0;
#ifdef USE_GPP
   gpp_args.framebuffer.data  = (sU32*) gpp_fb;
#endif
   gpp_args.framebuffer.w     = 128;
#ifdef USE_DSP
   //gpp_args.framebuffer.h     = (128 * 2) / 3;
#ifdef USE_GPP
   gpp_args.framebuffer.h     = (128  / 2);
   //gpp_args.framebuffer.h     = (128 * 2)  / 3;
#else
   gpp_args.framebuffer.h     = 0;
#endif /* USE_GPP */
#else
   gpp_args.framebuffer.h     = 128;
#endif /* USE_DSP */
   gpp_args.framebuffer.pitch = 128 * 4;
   
#ifdef USE_DSP   
   dsp_args = (demo_fractal_args_t *) shm.virt_addr;
   
   dsp_args->start_x = 0;
   dsp_args->start_y = gpp_args.framebuffer.h;
   dsp_args->framebuffer.data  = (sU32*)(DSP_FB);
   dsp_args->framebuffer.w     = 128;
   dsp_args->framebuffer.h     = (128 - gpp_args.framebuffer.h);
   dsp_args->framebuffer.pitch = 128 * 4;
#endif /* USE_DSP */
}


/*--------------------------------------------------------------------------- loc_dss_gfx_addr_set() */
#ifdef USE_VIDEO
#ifdef REG_ACCESS
static void loc_dss_gfx_addr_set(sU32 _even, sU32 _odd) {

   log_printf(LOG_TRACE "loc_dss_gfx_addr_set: even=0x%08x odd=0x%08x\n", _even, _odd);

   dsp_reg_write_32(DSS_GFX_BA0, _even);
   dsp_reg_write_32(DSS_GFX_BA1, _odd);
}
#endif /* REG_ACCESS */
#endif /* USE_VIDEO */


/*--------------------------------------------------------------------------- loc_frame_begin() */
//static int xxx_first = 0;
static void loc_frame_begin(void) {

   gpp_args.c1 = (float) sin(angle_i + sin(angle_i) * 3.1415*2) * 0.75f;
   gpp_args.c2 = (float) cos(angle_j) * 0.7f;

   gpp_args.iter_depth = it_depth;

   //return; // xxxxxxxxxxxxxxxxxxxxxxxxxxx

#ifdef USE_DSP
   dsp_args->c1 = gpp_args.c1;
   dsp_args->c2 = gpp_args.c2;
   dsp_args->iter_depth = it_depth;

   ///if(0 == xxx_first) // xxx debug
   {
      dsp_cache_wb(shm.phys_addr, ARGS_MEM_SIZE);

      //xxx_first = 1;
   }
#endif /* USE_DSP */


#ifdef REG_ACCESS
   {
      sU32 val;
      
      if(0 == dsp_reg_read_32(DSS_GFX_BA0, &val))
      {
         printf("xxx SDL fbaddr=0x%08x\n", val);
      }
      else
      {
         log_printf(LOG_ERROR "dsp_reg_read_32() failed.\n");
      }
   }
#endif
}


/*--------------------------------------------------------------------------- loc_frame_process_gpp() */
#ifdef USE_GPP
static void loc_frame_process_gpp(void) {
#ifdef USE_FIXEDPOINT
   _fp xx;
   _fp yy;
   _fp c1 = _FP(gpp_args.c1);
   _fp c2 = _FP(gpp_args.c2);
   _fp fp_start_x = _FP((float)gpp_args.start_x);
   _fp fp_start_y = _FP((float)gpp_args.start_y);
   _fp s_xx = _FPdiv(_FP(1.0f), _FP((float)(128 >> 2)));
   _fp s_yy = _FPdiv(_FP(1.0f), _FP((float)(128 >> 2)));
   _fp c_yy = _FP(-1.8f) + _FPmpy(s_yy, fp_start_y);
   sUI ly = 0;
   sUI iter;
   sUI di = 0;
   sUI cx;
   sUI cy;
   sU32 *d = gpp_args.framebuffer.data;
   sU32 itd = gpp_args.iter_depth;

   ///printf("xxx c_yy=%f\n", c_yy/65536.0f);

   for(cy=0; cy<gpp_args.framebuffer.h; cy++)
   {
      _fp c_xx = _FP(-2.0f) + _FPmpy(fp_start_x, s_xx);

      for(cx=0; cx<gpp_args.framebuffer.w; cx++)
      {
         _fp qxx, qyy, qxxyy;

         qxx   = _FPmpy(c_xx, c_xx);
         qyy   = _FPmpy(c_yy, c_yy);
         xx    = c_xx;
         yy    = c_yy;
         qxxyy = qxx + qyy;

         for(iter=0; (iter < itd) && (qxxyy <= _FP(4.0f)) ; iter++)
         {
            yy    = _FPmpy(_FP(2.0f), _FPmpy(xx, yy)) + c2;
            xx    = qxx - qyy + c1;
            qxx   = _FPmpy(xx, xx);
            qyy   = _FPmpy(yy, yy);
            qxxyy = qxx + qyy;
         }

         {
            sU32 c8;
            sU32 c32;

            c8 = (iter << 3);

            c32 = (ly + (c8 << 1));

            if(c32 > 255)
            {
               c32 = 255;
            }

            c32 = (255u << 24) | (c8 << 16) | (c8 << 8) | c32;

            d[di++] = c32;
         }

         c_xx += s_xx;
      } /* loopy x */

      c_yy += s_yy;
      ly++;

      di += (gpp_args.framebuffer.pitch >> 2) - gpp_args.framebuffer.w;

   } /* loop y */
#else
   float xx;
   float yy;
   float c1 = gpp_args.c1;
   float c2 = gpp_args.c2;
   float s_xx = 1.0f / ((float)(128 >> 2));
   float s_yy = 1.0f / ((float)(128 >> 2));
   float c_yy = -1.8f + s_yy * gpp_args.start_y;
   sUI ly = 0;
   sUI iter;
   sUI di = 0;
   sUI cx;
   sUI cy;
   sU32 *d = gpp_args.framebuffer.data;
   sU32 itd = gpp_args.iter_depth;

  
   for(cy=0; cy<gpp_args.framebuffer.h; cy++)
   {
      float c_xx = -2.0f + gpp_args.start_x * s_xx;
      
      for(cx=0; cx<gpp_args.framebuffer.w; cx++)
      {
         float qxx, qyy, qxxyy;
         
         qxx   = c_xx * c_xx;
         qyy   = c_yy * c_yy;
         xx    = c_xx;
         yy    = c_yy;
         qxxyy = qxx + qyy;
         
         for(iter=0; (iter < itd) && (qxxyy <= 4.0f) ; iter++)
         {
            yy    = 2.0f * xx * yy + c2;
            xx    = qxx - qyy + c1;
            qxx   = xx * xx;
            qyy   = yy * yy;
            qxxyy = qxx + qyy;
         }
         
         {
            sU32 c8;
            sU32 c32;

            c8 = (iter << 3);

            c32 = (ly + (c8 << 1));

            if(c32 > 255)
            {
               c32 = 255;
            }
         
            c32 = (255u << 24) | (c8 << 16) | (c8 << 8) | c32;
         
            d[di++] = c32;
         }
         
         c_xx += s_xx;
      } /* loopy x */
      
      c_yy += s_yy;
      ly++;

      di += (gpp_args.framebuffer.pitch >> 2) - gpp_args.framebuffer.w;

   } /* loop y */
#endif /* USE_FIXPOINT */
}
#endif /* USE_GPP */


/*--------------------------------------------------------------------------- loc_frame_process_dsp() */
#ifdef USE_DSP
static void loc_frame_process_dsp(void) {
   dsp_msg_t msg;

   DSP_MSG_INIT(&msg, compid_demo_fractal, DEMO_FRACTAL_CMD_PROCESS, shm.phys_addr, 0);

   //printf("xxx sending vid phys=0x%08x\n", shm_vid.phys_addr);

   dsp_rpc_send(&msg);
}
#endif /* USE_DSP */


/*--------------------------------------------------------------------------- loc_frame_process() */
static void loc_frame_process(void) {
#ifdef USE_DSP
   dsp_msg_t reply;
#endif /* USE_DSP */

#ifdef USE_DSP
   loc_frame_process_dsp();
#endif /* USE_DSP */

#ifdef USE_GPP
   loc_frame_process_gpp();
#else
   usleep(2*1000);
#endif /* USE_GPP */

#ifdef USE_DSP
   /* Sync with DSP */
   dsp_rpc_recv(&reply);

#if 0
   dsp_debug_internal_print();
#endif

#endif /* USE_DSP */
}


/*--------------------------------------------------------------------------- loc_frame_end() */
static void loc_frame_end(void) {

#ifndef USE_OMAPFB
   dsp_cache_inv((sU32)(DSP_FB), 128 * 4 * dsp_args->framebuffer.h);
   ////dsp_cache_wbinv((sU32)(DSP_FB), 128 * 4 * dsp_args->framebuffer.h);
#endif /* USE_OMAPFB */


#ifdef USE_VIDEO
#ifdef USE_GPP
   /* ugly: copy pixeldata to actual framebuffer */
   {
      sUI y;
      sU8 *s = (sU8*) gpp_fb;
#ifdef USE_SDL
      sU8 *d = sdl_surf_screen->pixels;
#else
      sU8 *d = (sU8*) shm_vid.virt_addr;
#endif /* USE_SDL */

      for(y=0; y<gpp_args.framebuffer.h; y++)
      {
         memcpy(d, s, 128*4);

         s += 128*4;
#ifdef USE_SDL
         d += sdl_surf_screen->pitch;
#else
         d += 128*4;
#endif /* USE_SDL */
      }
   }
#endif

   /* crashes the whole system if called too frequently: 
    *  (DISPC does not seem to like frequent BA0/1 reg access???!!!)
    */
   //SDL_Flip(sdl_surf_screen);

/*    loc_dss_gfx_addr_set(shm.phys_addr + ARGS_MEM_SIZE, */
/*                          shm.phys_addr + ARGS_MEM_SIZE */
/*                          ); */

   //usleep(16*1000);

   if(b_vsync)
   {
      omapfb_vsync();
   }
#endif /* USE_VIDEO */


   angle_i += 0.008f;

   if(angle_i >= 3.1415*2)
   {
      angle_i -= 3.1415*2;
   }

   angle_j += 0.009485f;

   if(angle_j >= 3.1415*2)
   {
      angle_j -= 3.1415*2;
   }
}


/*--------------------------------------------------------------------------- loc_exit() */
static void loc_exit(void) {
}


/*--------------------------------------------------------------------------- main() */
int main(int argc, char**argv) {
   int ret;

   if(LOG_DEBUG_LEVEL(20))
   {
      log_printf(LOG_TRACE "main\n");
   }

   if(0 == osal_init(
#ifdef REG_ACCESS
         S_TRUE  /* root */
#else
         S_FALSE /* user */
#endif /* REG_ACCESS */
                     )
      )
   {
#ifdef REG_ACCESS
      ret = dsp_init_root();
#else
      ret = 0;
#endif /* REG_ACCESS */

      if(0 == ret)
      {
         /* Open client connection */
#ifdef USE_DSP
         ret = dsp_open();
#endif /* USE_DSP */
         
         if(LOG_DEBUG_LEVEL(20))
         {
            log_printf(LOG_TRACE "main 2\n");
         }
         
         if(0 == ret)
         {
#if 0
            if(LOG_DEBUG_LEVEL(10))
            {
               dsp_debug_internal_print();
            }
#endif
         
            if(LOG_DEBUG_LEVEL(20))
            {
               log_printf(LOG_TRACE "main 3\n");
            }

        
            ret = 0;
         
            /* Allocate contiguous memory block */
#ifdef USE_DSP
            shm = dsp_shm_alloc(DSP_CACHE_R, SHM_SIZE);

            if(0 != shm.size)
#endif /* USE_DSP */
            {
               if(LOG_DEBUG_LEVEL(20))
               {
                  log_printf(LOG_TRACE "main 4\n");
               }
            
               if(LOG_DEBUG_LEVEL(20))
               {
                  log_printf(LOG_TRACE "main 5\n");
               }
            
               {
                  sUI i;
                  sU32 tStart;
                  sU32 tEnd;
               
                  if(LOG_DEBUG_LEVEL(20))
                  {
                     log_printf(LOG_TRACE "main 6\n");
                  }

#ifdef USE_VIDEO
                  if(loc_video_init())
#endif /* USE_VIDEO */
                  {
                     if(LOG_DEBUG_LEVEL(20))
                     {
                        log_printf(LOG_TRACE "main 7\n");
                     }

#if 0
                     usleep(1000*17); /* (note) too frequent reg access seems to cause system freezes */
                     loc_dss_gfx_addr_set(shm_vid.phys_addr + ARGS_MEM_SIZE,
                                          shm_vid.phys_addr + ARGS_MEM_SIZE
                                          );
#endif

#ifdef USE_DSP
                     if(loc_lazy_load_components())
#endif /* USE_DSP */
                     {
                        loc_init();
                        
                        tStart = osal_milliseconds_get();
                        
                        for(i=0; i<NUM_ITERATIONS; i++)
                        {
#ifndef USE_VIDEO
                           log_printf(".");
#endif /* !USE_VIDEO */
                           
                           loc_frame_begin();
                           
                           loc_frame_process();
                           
                           loc_frame_end();
                           
                        }
                        
#ifndef USE_VIDEO
                        log_printf("\n");
#endif /* !USE_VIDEO */
                        
                        tEnd = osal_milliseconds_get();
                        
                        log_printf(LOG_INFO "%u iterations in %u millisecs.\n", NUM_ITERATIONS, (tEnd - tStart));
                        
                        loc_exit();
                     }
#ifdef USE_DSP
                     else
                     {
                        /* Failed: loc_lazy_load_components() */
                        log_printf(LOG_ERROR "failed to load/query required DSP components.\n");
                     }
#endif /* USE_DSP */
                  
                     usleep(1000000 * 1);

#ifdef USE_VIDEO                  
                     loc_video_exit();
#endif /* USE_VIDEO */
                  }
               }
            
#ifdef USE_DSP
               /* Free contiguous memory block */
               dsp_shm_free(shm);
#endif /* USE_DSP */
            
            } /* if dsp_shm_init() */
#ifdef USE_DSP
            else
            {
               ret = 10;
            }
#endif /* USE_DSP */
         
#ifdef USE_DSP
            /* Disconnect client */
            dsp_close();
#endif /* USE_DSP */
         
         } /* if dsp_open() */
#ifdef USE_DSP
         else
         {
            ret = 10;
         }
#endif /* USE_DSP */

#ifdef REG_ACCESS
         dsp_exit_root();
#endif

      } /* if dsp_init_root() */
      else
      {
         ret = 10;
      }

   } /* if osal_init() */
   else
   {
      ret = 10;
   }

   return ret;
}
