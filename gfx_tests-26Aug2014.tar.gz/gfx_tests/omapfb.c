/* ----
 * ---- file   : omapfb.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          Distributed under terms of the LESSER GNU GENERAL PUBLIC LICENSE (LGPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#GPL or COPYING for further information.
 * ----
 * ---- info   : Wrapper / abstraction layer for OmapFB access on Open Pandora (used for c64 tools examples).
 * ----
 * ---- changed: 22Sep2013, 24Oct2013, 10Nov2013
 * ----
 * ----
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <math.h>

#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>

#include <linux/fb.h>
#include <linux/omapfb.h>

#include "../include/types.h"
#include "../include/log.h"
#include "../include/dsp_common.h"


#include "omapfb.h"


#define NUM_PLANES 3


/*--------------------------------------------------------------------------- module vars */
static int fd[NUM_PLANES] = { -1, -1, -1 };

struct omapfb_plane_info pi[NUM_PLANES];
struct omapfb_mem_info   mi[NUM_PLANES];
struct fb_var_screeninfo vi[NUM_PLANES];
struct fb_fix_screeninfo fi[NUM_PLANES];

dsp_mem_region_t dsp_mem[NUM_PLANES];

static sUI default_plane_idx = 1;

static struct omapfb_color_key orig_ckey;


/*--------------------------------------------------------------------------- loc_open_devs() */
static sBool loc_open_devs(void) {
   sBool ret;

   fd[0] = open("/dev/fb0", O_RDWR);

   if(fd[0] > 0)
   {
      fd[1] = open("/dev/fb1", O_RDWR);
      
      if(fd[1] > 0)
      {
         fd[2] = open("/dev/fb2", O_RDWR);
         
         /* Succeeded */
         ret = S_TRUE;

         if(fd[2] > 0)
         {
            /* (note) opening fb2 requires root privileges */
         }
         else
         {
            /* Failed: open() */
            log_printf(LOG_WARN "omapfb_init: failed to open \"/dev/fb2\".\n");

#if 0            
            ret = S_FALSE;
            
            close(fd[1]);
            fd[1] = -1;

            close(fd[0]);
            fd[0] = -1;
#endif
         }
      }
      else
      {
         /* Failed: open() */
         log_printf(LOG_ERROR "omapfb_init: failed to open \"/dev/fb1\".\n");
         
         ret = S_FALSE;

         close(fd[0]);
         fd[0] = -1;
      }
   }
   else
   {
      /* Failed: open() */
      log_printf(LOG_ERROR "omapfb_init: failed to open \"/dev/fb0\".\n");

      ret = S_FALSE;
   }

   return ret;
}


/*--------------------------------------------------------------------------- loc_close_devs() */
static void loc_close_devs(void) {
   sUI i;

   for(i=0; i<NUM_PLANES; i++)
   {
      if(-1 != fd[i])
      {
         close(fd[i]);
         fd[i] = -1;
      }
   }

}


/*--------------------------------------------------------------------------- omapfb_plane_enable() */
sBool omapfb_plane_enable(sUI _planeIdx, sBool _bEnabled) {
   int ret;
   int r;

   r = ioctl(fd[_planeIdx], OMAPFB_QUERY_PLANE, &pi[_planeIdx]);

   if(0 == r)
   {
      pi[_planeIdx].enabled = (__u8) _bEnabled;
      
      r = ioctl(fd[_planeIdx], OMAPFB_SETUP_PLANE, &pi);
      
      if(0 == r)
      {
         /* Succeeded */
         log_printf(LOG_INFO "omapfb_plane_enable: ok, plane %u is now %s.\n", 
                    _planeIdx,
                    _bEnabled ? "enabled" : "disabled"
                    );

         ret = S_TRUE;
      }
      else
      {
         /* Failed: ioctl */
         log_printf(LOG_ERROR "omapfb_plane_enable: ioctl() [SETUP_PLANE] failed. errno=%d (\"%s\").\n",
                    errno, strerror(errno)
                    );
         
         ret = S_FALSE;
      }
   }
   else
   {
      /* Failed: ioctl */
      log_printf(LOG_ERROR "omapfb_plane_enable: ioctl() [QUERY_PLANE] failed. errno=%d (\"%s\").\n",
                 errno, strerror(errno)
                 );
      
      ret = S_FALSE;
   }
   
   return ret;
}


/*--------------------------------------------------------------------------- omapfb_plane_setup() */
sBool omapfb_plane_setup(sUI _planeIdx,
                         sUI _px, sUI _py,
                         sUI _w, sUI _h,
                         sUI _zoomedW, sUI _zoomedH,
                         sUI _vw, sUI _vh,
                         sUI _bitsPerPixel
                         ) {
   int ret;
   int r;

   r = ioctl(fd[_planeIdx], OMAPFB_QUERY_PLANE, &pi[_planeIdx]);

   if(0 == r)
   {
      pi[_planeIdx].enabled = 0; /* must be disabled during setup */

      r = ioctl(fd[_planeIdx], OMAPFB_SETUP_PLANE, &pi[_planeIdx]);

      if(0 == r)
      {
         /* Succeeded */
         log_printf(LOG_INFO "omapfb_plane_setup: ok, plane %u is now disabled.\n", _planeIdx);

         r = ioctl(fd[_planeIdx], OMAPFB_QUERY_MEM, &mi[_planeIdx]);
         
         if(0 == r)
         {
            mi[_planeIdx].size = (_vw * _vh * (_bitsPerPixel >> 3));
            
            r = ioctl(fd[_planeIdx], OMAPFB_SETUP_MEM, &mi[_planeIdx]);
            
            if(0 == r)
            {
               pi[_planeIdx].pos_x      = _px;
               pi[_planeIdx].pos_y      = _py;
               pi[_planeIdx].out_width  = _zoomedW;
               pi[_planeIdx].out_height = _zoomedH;
               pi[_planeIdx].enabled    = 1;

               r = ioctl(fd[_planeIdx], OMAPFB_SETUP_PLANE, &pi[_planeIdx]);

               if(0 == r)
               {
                  log_printf(LOG_INFO "omapfb_plane_setup: OK, plane %u is configured size=(%u; %u) geo=(%u; %u; %u; %u) virt=(%u; %u) bpp=%u.\n",
                             _planeIdx,
                             _w, _h,
                             _px, _py,
                             _zoomedW, _zoomedH,
                             _vw, _vh,
                             _bitsPerPixel
                             );

                  /* Succeeded */
                  ret = S_TRUE;
               }
               else
               {
                  /* Failed: ioctl */
                  log_printf(LOG_ERROR "omapfb_plane_setup: ioctl() [SETUP_MEM] failed. errno=%d (\"%s\").\n",
                             errno, strerror(errno)
                             );
                  
                  ret = S_FALSE;
               }
            }
            else
            {
               /* Failed: ioctl */
               log_printf(LOG_ERROR "omapfb_plane_setup: ioctl() [SETUP_MEM] failed. errno=%d (\"%s\").\n",
                          errno, strerror(errno)
                          );
               
               ret = S_FALSE;
            }
         }
         else
         {
            /* Failed: ioctl */
            log_printf(LOG_ERROR "omapfb_plane_setup: ioctl() [QUERY_MEM] failed. errno=%d (\"%s\").\n",
                       errno, strerror(errno)
                       );
            
            ret = S_FALSE;
         }
      }
      else
      {
         /* Failed: ioctl */
         log_printf(LOG_ERROR "omapfb_plane_setup: ioctl() [SETUP_PLANE] failed. errno=%d (\"%s\").\n",
                    errno, strerror(errno)
                    );
         
         ret = S_FALSE;
      }
   }
   else
   {
      /* Failed: ioctl */
      log_printf(LOG_ERROR "omapfb_plane_setup: ioctl() [QUERY_PLANE] failed. errno=%d (\"%s\").\n",
                 errno, strerror(errno)
                 );

      ret = S_FALSE;
   }
   
   return ret;
}


/*--------------------------------------------------------------------------- omapfb_plane_setup_dsp_mem() */
sBool omapfb_plane_setup_dsp_mem(sUI _planeIdx,
                                 sUI _w,  sUI _h,
                                 sUI _vw, sUI _vh,
                                 sUI _bitsPerPixel
                                 ) {
   int r;
   sBool ret;

   r = ioctl(fd[_planeIdx], FBIOGET_VSCREENINFO, &vi[_planeIdx]);

   if(0 == r)
   {
      vi[_planeIdx].xres           = _w;
      vi[_planeIdx].yres           = _h;
      vi[_planeIdx].xres_virtual   = _vw;
      vi[_planeIdx].yres_virtual   = _vh;
      vi[_planeIdx].bits_per_pixel = _bitsPerPixel;

      r = ioctl(fd[_planeIdx], FBIOPUT_VSCREENINFO, &vi[_planeIdx]);

      if(0 == r)
      {
         r = ioctl(fd[_planeIdx], FBIOGET_FSCREENINFO, &fi[_planeIdx]);

         if(0 == r)
         {
            void *virtAddr;

            virtAddr = mmap(NULL,
                            fi[_planeIdx].smem_len,
                            PROT_READ | PROT_WRITE,
                            MAP_SHARED,
                            fd[_planeIdx],
                            0
                            );

            if(MAP_FAILED != virtAddr)
            {
               dsp_mem[_planeIdx].phys_addr = (sU32)fi[_planeIdx].smem_start;
               dsp_mem[_planeIdx].virt_addr = (sU32)virtAddr;
               dsp_mem[_planeIdx].size      = fi[_planeIdx].smem_len;

               /* Succeeded */
               log_printf(LOG_INFO "omapfb_plane_setup_dsp_mem: plane %u virt_addr=0x%08x, phys_addr=0x%08x size=0x%08x (req=0x%08x).\n",
                          _planeIdx,
                          dsp_mem[_planeIdx].virt_addr,
                          dsp_mem[_planeIdx].phys_addr,
                          dsp_mem[_planeIdx].size,
                          (_vw * _vh * (_bitsPerPixel >> 3))
                          );
              
               ret = S_TRUE;
            }
            else
            {
               log_printf(LOG_ERROR "omapfb_plane_setup_dsp_mem: mmap() failed (size=%u bytes). errno=%d (\"%s\").\n",
                          fi[_planeIdx].smem_len,
                          errno, strerror(errno)
                          );
               
               ret = S_FALSE;
            }
         }
         else
         {
            log_printf(LOG_ERROR "omapfb_plane_setup_dsp_mem: ioctl() [FBIOGET_FSCREENINFO] failed. errno=%d (\"%s\").\n",
                       errno, strerror(errno)
                       );
            
            ret = S_FALSE;
         }
      }
      else
      {
         log_printf(LOG_ERROR "omapfb_plane_setup_dsp_mem: ioctl() [FBIOPUT_VSCREENINFO] failed. errno=%d (\"%s\").\n",
                    errno, strerror(errno)
                    );
         
         ret = S_FALSE;
      }
   }
   else
   {
      log_printf(LOG_ERROR "omapfb_plane_setup_dsp_mem: ioctl() [FBIOGET_VSCREENINFO] failed. errno=%d (\"%s\").\n",
                 errno, strerror(errno)
                 );

      ret = S_FALSE;
   }

   return ret;
}


/*--------------------------------------------------------------------------- omapfb_plane_get_dsp_mem() */
dsp_mem_region_t omapfb_plane_get_dsp_mem(sUI _planeIdx) {

   return dsp_mem[_planeIdx];
}


/*--------------------------------------------------------------------------- omapfb_plane_offset() */
sBool omapfb_plane_offset(sUI _planeIdx, sU32 _offsetX, sU32 _offsetY) {
   int r;

   vi[_planeIdx].xoffset = _offsetX;
   vi[_planeIdx].yoffset = _offsetY;

   r = ioctl(fd[_planeIdx], FBIOPUT_VSCREENINFO, &vi[_planeIdx]);

   if(0 != r)
   {
      log_printf(LOG_ERROR "omapfb_plane_offset: ioctl() [FBIOPUT_VSCREENINFO] failed. errno=%d (\"%s\").\n",
                 errno, strerror(errno)
                 );
   }

   return (0 == r);
}


/*--------------------------------------------------------------------------- omapfb_init() */
sBool omapfb_init(sUI _px, sUI _py,
                  sUI _w,  sUI _h,
                  sUI _zoomedW, sUI _zoomedH,
                  sUI _vw,  sUI _vh,
                  sUI _bitsPerPixel,
                  sBool _bDisableDesktopLayer
                  ) {
   sBool ret;

   memset(dsp_mem, 0, sizeof(dsp_mem_region_t) * NUM_PLANES);

   if(loc_open_devs())
   {
      if(0 != _w)
      {
         sBool bOk;
         
         if(0 == ioctl(fd[2], OMAPFB_GET_COLOR_KEY, &orig_ckey))
         {
            if(_bDisableDesktopLayer)
            {
               bOk = omapfb_plane_enable(0, S_FALSE);
            }
            else
            {
               bOk = S_TRUE;
            }
            
            if(bOk)
            {
               if(omapfb_plane_setup(default_plane_idx, _px, _py, _w, _h, _zoomedW, _zoomedH, _vw, _vh, _bitsPerPixel))
               {
                  if(omapfb_plane_setup_dsp_mem(default_plane_idx, _w, _h, _vw, _vh, _bitsPerPixel))
                  {
                     log_printf(LOG_INFO "omapfb_init: OK.\n");
                     
                     /* Succeeded */
                     ret = S_TRUE;
                  }
                  else
                  {
                     log_printf(LOG_ERROR "omapfb_plane_setup_dsp_mem");
                     ret = S_FALSE;
                  }
               }
               else
               {
                  log_printf(LOG_ERROR "omapfb_plane_setup 1\n");
                  ret = S_FALSE;
               }
            }
            else
            {
               log_printf(LOG_ERROR "omapfb_plane_enable 0\n");
               ret = S_FALSE;
            }
         }
         else
         {
            log_printf(LOG_ERROR "omapfb_init: ioctl[OMAPFB_GET_COLOR_KEY] failed. errno=%d (\"%s\").\n",
                       errno, strerror(errno)
                       );
            ret = S_FALSE;
         }
      } /* if 0 != w */
      else
      {
         /* Don't create a layer */
         ret = S_TRUE;
      }
   }
   else
   {
      log_printf(LOG_ERROR "loc_open_devs\n");
      ret = S_FALSE;
   }

   return ret;
}


/*--------------------------------------------------------------------------- omapfb_exit() */
void omapfb_exit(void) {
   sUI i;

   /* Restore original color key */
   (void)ioctl(fd[2], OMAPFB_SET_COLOR_KEY, &orig_ckey);

   (void)omapfb_plane_enable(default_plane_idx, S_FALSE);

   for(i=0; i<NUM_PLANES; i++)
   {
      if(0/*NULL*/ != dsp_mem[i].virt_addr)
      {
         munmap((void*)dsp_mem[i].virt_addr, dsp_mem[i].size);

         log_printf(LOG_DEBUG "omapfb_exit: [%u] unmapped %u bytes @virt=0x%08x (phys=0x%08x).\n",
                    i,
                    dsp_mem[i].size,
                    dsp_mem[i].virt_addr,
                    dsp_mem[i].phys_addr
                    );
      }
   }

   (void)omapfb_plane_enable(0, S_TRUE);

   loc_close_devs();
}


/*--------------------------------------------------------------------------- omapfb_vsync() */
void omapfb_vsync(void) {

   ioctl(fd[1], OMAPFB_WAITFORVSYNC);
}


/*--------------------------------------------------------------------------- omapfb_set_default_plane_idx() */
void omapfb_set_default_plane_idx(sUI _planeIdx) {
   if(_planeIdx < 3u)
   {
      default_plane_idx = _planeIdx;

      log_printf(LOG_INFO "omapfb: default plane idx set to %u\n", _planeIdx);
   }
}


/*--------------------------------------------------------------------------- omapfb_color_key_set() */
sBool omapfb_color_key_set(sU32 _colorKey, sBool _bVidSrc) {
   struct omapfb_color_key ckey;
   int r;
   
   r = ioctl(fd[2], OMAPFB_GET_COLOR_KEY, &ckey);

   if(0 == r)
   {
      ckey.trans_key = _colorKey;
      ckey.key_type  = _bVidSrc ? OMAPFB_COLOR_KEY_VID_SRC : OMAPFB_COLOR_KEY_GFX_DST;

      r = ioctl(fd[2], OMAPFB_SET_COLOR_KEY, &ckey);

      if(0 == r)
      {
         /* Succeeded */
      }
      else
      {
         log_printf(LOG_ERROR "omapfb_color_key_set: ioctl[OMAPFB_SET_COLOR_KEY] failed. errno=%d (\"%s\").\n",
                    errno, strerror(errno)
                    );
      }
   }
   else
   {
      log_printf(LOG_ERROR "omapfb_color_key_set: ioctl[OMAPFB_GET_COLOR_KEY] failed. errno=%d (\"%s\").\n",
                 errno, strerror(errno)
                 );
   }
   
   return (0 == r);
}
