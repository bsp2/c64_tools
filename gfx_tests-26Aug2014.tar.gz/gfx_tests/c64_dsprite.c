/* ----
 * ---- file   : c64_dsprite.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          ARM fixpoint optimized code contributed by M-HT.
 * ----          Distributed under terms of the GNU GENERAL PUBLIC LICENSE (GPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#GPL or COPYING for further information.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 23Oct2013, 24Oct2013, 25Oct2013, 02Nov2013, 10Nov2013, 12Nov2013, 13Nov2013
 * ----          14Nov2013, 08Dec2013, 11Dec2013
 * ----
 * ----
 */

// please keep defined, does not compile otherwise (ATM)
#define USE_DSP defined

#define CLEAR_MODE 1

#define DOUBLEBUF defined

#define VSYNC 1

#define SLOMO 1.0f
//#define SLOMO 0.025f

#define NUM_ITERATIONS  (60u * 10u)
//#define NUM_ITERATIONS  (60u * 30u)

#define MAX_ITERATIONS (60u * 60u * 60u)


//#define NUM_SPRITES  (64u)
//#define NUM_SPRITES  (128u)
#define NUM_SPRITES  (256u)
//#define NUM_SPRITES  (384u)
//#define NUM_SPRITES  (512u)
//#define NUM_SPRITES  (768u)
//#define NUM_SPRITES  (1024u)
//#define NUM_SPRITES  (1500u)


#define MAX_SPRITES  (32768u)


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <math.h>

#include <unistd.h>

#include <inc_libc64.h>

#include "dsp/components/dsprite/dsprite.h"

#include "omapfb.h"

#define DST_W (800)
#define DST_H (480)
#define DST_HCLIP (DST_H + img_h*2)

#define DST_VW (DST_W + img_w*2)
#define DST_VHD (2 * (DST_H + img_h*2))


#define FB_VIRT_ADDR (shm_vid.virt_addr + (screen_offset_y ) * DST_VW * sizeof(sU32))
#define FB_PHYS_ADDR (shm_vid.phys_addr + (screen_offset_y ) * DST_VW * sizeof(sU32))


#define MODE_COPY            (0)
#define MODE_ALPHATEST       (1)
#define MODE_PREMUL_SRCOVER  (2)
#define MODE_SRCOVER         (3)
#define NUM_MODES            (4)


#define CLEAR_MODE_NONE (0u)
#define CLEAR_MODE_GPP  (1u)
#define CLEAR_MODE_DSP  (2u)
#define NUM_CLEAR_MODES (3u)


#define DSPRITE_DLIST_SIZE  (2 * 1024u * 1024u)


extern sU32 pandora_logo_32x32_argb32[32 * 32];
extern sU32 bullet_8x8_argb32[8 * 8];


typedef struct {
   sF32 x;
   sF32 y;
   sF32 ax;
   sF32 ay;
} sprite_dat_t;


/*--------------------------------------------------------------------------- module vars */
#define MODE_STR(a) #a
static const char *mode_names[NUM_MODES] = {
   MODE_STR(MODE_COPY),
   MODE_STR(MODE_ALPHATEST),
   MODE_STR(MODE_PREMUL_SRCOVER),
   MODE_STR(MODE_SRCOVER),
};
#undef MODE_STR

static dsp_component_id_t compid_dsprite;

static dsp_mem_region_t shm;

static dsp_mem_region_t fshm_img;
static sU32             fshm_img_phys_addr_dsp;  /* local interconnect (DSP) view */

static dsp_mem_region_t shm_vid;

/* for the effect to look more nicely. _NOT_ for benchmarking.. */
static sBool b_vsync = VSYNC;

//static sSI mode = MODE_COPY;
//static sSI mode = MODE_ALPHATEST;
static sSI mode = MODE_PREMUL_SRCOVER;
//static sSI mode = MODE_SRCOVER;

static sU32 mem_img[32 * 32];

static sprite_dat_t sprite_dat[MAX_SPRITES];

static sU32 screen_offset_y = 0;

static sU32 num_sprites = NUM_SPRITES;

static sU32 clear_mode = CLEAR_MODE_GPP;

static sU32 num_iterations = NUM_ITERATIONS;

static sF32 slomo = SLOMO;

static sU32 img_nr = 0;

static sU32 img_w;
static sU32 img_h;


/*--------------------------------------------------------------------------- loc_lazy_load_components() */
sBool loc_lazy_load_components(void) {
   sBool ret;

   ret = S_FALSE;

   if(0 == dsp_component_load(NULL, COMPONENT_NAME_DSPRITE, &compid_dsprite))
   {
      /* Succeeded */
      ret = S_TRUE;
   }

   return ret;
}


/*--------------------------------------------------------------------------- loc_video_init() */
static sBool loc_video_init(void) {
   sBool ret;

   if(omapfb_init(0, 0, // position
                  DST_W, DST_H,
                  800, 480, // zoomed size
                  DST_VW, DST_VHD, // virtual size
                  32,
                  S_TRUE  /* disable desktop layer */
                  )
      )
   {
      shm_vid = omapfb_plane_get_dsp_mem(1);

      omapfb_plane_offset(1, img_w, img_h);

      memset((void*)shm_vid.virt_addr,
             0,
             DST_VW * sizeof(sU32) * DST_VHD
             );

      
      /* Succeeded */
      ret = S_TRUE;
      
   }
   else
   {
      /* Failed: omapfb_init() */
      log_printf(LOG_ERROR "omapfb_init() failed.\n");
      
      ret = S_FALSE;
   }
   
   return ret;
}


/*--------------------------------------------------------------------------- loc_video_exit() */
static void loc_video_exit(void) {

   omapfb_exit();
}


/*--------------------------------------------------------------------------- loc_sprite_init() */
static void loc_sprite_init(void) {
   /* Init sprite data */
   sUI i;
   
   for(i=0; i<num_sprites; i++)
   {
      sprite_dat_t *spr = &sprite_dat[i];
      
      spr->x = (sF32) (rand() % (DST_VW - img_w));
      spr->y = (sF32) (rand() % (DST_HCLIP - img_h));
      
      spr->ax = (((rand() & 65535) / 16384.0f) - 2.0f) * slomo; // * (num_sprites / 2048.0f)
      spr->ay = (((rand() & 65535) / 16384.0f) - 2.0f) * slomo; // * (num_sprites / 2048.0f)
   }
}


/*--------------------------------------------------------------------------- loc_sprite_move() */
static void loc_sprite_move(void) {
   /* Move sprites */
   sUI i;
   
   for(i=0; i<num_sprites; i++)
   {
      sprite_dat_t *spr = &sprite_dat[i];
      
      spr->x += spr->ax;
      spr->y += spr->ay;

      if(spr->x >= ((sF32)(DST_VW - img_w)))
      {
         spr->x -= spr->ax;
         spr->ax = -spr->ax;
      }
      else if(spr->x < 0.0f)
      {
         spr->x -= spr->ax;
         spr->ax = -spr->ax;
      }

      if(spr->y >= ((sF32)(DST_HCLIP - img_h)))
      {
         spr->y -= spr->ay;
         spr->ay = -spr->ay;
      }
      else if(spr->y < 0.0f)
      {
         spr->y -= spr->ay;
         spr->ay = -spr->ay;
      }
   }
}


/*--------------------------------------------------------------------------- loc_init() */
static sBool loc_init(void) {
   sU32 *d = (sU32*) fshm_img.virt_addr;

   log_printf(LOG_DEBUG "fshm_img: phys_addr=0x%08x, virt_addr=0x%08x\n",
              fshm_img.phys_addr,
              fshm_img.virt_addr
              );

   fshm_img_phys_addr_dsp = dsp_physgpp_to_physdsp(fshm_img.phys_addr);

   log_printf(LOG_DEBUG "fshm_img: DSP phys_addr=0x%08x\n",
              fshm_img_phys_addr_dsp
              );

   /* Init clear-screen source data */
   memset((void*)(shm.virt_addr + DSPRITE_DLIST_SIZE*2 + img_w * sizeof(sU32) * img_h),
          0,
          DST_VW * sizeof(sU32)
          );

#if 0
   /* Create test image */
   {
      sUI x;
      sUI y;

      for(y=0; y<img_h; y++)
      {
         for(x=0; x<img_w; x++)
         {
            d[x] = (x ^ y) | ( (x*x) ^ (y*y) ) | ( ((x ^ y) & 1) ? 0xFF000000u : 0u);
         }
         
         d += img_w;
      }
   }
#endif

#if 1

   memcpy(d,
          img_nr ? bullet_8x8_argb32 : pandora_logo_32x32_argb32,
          img_w * sizeof(sU32) * img_h
          );

   /* grayscale */
   if(0 == img_nr)
   {
      sUI i;
      sU32 *s = d;

      for(i=0; i< (img_w * img_h); i++)
      {
         sU32 c = s[i];
         sU32 b = c & 255;

         c = (c & 0xFF000000u) | (b << 16) | (b << 8) | b;

         s[i] = c;
      }
   }


   /* test image (gradient) */
   if(0)
   {
      sUI i;
      sU32 *s = d;

      for(i=0; i< (img_w * img_h); i++)
      {
         sU32 c = s[i];
         sU32 l = (i >> 5) << 3;

         //c = ((c >> 3) & 0xFF000000u) | (c & 0x00FFFFFFu);
         //c = 0xFF000000u | (c & 0x00FFFFFFu);

         //c = 0x20FFFFFFu;

         c = 0x20000000u | (l << 16) | (l << 8) | l;

         s[i] = c;
      }
   }

   /* premultiply image */
   if(0)//if(MODE_PREMUL_SRCOVER == mode)
   {
      sUI i;
      sU32 *s = d;

      for(i=0; i< (img_w * img_h); i++)
      {
         sU32 c = s[i];

         sF32 a = (sF32) ((c >> 24) / 255.0f);

         sU32 r= (sU32) (((c >> 16) & 0xFFu) * a);
         sU32 g= (sU32) (((c >>  8) & 0xFFu) * a);
         sU32 b= (sU32) (((c      ) & 0xFFu) * a);

         c = (c & 0xFF000000) | (r << 16) | (g << 8) | b;

         s[i] = c;
      }
   }

#endif

   /* Copy to RAM (for GPP) */
   memcpy(mem_img,
          (void*)(fshm_img.virt_addr),
          img_w * sizeof(sU32) * img_h
          );

   /* Copy to shared RAM (for DSP) */
   memcpy((void*) (shm.virt_addr + DSPRITE_DLIST_SIZE*2),
          (void*) fshm_img.virt_addr,
          img_w * sizeof(sU32) * img_h
          );


   loc_sprite_init();

   log_printf(LOG_DEBUG "loc_init: loc_sprite_init() ok.\n");

   return S_TRUE;
}


/*--------------------------------------------------------------------------- loc_frame_begin() */
static void loc_frame_begin(void) {

#ifdef DOUBLEBUF
   /* Swap buffers */
   {
      if(0 != screen_offset_y)
      {
         screen_offset_y = 0;
      }
      else
      {
         screen_offset_y = DST_HCLIP;
      }

   }
#endif

   loc_sprite_move();

   //printf("xxx 2 FB_VIRT_ADDR=0x%08x\n", FB_VIRT_ADDR);

}


/*--------------------------------------------------------------------------- loc_clear_dsp() */
static void *loc_clear_dsp(dsprite_op_ptr_t u, sU32 dstAddrBase) {
 
   if(CLEAR_MODE_DSP == clear_mode)
   {
      u.copy->op = DSPRITE_OP_COPY;

      u.copy->sprite.src_phys_addr  = (shm.phys_addr + DSPRITE_DLIST_SIZE*2 + img_w * sizeof(sU32) * img_h);
      u.copy->sprite.src_pitch      = 0;
      u.copy->sprite.dst_phys_addr  = dstAddrBase;
      u.copy->sprite.dst_pitch      = DST_VW * 4;
      u.copy->num_bytes_x           = DST_VW * 4;
      u.copy->num_y                 = DST_HCLIP;

      u.copy++;
   }
   else if(CLEAR_MODE_GPP == clear_mode)
   {
      /* Clear screen using memcpy */
      memset((void*)(FB_VIRT_ADDR),
             0,
             DST_VW * sizeof(sU32) * DST_HCLIP
             );
   }

   return u.any;
}


/*--------------------------------------------------------------------------- loc_frame_process_copy_dsp() */
#ifdef USE_DSP
static void loc_frame_process_copy_dsp(void) {
   dsp_msg_t msg;
   dsprite_op_ptr_t u;
   sprite_dat_t *spr = sprite_dat;
   sUI i;
   sU32 dstAddrBase = FB_PHYS_ADDR;

   u.op = (dsprite_op_t*) shm.virt_addr;

   /* Clear screen using EDMA */
   u.any = loc_clear_dsp(u, dstAddrBase);

   for(i=0; i<num_sprites; i++)
   {
      sU32 dstAddr = dstAddrBase;
      sU32 x;
      sU32 y;

      u.copy->op = DSPRITE_OP_COPY;

#if 0
      x = rand() % (DST_VW - img_w);
      y = rand() % (DST_HCLIP - img_h);
#else
      x = (sU32) spr->x;
      y = (sU32) spr->y;
#endif

      dstAddr += (x * sizeof(sU32)) + (y * (DST_VW * sizeof(sU32)));
      
      u.copy->sprite.dst_phys_addr  = dstAddr;
      u.copy->sprite.dst_pitch      = DST_VW * 4;
      
      u.copy->sprite.src_phys_addr = fshm_img_phys_addr_dsp;

#if 1
      u.copy->sprite.src_pitch = img_w * 4;
      u.copy->num_bytes_x      = img_w * 4;
      u.copy->num_y            = img_h;
#else
      u.copy->sprite.src_pitch = DST_W * 4;
      u.copy->num_bytes_x      = DST_W * 4;
      u.copy->num_y            = DST_H;
#endif
      
      u.copy++;
      spr++;
   }

   u.op[0] = DSPRITE_OP_END; /* end of sprite arraylist */

   DSP_MSG_INIT(&msg, compid_dsprite, DSPRITE_CMD_PROCESS, shm.phys_addr, 0);

   dsp_rpc_send(&msg);

   usleep(2*1000);
}
#endif /* USE_DSP */


/*--------------------------------------------------------------------------- loc_frame_process_alphatest_dsp() */
#ifdef USE_DSP
static void loc_frame_process_alphatest_dsp(void) {
   dsp_msg_t msg;
   dsprite_op_ptr_t u;
   sprite_dat_t *spr = sprite_dat;
   sUI i;
   sU32 dstAddrBase = FB_PHYS_ADDR;

   u.op = (dsprite_op_t*) shm.virt_addr;

   /* Clear screen using EDMA */
   u.any = loc_clear_dsp(u, dstAddrBase);
   
   u.multi->op     = DSPRITE_OP_ALPHATEST_ARGB32;
   u.multi->w      = img_w;
   u.multi->h      = img_h;
   u.multi->num    = num_sprites;
   u.multi->ext_sz = 0;

   u.multi++;

   for(i=0; i<num_sprites; i++)
   {
      sU32 dstAddr = dstAddrBase;
      sU32 x;
      sU32 y;

      x = (sU32) spr->x;
      y = (sU32) spr->y;

      dstAddr += (x * sizeof(sU32)) + (y * (DST_VW * sizeof(sU32)));
      
      u.sprite->dst_phys_addr  = dstAddr;
      u.sprite->dst_pitch      = DST_VW * 4;

      /* Physically address as seen by DSP/EDMA (GPP sees it a different (L3) address) */
      u.sprite->src_phys_addr  = fshm_img_phys_addr_dsp;

      u.sprite->src_pitch      = img_w * 4;
      
      u.sprite++;
      spr++;
   }

   u.op[0] = DSPRITE_OP_END; /* end of sprite arraylist */

   DSP_MSG_INIT(&msg, compid_dsprite, DSPRITE_CMD_PROCESS, shm.phys_addr, 0);

   dsp_rpc_send(&msg);

   usleep(2*1000);
}
#endif /* USE_DSP */


/*--------------------------------------------------------------------------- loc_frame_process_premul_srcover_dsp() */
#ifdef USE_DSP
static void loc_frame_process_premul_srcover_dsp(void) {
   dsp_msg_t msg;
   dsprite_op_ptr_t u;
   sprite_dat_t *spr = sprite_dat;
   sUI i;
   sU32 dstAddrBase = FB_PHYS_ADDR;

   u.op = (dsprite_op_t*) shm.virt_addr;

   /* Clear screen using EDMA */
   u.any = loc_clear_dsp(u, dstAddrBase);
   
   u.multi->op     = DSPRITE_OP_PREMUL_SRCOVER_ARGB32;
   u.multi->w      = img_w;
   u.multi->h      = img_h;
   u.multi->num    = num_sprites;
   u.multi->ext_sz = 0;

   u.multi++;

   for(i=0; i<num_sprites; i++)
   {
      sU32 dstAddr = dstAddrBase;
      sU32 x;
      sU32 y;

      x = (sU32) spr->x;
      y = (sU32) spr->y;

      dstAddr += (x * sizeof(sU32)) + (y * (DST_VW * sizeof(sU32)));
      
      u.sprite->dst_phys_addr  = dstAddr;
      u.sprite->dst_pitch      = DST_VW * 4;


      /* Physically address as seen by DSP/EDMA (GPP sees it a different (L3) address) */
      u.sprite->src_phys_addr  = fshm_img_phys_addr_dsp;
      
      //u.sprite->src_phys_addr  = (shm.phys_addr + DSPRITE_DLIST_SIZE*2);

      u.sprite->src_pitch      = img_w * 4;
      
      u.sprite++;
      spr++;
   }

   u.op[0] = DSPRITE_OP_END; /* end of sprite arraylist */

   DSP_MSG_INIT(&msg, compid_dsprite, DSPRITE_CMD_PROCESS, shm.phys_addr, 0);

   dsp_rpc_send(&msg);

   usleep(2*1000);
}
#endif /* USE_DSP */


/*--------------------------------------------------------------------------- loc_frame_process_srcover_dsp() */
#ifdef USE_DSP
static void loc_frame_process_srcover_dsp(void) {
   dsp_msg_t msg;
   dsprite_op_ptr_t u;
   sprite_dat_t *spr = sprite_dat;
   sUI i;
   sU32 dstAddrBase = FB_PHYS_ADDR;

   u.op = (dsprite_op_t*) shm.virt_addr;

   /* Clear screen using EDMA */
   u.any = loc_clear_dsp(u, dstAddrBase);
   
   u.multi->op     = DSPRITE_OP_SRCOVER_ARGB32;
   u.multi->w      = img_w;
   u.multi->h      = img_h;
   u.multi->num    = num_sprites;
   u.multi->ext_sz = 0;

   u.multi++;

   for(i=0; i<num_sprites; i++)
   {
      sU32 dstAddr = dstAddrBase;
      sU32 x;
      sU32 y;

      x = (sU32) spr->x;
      y = (sU32) spr->y;

      dstAddr += (x * sizeof(sU32)) + (y * (DST_VW * sizeof(sU32)));
      
      u.sprite->dst_phys_addr  = dstAddr;
      u.sprite->dst_pitch      = DST_VW * 4;

      /* Physically address as seen by DSP/EDMA (GPP sees it a different (L3) address) */
      u.sprite->src_phys_addr  = fshm_img_phys_addr_dsp;

      //u.sprite->src_phys_addr  = (shm.phys_addr + DSPRITE_DLIST_SIZE*2);

      u.sprite->src_pitch      = img_w * 4;
      
      u.sprite++;
      spr++;
   }

   u.op[0] = DSPRITE_OP_END; /* end of sprite arraylist */

   DSP_MSG_INIT(&msg, compid_dsprite, DSPRITE_CMD_PROCESS, shm.phys_addr, 0);

   dsp_rpc_send(&msg);

   usleep(2*1000);
}
#endif /* USE_DSP */


/*--------------------------------------------------------------------------- loc_frame_process_copy_gpp() */
#ifndef USE_DSP
static void loc_frame_process_copy_gpp(void) {

#ifdef USE_DSP
   dsp_msg_t msg;
#endif
   dsprite_cmd_t *cmd;
   sUI i;

   cmd = (dsprite_cmd_t*) shm.virt_addr;

   for(i=0; i<num_sprites; i++)
   {
      sU32 dstAddr = FB_VIRT_ADDR;
      sU32 x;
      sU32 y;

      x = rand() % (DST_VW - img_w);
      y = rand() % (DST_HCLIP - img_h);

      dstAddr += (x * sizeof(sU32)) + (y * (DST_VW * sizeof(sU32)));
      
      cmd->dst_phys_addr  = dstAddr;
      cmd->dst_pitch      = DST_VW * 4;
      cmd->src_phys_addr  = (sU32)mem_img;
      cmd->src_pitch      = img_w * 4;
      cmd->num_bytes_x    = img_w * 4;
      cmd->num_y          = img_h;
      
      cmd++;
   }

   cmd->dst_phys_addr = 0u; /* end of sprite arraylist */


   cmd = (dsprite_cmd_t*) shm.virt_addr;

   for(i=0; i<num_sprites; i++)
   {
      sU8 *d = (sU8*)cmd->dst_phys_addr;
      sU8 *s = (sU8*)cmd->src_phys_addr;
      sUI y;

      for(y=0; y<cmd->num_y; y++)
      {
         memcpy(d, s, cmd->src_pitch);

         d += cmd->dst_pitch;
         s += cmd->src_pitch;
      }

      cmd++;
   }

   usleep(2*1000);
}
#endif /* !USE_DSP */


/*--------------------------------------------------------------------------- loc_frame_process() */
static void loc_frame_process(void) {

   switch(mode)
   {
      default:
      case MODE_COPY:
#ifdef USE_DSP
         loc_frame_process_copy_dsp();
#else
         loc_frame_process_copy_gpp();
#endif
         break;

      case MODE_ALPHATEST:
#ifdef USE_DSP
         loc_frame_process_alphatest_dsp();
#else
         /* (todo) write GPP fxn */
#endif
         break;

      case MODE_PREMUL_SRCOVER:
#ifdef USE_DSP
         loc_frame_process_premul_srcover_dsp();
#else
         /* (todo) write GPP fxn */
#endif
         break;

      case MODE_SRCOVER:
#ifdef USE_DSP
         loc_frame_process_srcover_dsp();
#else
         /* (todo) write GPP fxn */
#endif
         break;

   }
}


/*--------------------------------------------------------------------------- loc_frame_end() */
static void loc_frame_end(void) {

#ifdef USE_DSP
   {
      dsp_msg_t reply;
      
      /* Sync with DSP */
      dsp_rpc_recv(&reply);

      if(0 != reply.data[0].ret)
      {
         log_printf(LOG_ERROR "loc_frame_end: DSP process() returned error %u\n", reply.data[0].ret);
      }
   }
#endif

   //usleep(16*1000);

#ifdef DOUBLEBUF
   omapfb_plane_offset(1, img_w, screen_offset_y + img_h);
#endif

   if(b_vsync)
   {
      omapfb_vsync();
   }

}


/*--------------------------------------------------------------------------- loc_exit() */
static void loc_exit(void) {
}


/*--------------------------------------------------------------------------- loc_usage() */
static void loc_usage(void) {
   printf(
      "Usage: ./c64_dsprite [mode] [num_sprites] [clear_mode] [num_iterations] [speed] [vsync] [img_nr]\n"
      "\n"
      "             mode: 0=copy, 1=alphatest, 2=premul srcover + saturate, 3=srcover [default is 2]\n"
      "      num_sprites: 1..4096 [default is 256]\n"
      "       clear_mode: 0=none, 1=GPP (memcpy), 2=DSP (EDMA) [default is 1]\n"
      "   num_iterations: 1..60*60*60 (~1h at 60Hz) [default is 60*10]\n"
      "            speed: sprite movement speed scale (float value) [default is 1.0]\n"
      "            vsync: 1=on, 0=off [default is 1]\n"
      "           img_nr: 0=logo (32x32), 1=bullet (8x8) [default is 0]\n"
      "\n"
          );
}


/*--------------------------------------------------------------------------- main() */
int main(int argc, char**argv) {
   int ret;

   if(1 == argc)
   {
      loc_usage();

      return 0;
   }

   if(argc > 1)
   {
      if(!strcmp(argv[1], "-h"))
      {
         loc_usage();
         return 0;
      }

      sscanf(argv[1], "%d", &mode);

      if(mode < 0)
      {
         mode = 0;
      }
      else if(mode > NUM_MODES)
      {
         mode = NUM_MODES - 1;
      }

      if(argc > 2)
      {
         sscanf(argv[2], "%u", &num_sprites);

         if(num_sprites < 1)
         {
            num_sprites = 1;
         }
         else if(num_sprites > MAX_SPRITES)
         {
            num_sprites = MAX_SPRITES;
         }

         if(argc > 3)
         {
            sscanf(argv[3], "%u", &clear_mode);

            if(clear_mode >= NUM_CLEAR_MODES)
            {
               clear_mode = CLEAR_MODE_GPP;
            }

            if(argc > 4)
            {
               sscanf(argv[4], "%u", &num_iterations);

               if(num_iterations < 1)
               {
                  num_iterations = 1;
               }
               else if(num_iterations > MAX_ITERATIONS)
               {
                  num_iterations = MAX_ITERATIONS;
               }

               if(argc > 5)
               {
                  sscanf(argv[5], "%f", &slomo);

                  if(argc > 6)
                  {
                     sscanf(argv[6], "%d", &b_vsync);

                     if(argc > 7)
                     {
                        sscanf(argv[7], "%u", &img_nr);

                        if(img_nr > 1)
                        {
                           img_nr = 1;
                        }
                     }
                  }
               }
            }
         }
      }

   }

   if(0 == img_nr)
   {
      img_w = 32;
      img_h = 32;
   }
   else
   {
      img_w = 8;
      img_h = 8;
   }

   /* Open client connection */
   ret = dsp_open();
         
   if(0 == ret)
   {
      log_printf(LOG_INFO "        mode: %s\n", mode_names[mode]);
      log_printf(LOG_INFO "    #sprites: %u\n", num_sprites);
      log_printf(LOG_INFO "  clear_mode: %s\n", (CLEAR_MODE_DSP == clear_mode) ? "DSP" : (CLEAR_MODE_GPP == clear_mode) ? "GPP" : "NONE");
      log_printf(LOG_INFO " #iterations: %u\n", num_iterations);
      log_printf(LOG_INFO "       slomo: %f\n", slomo);
      log_printf(LOG_INFO "       vsync: %s\n", b_vsync ? "YES" : "NO");
      log_printf(LOG_INFO "      img_nr: %s\n", img_nr ? "8x8" : "32x32");

      srand(osal_milliseconds_get());
        
      /* Allocate contiguous memory block */
      shm = dsp_shm_alloc(DSP_CACHE_R, DSPRITE_DLIST_SIZE * 2 + (img_w * sizeof(sU32) * img_h) + (DST_VW * sizeof(sU32)));

      if(0 != shm.size)
      {
         fshm_img = dsp_l1sram_alloc(img_w * sizeof(sU32) * img_h);

         if(0 != fshm_img.size)
         {
            sUI i;
            sU32 tStart;
            sU32 tEnd;
               
            if(loc_video_init())
            {

               if(loc_lazy_load_components())
               {
                  if(loc_init())
                  {
                        
                     tStart = osal_milliseconds_get();
                     
                     for(i=0; i<num_iterations; i++)
                     {
                        
                        loc_frame_begin();
                        
                        loc_frame_process();
                        
                        loc_frame_end();
                        
                     }
                     
                     
                     tEnd = osal_milliseconds_get();
                     
                     log_printf(LOG_INFO "%u iterations in %u millisecs.\n", num_iterations, (tEnd - tStart));

                     log_printf(LOG_INFO " ==> avg FPS=%.3f\n",
                                (1000.0f / ((tEnd - tStart) / ((sF32)num_iterations)))
                                );
                     
                     loc_exit();
                  }
                  else
                  {
                     /* Failed: loc_init() */
                     log_printf(LOG_ERROR "loc_init() failed.\n");
                  }
               }
               else
               {
                  /* Failed: loc_lazy_load_components() */
                  log_printf(LOG_ERROR "failed to load/query required DSP components.\n");
               }
                  
               //usleep(1000000 * 1);

               loc_video_exit();
         
            }

            dsp_l1sram_free(fshm_img);
         }
         else
         {
            /* Failed: dsp_l1sram_alloc() */
            log_printf(LOG_ERROR "failed to allocate L1SRAM for image\n");
         }

         /* Free contiguous memory block */
         dsp_shm_free(shm);

      } /* if dsp_shm_alloc() */

      /* Disconnect client */
      dsp_close();
      
   }
   else
   {
      /* Failed: dsp_open() */
      ret = 10;
   }

   return ret;
}
