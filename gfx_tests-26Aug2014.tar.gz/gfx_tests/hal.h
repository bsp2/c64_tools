/* ----
 * ---- file   : hal.h
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          Distributed under terms of the LESSER GNU GENERAL PUBLIC LICENSE (LGPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#LGPL or COPYING_LGPL for further information.
 * ----
 * ---- info   : HAL main API. This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 28Oct2013, 10Nov2013, 11Nov2013, 20Nov2013, 13Dec2013
 * ----
 * ----
 */

#ifndef __HAL_H__
#define __HAL_H__

#include "../include/cplusplus_begin.h"


#define HAL_INIT_VIDEO (1u << 0)
#define HAL_INIT_NUBS  (1u << 1)


typedef void (*hal_event_key_fxn_t) (sU32 _sym, sU32 _mod, sBool _bPressed);

S_EXTERN hal_event_key_fxn_t hal_event_key_fxn;


S_EXTERN void hal_event_process (void);

S_EXTERN void hal_video_flip (void);

S_EXTERN int hal_nub_init (void);

S_EXTERN void hal_nub_exit (void);

S_EXTERN int hal_video_init (sUI _sdlWinW, sUI _sdlWinH);

S_EXTERN void hal_video_exit (void);

S_EXTERN int hal_init (sUI _halInitFlags, sUI _sdlWinW, sUI _sdlWinH);

S_EXTERN sBool hal_running (void);

S_EXTERN void hal_stop (void);

S_EXTERN void hal_exit (void);


#include "../include/cplusplus_end.h"

#endif /* __HAL_H__ */
