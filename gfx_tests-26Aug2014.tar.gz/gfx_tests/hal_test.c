/* ----
 * ---- file   : hal_test.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          Distributed under terms of the LESSER GNU GENERAL PUBLIC LICENSE (LGPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#LGPL or COPYING_LGPL for further information.
 * ----
 * ---- info   : HAL main API. This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 28Oct2013
 * ----
 * ----
 */

#include "inc_hal.h"


/*--------------------------------------------------------------------------- loc_onkey() */
static void loc_onkey(sU32 _sym, sU32 _mod, sBool _bPressed) {

   printf("[dbg] loc_onkey: sym=0x%08x mod=0x%08x bPressed=%d\n",
          _sym,
          _mod,
          _bPressed
          );

   if('q' == _sym)
   {
      hal_stop();
   }
}


/*--------------------------------------------------------------------------- main() */
int main(int argc, char**argv) {
   (void)argc;
   (void)argv;

   //if(0 == hal_init(HAL_INIT_NUBS, 64, 64))
   if(0 == hal_init(0, 64, 64))
   {
      hal_event_key_fxn = &loc_onkey;
      
      while(hal_running())
      {
         hal_event_process();
         
         hal_video_flip();
      }
     
      hal_exit();
   }

   return 0;
}
