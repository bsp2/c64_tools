/* ----
 * ---- file   : c64_age.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          ARM fixpoint optimized code contributed by M-HT.
 * ----          Distributed under terms of the GNU GENERAL PUBLIC LICENSE (GPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#GPL or COPYING for further information.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 18Nov2013, 19Nov2013, 04Dec2013, 05Dec2013, 06Dec2013, 11Dec2013
 * ----
 * ----
 */

#define NUM_ITERATIONS  (60u * 10u)
//#define NUM_ITERATIONS  (60u * 30u)

#define MAX_ITERATIONS (60u * 60u * 60u)

//#define DOUBLEBUF defined

#define USE_RADIAL defined


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <math.h>

#include <unistd.h>

#include <inc_libc64.h>

#include "dsp/components/age/age.h"

#include "omapfb.h"
#include "inc_hal.h"
#include "fixmath.h"


//#define FILL_RIGHT_BORDER defined

#define GUARD_BAND_SIZE  (16u)

#define DST_W (800)
#define DST_H (480)

//#define DST_W (400)
//#define DST_H (240)

//#define DST_W (800)
//#define DST_H (240)

//#define DST_W (400)
//#define DST_H (480)

#define DST_HCLIP (DST_H + GUARD_BAND_SIZE*2)

#define DST_VW (DST_W+16)
//#define DST_VW (DST_W + GUARD_BAND_SIZE*2)
//#define DST_VW (DST_W*2)


#ifdef DOUBLEBUF
#define DST_VHD (2 * (DST_H + GUARD_BAND_SIZE*2))
#else
#define DST_VHD (1 * (DST_H + GUARD_BAND_SIZE*2))
#endif

#define SRC_W  (DST_W+16)
#define SRC_H  (DST_H)

#define PROC_W (DST_W+16)

#define FB_VIRT_ADDR  (shm_vid.virt_addr + (screen_offset_y ) * DST_VW * sizeof(sU32))
#define FB_PHYS_ADDR  (shm_vid.phys_addr + (screen_offset_y ) * DST_VW * sizeof(sU32))

#define SHM_SIZE  (4u * 1024u * 1024u)

#define DLIST_SIZE  (1024u * 1024u)

#define NUM_PALS  (256u)


//#define NUM_PAL_SINS  (10)
//#define NUM_YSINS (5)
//#define NUM_YSINS_SCL (5)


#define NUM_PAL_SINS  (10)
#define NUM_YSINS (5)
#define NUM_YSINS_SCL (5)


enum {
   PROCESS_MODE_BITMAP                         = 0,
   PROCESS_MODE_BITMAP_SCROLLSCR               = 1,
   PROCESS_MODE_BITMAP_SCROLLSCNLINES          = 2,
   PROCESS_MODE_BITMAP_SCROLLSCNLINES_PAL      = 3,
   PROCESS_MODE_BITMAP_SCROLLSCNLINES_PAL_YSIN = 4,

   NUM_PROCESS_MODES
};


/*--------------------------------------------------------------------------- module vars */
static dsp_component_id_t compid_age;

static dsp_mem_region_t shm;

static dsp_mem_region_t fshm_pal;

static dsp_mem_region_t shm_vid;

/* for the effect to look more nicely. _NOT_ for benchmarking.. */
static sBool b_vsync = S_TRUE;

static sU32 screen_offset_y = 0;

static sU32 num_iterations = 0;

static dsp_mspace_handle_t msp;

static sU32 *dlist;
static sU32 *dlist_gen;
static sU32 *dlist_render;

static sU16 *mem_bitplanes[8];

static sU32 *mem_palette_gray;
static sU32 *mem_palettes;

static sU8 *fb_chunky;

static sU16 ang_oshift[8];
static sS16 ang_oshift_spd[8];

static sU16 ang_ishift[8];
static sS16 ang_ishift_spd[8];

static sU16 ang_opal[NUM_PAL_SINS];
static sS16 ang_opal_spd[NUM_PAL_SINS];
static sS16 ang_ipal_spd[NUM_PAL_SINS];

static sU16 ang_oy[8][NUM_YSINS];
static sS16 ang_oy_spd_a[8][NUM_YSINS];
static sS16 ang_iy_spd_a[8][NUM_YSINS];
static sS16 ang_oy_spd_b[8][NUM_YSINS];
static sS16 ang_iy_spd_b[8][NUM_YSINS];
static sS16 ang_oy_spd[8][NUM_YSINS];
static sS16 ang_iy_spd[8][NUM_YSINS];
static sU16 ang_oyab;
static sS16 ang_oyab_spd;

static sU16 ang_oyscl[NUM_YSINS_SCL];
static sS16 ang_oyscl_spd_a[NUM_YSINS_SCL];
static sS16 ang_iyscl_spd_a[NUM_YSINS_SCL];
static sS16 ang_oyscl_spd_b[NUM_YSINS_SCL];
static sS16 ang_iyscl_spd_b[NUM_YSINS_SCL];
static sS16 ang_oyscl_spd[NUM_YSINS_SCL];
static sS16 ang_iyscl_spd[NUM_YSINS_SCL];
static sU16 ang_oysclab;
static sS16 ang_oysclab_spd;

static sU16 ang_oyslew;
static sS16 ang_oyslew_spd;

static sSI process_mode = 0;

static sUI iter;


/*--------------------------------------------------------------------------- loc_lazy_load_components() */
sBool loc_lazy_load_components(void) {
   sBool ret;

   ret = S_FALSE;

   if(0 == dsp_component_load(NULL, COMPONENT_NAME_AGE, &compid_age))
   {
      /* Succeeded */
      ret = S_TRUE;
   }

   return ret;
}


/*--------------------------------------------------------------------------- hsv_to_argb32() */
#define Dargb(a,r,g,b) ((((sU8)a)<<24)|(((sU8)r)<<16)|(((sU8)g)<<8)|((sU8)b))

static sU32 hsv_to_argb32(float h, float s, float v, sU8 _a) {
   // converts alpha '_a' (0..255) + hue (0..360) + saturation/value (0..1) to ARGB32 int

   int i;
   float f;
   int p;
   int q;
   int t;
   
   if(h >= 360)
      h -= 360;
   h /= 60;

   i = h;
   f = h - i;
   
   p = 255 * v * ( 1 - s );
   q = 255 * v * ( 1 - s * f );
   t = 255 * v * ( 1 - s * ( 1 - f ) );
   
   v *= 255;
   
   switch(i)
   {
      case 0:
         return Dargb(_a, v, t, p);
      case 1:
         return Dargb(_a, q, v, p);
      case 2:
         return Dargb(_a, p, v, t);
      case 3:
         return Dargb(_a, p, q, v);
      case 4:
         return Dargb(_a, t, p, v);
      default:
         return Dargb(_a, v, p, q);
   }
}



/*--------------------------------------------------------------------------- loc_video_init() */
static sBool loc_video_init(void) {
   sBool ret;

   if(omapfb_init(0, 0, // position
                  DST_W, DST_H,
                  800, 480, // zoomed size
                  //DST_W, DST_H, // zoomed size
                  DST_VW, DST_VHD, // virtual size
                  32,
                  S_TRUE  /* disable desktop layer */
                  )
      )
   {
      shm_vid = omapfb_plane_get_dsp_mem(1);

      omapfb_plane_offset(1, GUARD_BAND_SIZE, GUARD_BAND_SIZE);

      memset((void*)shm_vid.virt_addr,
             0,
             DST_VW * sizeof(sU32) * DST_VHD
             );

      
      /* Succeeded */
      ret = S_TRUE;
      
   }
   else
   {
      /* Failed: omapfb_init() */
      log_printf(LOG_ERROR "omapfb_init() failed.\n");
      
      ret = S_FALSE;
   }
   
   return ret;
}


/*--------------------------------------------------------------------------- loc_video_exit() */
static void loc_video_exit(void) {

   omapfb_exit();
}


/*--------------------------------------------------------------------------- loc_randomize_angles() */
static void loc_randomize_angles(void) {

   {
      sUI i;

      for(i=0; i<8; i++)
      {
         ang_oshift[i] = S_2X16U( 2 * 3.1415f * ((rand() & 65535) / 65536.0f) );
         ang_oshift_spd[i] = S_2X16S( (((rand() & 65535) / 65536.0f) * 0.1f + 0.01f) / S_2PI );

         ang_ishift_spd[i] = S_2X16S( (((rand() & 65535) / 65536.0f) * 0.1f  * 0.5f + 0.015f) / S_2PI );
      }

      for(i=0; i<NUM_PAL_SINS; i++)
      {
         ang_opal[i] = 0;
         ang_opal_spd[i] = S_2X16S( ((((rand() & 65535) / 65536.0f) * 0.1f  * 0.25f) + 0.0015f) / S_2PI );
         ang_ipal_spd[i] = S_2X16S( ((((rand() & 65535) / 65536.0f) * 0.062f  * 0.125f) + 0.0005f) / S_2PI );
      }

      {
         sUI bplIdx;

         float tscla = 0.7f;
         float tsclb = 0.7f;

         for(bplIdx = 0; bplIdx < 8; bplIdx++)
         {
            float scl = 1.0f;
            for(i=0; i<NUM_YSINS; i++)
            {
               ang_oy[bplIdx][i] = 0;

               ang_oy_spd_a[bplIdx][i] = S_2X16S( ((((rand() & 65535) / 65536.0f) * 2 * tscla * 0.1f  * 0.25f * scl) + 0.0f) / S_2PI );
               ang_iy_spd_a[bplIdx][i] = S_2X16S( ((((rand() & 65535) / 65536.0f) * 3 * tscla * 0.042f  * 0.125f * scl) + 0.0f) / S_2PI );
               scl *= 0.5f;
            }
         }

         for(bplIdx = 0; bplIdx < 8; bplIdx++)
         {
            float scl = 1.0f;
            for(i=0; i<NUM_YSINS; i++)
            {
               ang_oy[bplIdx][i] = 0;

               ang_oy_spd_b[bplIdx][i] = S_2X16S( ((((rand() & 65535) / 65536.0f) * 4 * tscla * 0.1f  * 0.25f * scl) + 0.0f) / S_2PI );
               ang_iy_spd_b[bplIdx][i] = S_2X16S( ((((rand() & 65535) / 65536.0f) * 1 * tscla * 0.042f  * 0.125f * scl) + 0.0f) / S_2PI );
               scl *= 0.5f;
            }
         }

         for(i=0; i<NUM_YSINS_SCL; i++)
         {
            ang_oyscl[i] = 0;

            ang_oyscl_spd_a[i] = S_2X16S( ((((rand() & 65535) / 65536.0f) * 2 * tsclb * 0.1f  * 0.25f) + 0.0f) / S_2PI );
            ang_iyscl_spd_a[i] = S_2X16S( ((((rand() & 65535) / 65536.0f) * 2 * tsclb * 0.1f  * 0.25f) + 0.0f) / S_2PI );
         }

         for(i=0; i<NUM_YSINS_SCL; i++)
         {
            ang_oyscl[i] = 0;

            ang_oyscl_spd_b[i] = S_2X16S( ((((rand() & 65535) / 65536.0f) * 2 * tsclb * 0.1f  * 0.25f) + 0.0f) / S_2PI );
            ang_iyscl_spd_b[i] = S_2X16S( ((((rand() & 65535) / 65536.0f) * 0.25 * tsclb * 0.1f  * 0.25f) + 0.0f) / S_2PI );
         }

         ang_oyab = 0;
         ang_oyab_spd = 0x33;

         ang_oysclab = 0;
         ang_oysclab_spd = 0x33;//0x47;//0x33;//79;

         ang_oyslew = 0;
         ang_oyslew_spd = S_2X16S( ((((rand() & 65535) / 65536.0f) * 0.2 * 0.1f  * 0.25f) + 0.0f) / S_2PI );
      }
   }

}


/*--------------------------------------------------------------------------- loc_init() */
static sBool loc_init(void) {

   //sU32 *d = (sU32*) fshm_pal.virt_addr;

   log_printf(LOG_DEBUG "fshm_pal: phys_addr=0x%08x, virt_addr=0x%08x\n",
              fshm_pal.phys_addr,
              fshm_pal.virt_addr
              );

   log_printf(LOG_DEBUG "fshm_pal: DSP phys_addr=0x%08x\n",
              dsp_physgpp_to_physdsp(fshm_pal.phys_addr)
              );

   log_printf(LOG_DEBUG "loc_init: loc_init() ok.\n");

   loc_randomize_angles();

   return S_TRUE;
}


/*--------------------------------------------------------------------------- loc_bpl_and_pal_init() */
static void loc_bpl_and_pal_init(void) {

   /* Create chunky test bitmap */
   {
      float vstep = 1.0f / (SRC_H - 1);
      float ustep = 1.0f / (SRC_W - 1);
      sUI y;
      float v = 0.0f;
      sU8 *d = fb_chunky;
      
      for(y=0; y<SRC_H; y++)
      {
         sUI x;
         float u = 0.0f;
         //float u = 1.0f;

         for(x=0; x<(SRC_W
#ifdef FILL_RIGHT_BORDER
                     -16
#endif
                     )
                ; x++)
         {
#ifdef USE_RADIAL
            sU8 c = (sU8) (sin(u*3.1415f) * sin(v*3.1415f) * 255);
            //sU8 c = (sU8) (255 * (0.5f + 0.5f * sin(u*v*8*S_2PI)));
            //sU8 c = (sU8) ((0.5f + 0.5f * sin(S_2PI*sin(u*3.1415f) * sin(v*3.1415f))) * 255);
#else
            sU8 c = (sU8) (u * v * 255);
#endif
            //sU8 c = (sU8) (u * 255);
            //sU8 c = 0;
            //sU8 c = 64;
            //sU8 c = x & 255;

            *d++ = c;

            u += ustep;
            //u -= ustep;
         }

#ifdef FILL_RIGHT_BORDER
         *d++ = 255;
         *d++ = 255;
         *d++ = 255;
         *d++ = 255;

         *d++ = 255;
         *d++ = 255;
         *d++ = 255;
         *d++ = 255;

         *d++ = 255;
         *d++ = 255;
         *d++ = 255;
         *d++ = 255;

         *d++ = 255;
         *d++ = 255;
         *d++ = 255;
         *d++ = 255;
#endif

         v += vstep;
      }
   }

   /* Covert chunky test bitmap to bitplanes */
   {
      sUI y;
      sU8 *s = fb_chunky;
      sU16 *d[8];
      sUI i;

      for(i=0; i<8; i++)
      {
         d[i] = mem_bitplanes[i];
         printf("xxx d[%u] = 0x%08x\n", i, (sU32)d[i]);
      }
     
      for(y=0; y<SRC_H; y++)
      {
         sUI wi;

         for(wi=0; wi<(SRC_W >> 4); wi++)
         {
            sSI pixIdx;

            for(i=0; i<8; i++)
            {
               d[i][0] = 0;
            }

            for(pixIdx=15; pixIdx>=0; pixIdx--)
            {
               sU8 c = *s++;

/*                if(pixIdx & 1) */
/*                   c = 0; */
/*                else */
/*                   c = 255; */

               //c = (wi * pixIdx) & 255;

/*                c = 79; */

               if(c &   1u)
               {
                  d[0][0] |= (1u << pixIdx);
               }

               if(c &   2u)
               {
                  d[1][0] |= (1u << pixIdx);
               }

               if(c &   4u)
               {
                  d[2][0] |= (1u << pixIdx);
               }

               if(c &   8u)
               {
                  d[3][0] |= (1u << pixIdx);
               }

               if(c &  16u)
               {
                  d[4][0] |= (1u << pixIdx);
               }

               if(c &  32u)
               {
                  d[5][0] |= (1u << pixIdx);
               }

               if(c &  64u)
               {
                  d[6][0] |= (1u << pixIdx);
               }

               if(c & 128u)
               {
                  d[7][0] |= (1u << pixIdx);
               }

            }

            /* On to the next 16 pixels */
            for(i=0; i<8; i++)
            {
               d[i]++;
            }

         } /* for wi */

      } /* for y */

      for(i=0; i<8; i++)
      {
         printf("xxx d[%u] = 0x%08x\n", i, (sU32)d[i]);
      }
   }

/*    memset(mem_bitplanes[0], 255, DST_W * (DST_H >> 4)); */
/*    memset(mem_bitplanes[1], 255, DST_W * (DST_H >> 4)); */
/*    memset(mem_bitplanes[2], 255, DST_W * (DST_H >> 4)); */
/*    memset(mem_bitplanes[3], 255, DST_W * (DST_H >> 4)); */
/*    memset(mem_bitplanes[4], 255, DST_W * (DST_H >> 4)); */
/*    memset(mem_bitplanes[5], 255, DST_W * (DST_H >> 4)); */
/*    memset(mem_bitplanes[6], 255, DST_W * (DST_H >> 4)); */
/*    memset(mem_bitplanes[7], 255, DST_W * (DST_H >> 4)); */

   /* Create grayscale palette */
   {
      sU32 *d = mem_palette_gray;
      sUI i;
      
      for(i=0; i<256u; i++)
      {
         d[i] = 0xFF000000u | (i << 16) | (i << 8) | i;
      }
   }

   {
      sUI palIdx;
      float h = 0.0f;
      float hstep = 360.0f / NUM_PALS;
      sU32 *d = mem_palettes;

      for(palIdx=0; palIdx<NUM_PALS; palIdx++)
      {
         sSI i;

         for(i=0; i<256; i++)
         {
            //d[i] = hsv_to_argb32(h, i/255.0f, i/255.0f, 255);
            //d[i] = hsv_to_argb32(h, 0.5f + 0.5f * (i/255.0f), 0.25f + 0.75f * (i/255.0f), 255);
            //d[i] = hsv_to_argb32(h, 0.5f + 0.5f * (i/255.0f), (i/255.0f), 255);
            d[i] = hsv_to_argb32(h, 1.0f, 0.0f + 1.0f * (i/255.0f), 255);
         }

         h += hstep;
         d += 256;
      }
   }

   
}


/*--------------------------------------------------------------------------- loc_frame_begin() */
static void loc_frame_begin(void) {

#ifdef DOUBLEBUF
   /* Swap buffers */
   {
      if(0 != screen_offset_y)
      {
         screen_offset_y = 0;
      }
      else
      {
         screen_offset_y = DST_HCLIP;
      }

   }
#endif

}


/*--------------------------------------------------------------------------- loc_gen_dlist_0() */
static void loc_gen_dlist_0(void) {
   /*
    * - Display 8 bitplane 800x480 image
    */

   sU32 *dl = dlist_gen;

   *dl++ = AGE_OP_BLEND;
   *dl++ = AGE_BLEND_NONE;

   *dl++ = AGE_OP_VIDMODE;
   *dl++ = AGE_VIDMODE_BITMAP;

   *dl++ = AGE_OP_FLAGS;
   *dl++ = AGE_FLAG_COPY_PAL;

   {
      sUI i;

      *dl++ = AGE_OP_BPL_NUM;
      *dl++ = 8;

      for(i=0; i<8; i++)
      {
         *dl++ = AGE_OP_BPL0_ADDR + i;
         *dl++ = dsp_virt_to_phys(mem_bitplanes[i]);

         *dl++ = AGE_OP_BPL0_MOD + i;
         *dl++ = (sU32) (SRC_W >> 4);

         *dl++ = AGE_OP_BPL0_SHIFT + i;
         *dl++ = 0;
      }
   }

   *dl++ = AGE_OP_PAL_ADDR;
   *dl++ = dsp_virt_to_phys(mem_palette_gray);

   *dl++ = AGE_OP_DEST_ADDR;
   *dl++ = FB_PHYS_ADDR;

   *dl++ = AGE_OP_DEST_STRIDE;
   *dl++ = DST_VW;

   *dl++ = AGE_OP_PROCESS;
   *dl++ = ((PROC_W) << 16) | DST_H;

   *dl++ = AGE_OP_LINK;
   *dl++ = 0;
}


/*--------------------------------------------------------------------------- loc_gen_dlist_1() */
static void loc_gen_dlist_1(void) {
   /*
    * - Display 8 bitplane 800x480 image
    * - Scroll each bitplane independently (sin())
    */

   //sUI i;
   //sU32 dstAddrBase = FB_PHYS_ADDR;
   sU32 *dl = dlist_gen;

   *dl++ = AGE_OP_BLEND;
   *dl++ = AGE_BLEND_NONE;

   *dl++ = AGE_OP_VIDMODE;
   *dl++ = AGE_VIDMODE_BITMAP;

   *dl++ = AGE_OP_FLAGS;
   *dl++ = AGE_FLAG_COPY_PAL;

   {
      sUI i;

      *dl++ = AGE_OP_BPL_NUM;
      *dl++ = 8;

      for(i=0; i<8; i++)
      {
         *dl++ = AGE_OP_BPL0_ADDR + i;
         *dl++ = dsp_virt_to_phys(mem_bitplanes[i]);

         *dl++ = AGE_OP_BPL0_MOD + i;
         *dl++ = (sU32) (SRC_W >> 4);

         *dl++ = AGE_OP_BPL0_SHIFT + i;
         *dl++ = (sU32) S_SINX_VSCLADD_2I(ang_oshift[i], 7, 8);
         //*dl++ = 16;
         //*dl++ = 0;

         ang_oshift[i] += ang_oshift_spd[i];
      }
   }

   *dl++ = AGE_OP_PAL_ADDR;
   *dl++ = dsp_virt_to_phys(mem_palette_gray);

   *dl++ = AGE_OP_DEST_ADDR;
   *dl++ = FB_PHYS_ADDR;

   *dl++ = AGE_OP_DEST_STRIDE;
   *dl++ = DST_VW;

#if 0
   {
      sUI y;
      for(y=0; y<DST_H; y++)
      {
#if 0
         /* 166 fps */
         *dl++ = AGE_OP_PAL_ADDR;
         *dl++ = dsp_virt_to_phys(mem_palettes);
#endif

#if 0
         /* 185 fps */
         *dl++ = AGE_OP_REPEAT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_REPEAT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_REPEAT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_REPEAT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_REPEAT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_REPEAT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_REPEAT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_REPEAT + 0;
         *dl++ = 0;
#elif 0
         /* 162 fps */
         *dl++ = AGE_OP_BPL0_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL0_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL0_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL0_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL0_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL0_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL0_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL0_SHIFT + 0;
         *dl++ = 0;
#elif 0
         /* 132 FPS */
         *dl++ = AGE_OP_BPL0_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL1_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL2_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL3_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL4_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL5_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL6_SHIFT + 0;
         *dl++ = 0;

         *dl++ = AGE_OP_BPL7_SHIFT + 0;
         *dl++ = 0;
#endif

         *dl++ = AGE_OP_PROCESS;
         *dl++ = ((PROC_W) << 16) | 1;
      }
   }
#else
   *dl++ = AGE_OP_PROCESS;
   *dl++ = ((PROC_W) << 16) | DST_H;
#endif

   *dl++ = AGE_OP_LINK;
   *dl++ = 0;
}


/*--------------------------------------------------------------------------- loc_gen_dlist_2() */
static void loc_gen_dlist_2(void) {
   /*
    * - Display 8 bitplane 800x480 image
    * - Scroll each bitplane and each scanline independently (sin())
    */

   //sUI i;
   //sU32 dstAddrBase = FB_PHYS_ADDR;
   sU32 *dl = dlist_gen;

   *dl++ = AGE_OP_BLEND;
   *dl++ = AGE_BLEND_NONE;

   *dl++ = AGE_OP_VIDMODE;
   *dl++ = AGE_VIDMODE_BITMAP;

   *dl++ = AGE_OP_FLAGS;
   *dl++ = AGE_FLAG_COPY_PAL;

   {
      sUI bplIdx;

      *dl++ = AGE_OP_BPL_NUM;
      *dl++ = 8;

      for(bplIdx=0; bplIdx<8; bplIdx++)
      {
         *dl++ = AGE_OP_BPL0_ADDR + bplIdx;
         *dl++ = dsp_virt_to_phys(mem_bitplanes[bplIdx]);

         *dl++ = AGE_OP_BPL0_MOD + bplIdx;
         *dl++ = (sU32) (SRC_W >> 4);

         ang_ishift[bplIdx] = ang_oshift[bplIdx];

         ang_oshift[bplIdx] += ang_oshift_spd[bplIdx];
      }
   }

   *dl++ = AGE_OP_PAL_ADDR;
   *dl++ = dsp_virt_to_phys(mem_palette_gray);

   *dl++ = AGE_OP_DEST_ADDR;
   *dl++ = FB_PHYS_ADDR;

   *dl++ = AGE_OP_DEST_STRIDE;
   *dl++ = DST_VW;

   {
      sUI y;

      for(y=0; y<DST_H; y++)
      {
#if 1
         sUI bplIdx;

         for(bplIdx = 0; bplIdx < 8; bplIdx++)
         {
            *dl++ = AGE_OP_BPL0_SHIFT + bplIdx;
            *dl++ = (sU32) S_SINX_VSCLADD_2I(ang_ishift[bplIdx], 7, 8);
            //*dl++ = 0;

            ang_ishift[bplIdx] += ang_ishift_spd[bplIdx];
         }
#endif

         *dl++ = AGE_OP_PROCESS;
         *dl++ = ((PROC_W) << 16) | 1u;
      }

   }

   *dl++ = AGE_OP_LINK;
   *dl++ = 0;

   //printf("xxx dl_size=%u\n", ((sU32)dl) - ((sU32)dlist));
}


/*--------------------------------------------------------------------------- loc_gen_dlist_3() */
static void loc_gen_dlist_3(void) {
   /*
    * - Display 8 bitplane 800x480 image
    * - Scroll each bitplane and each scanline independently (sin())
    * - Change palette each scanline
    */

   sU32 *dl = dlist_gen;

   *dl++ = AGE_OP_BLEND;
   *dl++ = AGE_BLEND_NONE;

   *dl++ = AGE_OP_VIDMODE;
   *dl++ = AGE_VIDMODE_BITMAP;

   *dl++ = AGE_OP_FLAGS;
   *dl++ = 0;//AGE_FLAG_COPY_PAL;

   {
      sUI bplIdx;

      *dl++ = AGE_OP_BPL_NUM;
      *dl++ = 8;

      for(bplIdx=0; bplIdx<8; bplIdx++)
      {
         *dl++ = AGE_OP_BPL0_ADDR + bplIdx;
         *dl++ = dsp_virt_to_phys(mem_bitplanes[bplIdx]);

         *dl++ = AGE_OP_BPL0_MOD + bplIdx;
         *dl++ = (sU32) (SRC_W >> 4);

         ang_ishift[bplIdx] = ang_oshift[bplIdx];

         ang_oshift[bplIdx] += ang_oshift_spd[bplIdx];
      }
   }

#if 0
   *dl++ = AGE_OP_PAL_ADDR;
   *dl++ = dsp_virt_to_phys(mem_palettes);
#endif

   *dl++ = AGE_OP_DEST_ADDR;
   *dl++ = FB_PHYS_ADDR;

   *dl++ = AGE_OP_DEST_STRIDE;
   *dl++ = DST_VW;

   {
      sUI y;
      sUI i;
      sU16 angPal[NUM_PAL_SINS];

      for(i=0; i<NUM_PAL_SINS; i++)
      {
         angPal[i] = ang_opal[i];
      }

      for(y=0; y<DST_H; y++)
      {
#if 1
         sUI bplIdx;

         for(bplIdx = 0; bplIdx < 8; bplIdx++)
         {
            *dl++ = AGE_OP_BPL0_SHIFT + bplIdx;
            *dl++ = (sU32) S_SINX_VSCLADD_2I(ang_ishift[bplIdx], 7, 8);
            //*dl++ = 0;

            ang_ishift[bplIdx] += ang_ishift_spd[bplIdx];
         }
#endif

         {
            sS32 angSin = 0;
            sU8 palIdx;

            for(i=0; i<NUM_PAL_SINS; i++)
            {
               angSin += (sS32) S_SINX_XSCLADD(angPal[i],
                                              S_RAD2X(0.25f * (2.0f / NUM_PAL_SINS)),
                                              S_RAD2X(0.25f * (2.0f / NUM_PAL_SINS))
                                              );
               angPal[i] += ang_ipal_spd[i];
            }

            palIdx = ((sU16)(angSin >> 7)) % NUM_PALS;

            //palIdx = angSin * (NUM_PALS/2) + (NUM_PALS/2);

            *dl++ = AGE_OP_PAL_ADDR;
            *dl++ = dsp_virt_to_phys(mem_palettes + (palIdx * 256u));
            //(void)palIdx;
            //*dl++ = dsp_virt_to_phys(mem_palettes + (y&255)*256);
         }

         *dl++ = AGE_OP_PROCESS;
         *dl++ = ((PROC_W) << 16) | 1u;
      }

      for(i=0; i<NUM_PAL_SINS; i++)
      {
         ang_opal[i] += ang_opal_spd[i];
      }
   }

   *dl++ = AGE_OP_LINK;
   *dl++ = 0;

   //printf("xxx dl_size=%u\n", ((sU32)dl) - ((sU32)dlist));
}


/*--------------------------------------------------------------------------- loc_gen_dlist_4() */
static void loc_gen_dlist_4(void) {
   /*
    * - Display 8 bitplane 800x480 image
    * - Scroll each bitplane and each scanline independently (sin())
    * - Change palette each scanline
    * - Modulate bitplane y position
    */

   sU32 *dl = dlist_gen;
   sUI bplIdx;
   sUI i;
      
   *dl++ = AGE_OP_BLEND;
   *dl++ = AGE_BLEND_NONE;

   *dl++ = AGE_OP_VIDMODE;
   *dl++ = AGE_VIDMODE_BITMAP;

   *dl++ = AGE_OP_FLAGS;
   *dl++ = 0;//AGE_FLAG_COPY_PAL;

   {
      *dl++ = AGE_OP_BPL_NUM;
      *dl++ = 8;

      for(bplIdx=0; bplIdx<8; bplIdx++)
      {
         *dl++ = AGE_OP_BPL0_MOD + bplIdx;
         *dl++ = (sU32) (SRC_W >> 4);

         ang_ishift[bplIdx] = ang_oshift[bplIdx];

         ang_oshift[bplIdx] += ang_oshift_spd[bplIdx];
      }

      {
         //sX scl = S_2X(0.5f) + S_MULX(S_2X(0.5f), S_SINX(ang_oyab));
         ////sX scl = S_SINX(ang_oyab);
         //scl = 0;
         sX scl = (ang_oyab << 1);
         if(scl > S_2X(1))
         {
            scl = (S_2X(2) - scl);
         }

         for(bplIdx=0; bplIdx<8; bplIdx++)
         {
            for(i=0; i<NUM_YSINS; i++)
            {
               ang_oy_spd[bplIdx][i] = 
                  ang_oy_spd_a[bplIdx][i] + S_MULX(scl, ang_oy_spd_b[bplIdx][i] - ang_oy_spd_a[bplIdx][i]);

               ang_iy_spd[bplIdx][i] = 
                  ang_iy_spd_a[bplIdx][i] + S_MULX(scl, ang_iy_spd_b[bplIdx][i] - ang_iy_spd_a[bplIdx][i]);
            }
         }

         ang_oyab += ang_oyab_spd;
      }

      {
         //sX scl = S_2X(0.5f) + S_MULX(S_2X(0.5f), S_SINX(ang_oysclab));
         ////sX scl = S_SINX(ang_oysclab);
         //scl = 0;
         sX scl = (ang_oysclab << 1);
         if(scl > S_2X(1))
         {
            scl = (S_2X(2) - scl);
         }

         for(i=0; i<NUM_YSINS_SCL; i++)
         {
            ang_oyscl_spd[i] =
               ang_oyscl_spd_a[i] + S_MULX(scl, ang_oyscl_spd_b[i] - ang_oyscl_spd_a[i]);

            ang_iyscl_spd[i] =
               ang_iyscl_spd_a[i] + S_MULX(scl, ang_iyscl_spd_b[i] - ang_iyscl_spd_a[i]);
         }

         ang_oysclab += ang_oysclab_spd;
      }
   }

   *dl++ = AGE_OP_DEST_ADDR;
   *dl++ = FB_PHYS_ADDR;

   *dl++ = AGE_OP_DEST_STRIDE;
   *dl++ = DST_VW;

   {
      sUI y;
      sU16 angPal[NUM_PAL_SINS];
      sU16 angY[8][NUM_YSINS];
      sU16 angYScl[NUM_YSINS_SCL];
      sX sinYSlew;

      sinYSlew = S_MULX(S_SINX(ang_oyslew), S_2X(0.5f)) + S_2X(0.5f);

      for(i=0; i<NUM_PAL_SINS; i++)
      {
         angPal[i] = ang_opal[i];
      }

      for(i=0; i<NUM_YSINS_SCL; i++)
      {
         angYScl[i] = ang_oyscl[i];
      }

      for(bplIdx=0; bplIdx<8; bplIdx++)
      {
         for(i=0; i<NUM_YSINS; i++)
         {
            angY[bplIdx][i] = ang_oy[bplIdx][i];
         }
      }

      for(y=0; y<DST_H; y++)
      {
         sUI bplIdx;
         sX sinYScl;

         sinYScl = S_2X(1);

         for(i=0; i<NUM_YSINS_SCL; i++)
         {
            sinYScl = S_MULX(sinYScl, S_SINX(angYScl[i]));
         }

         for(bplIdx = 0; bplIdx < 8; bplIdx++)
         {
            *dl++ = AGE_OP_BPL0_SHIFT + bplIdx;
            *dl++ = (sU32) S_SINX_VSCLADD_2I(ang_ishift[bplIdx], 7, 8);
            //*dl++ = 0;

            ang_ishift[bplIdx] += ang_ishift_spd[bplIdx];
         }

         {
            sS32 angSin = 0;
            sU8 palIdx;

            for(i=0; i<NUM_PAL_SINS; i++)
            {
               angSin += (sS32) S_SINX_XSCLADD(angPal[i],
                                              S_RAD2X(0.25f * (2.0f / NUM_PAL_SINS)),
                                              S_RAD2X(0.25f * (2.0f / NUM_PAL_SINS))
                                              );
               angPal[i] += ang_ipal_spd[i];
            }

            palIdx = ((sU16)(angSin >> 7)) % NUM_PALS;

            //palIdx = angSin * (NUM_PALS/2) + (NUM_PALS/2);

            *dl++ = AGE_OP_PAL_ADDR;
            *dl++ = dsp_virt_to_phys(mem_palettes + (palIdx * 256u));
         }

         {
            sS32 angSin[8];

            for(bplIdx=0; bplIdx<8; bplIdx++)
            {
               sS32 cy;
               sX scl = S_2X(1);

               angSin[bplIdx] = S_2X(1);

               for(i=0; i<NUM_YSINS; i++)
               {
                  //angSin = S_MULX(angSin,  S_SINX(angY[i] + angSin));
                  //angSin += S_MULX(angSin,  S_SINX(S_MULX(angY[i], angSin)));
                  angSin[bplIdx] += S_MULX(scl, S_MULX(angSin[bplIdx],  S_SINX(S_MULX(angY[bplIdx][i], angSin[bplIdx]))));
                  //angSin = S_MULX(angSin,  S_MULX(scl, S_SINX(S_MULX(angY[i], angSin))));
                  //angSin = S_MULX(angSin,  S_2X(1) - S_MULX(scl, S_SINX(S_MULX(angY[i], angSin))));
                  //angSin = S_MULX(angSin,  S_SINX(S_MULX(angY[i], angSin) + angSin));
                  
                  angY[bplIdx][i] += ang_iy_spd[bplIdx][i];
                  
                  scl >>= 2;
               }


               if(bplIdx > 0)
               {
                  angSin[bplIdx] += S_MULX(sinYSlew, angSin[bplIdx] - angSin[bplIdx-1]);
               }

               //cy = y + S_2I(S_MULX(angSin, S_2X(64)));
               cy = y + S_2I(S_MULX(angSin[bplIdx], S_MULX(S_2X(64), sinYScl)));
               //cy = y + S_2I(S_MULX(angSin[bplIdx], S_MULX(S_2X(48), sinYScl)));
               //cy  = 0;
               
               while(cy < 0)
                  cy += SRC_H;
               
               while(cy >= SRC_H)
                  cy -= SRC_H;
               
               cy *= (SRC_W >> 3);
               
               *dl++ = AGE_OP_BPL0_ADDR + bplIdx;
               *dl++ = dsp_virt_to_phys(mem_bitplanes[bplIdx]) + cy;
            }
         }

         for(i=0; i<NUM_YSINS_SCL; i++)
         {
            angYScl[i] += ang_iyscl_spd[i];
         }

         *dl++ = AGE_OP_PROCESS;
         *dl++ = ((PROC_W) << 16) | 1u;
      }

      for(i=0; i<NUM_PAL_SINS; i++)
      {
         ang_opal[i] += ang_opal_spd[i];
      }

      for(bplIdx=0; bplIdx<8; bplIdx++)
      {
         for(i=0; i<NUM_YSINS; i++)
         {
            ang_oy[bplIdx][i] += ang_oy_spd[bplIdx][i];
         }
      }

      for(i=0; i<NUM_YSINS_SCL; i++)
      {
         ang_oyscl[i] += ang_oyscl_spd[i];
      }

      ang_oyslew += ang_oyslew_spd;
   }

   *dl++ = AGE_OP_LINK;
   *dl++ = 0;

   //printf("xxx dl_size=%u\n", ((sU32)dl) - ((sU32)dlist));
}


/*--------------------------------------------------------------------------- loc_frame_end() */
static void loc_frame_end(void) {

   dsp_msg_t reply;
   
   /* Sync with DSP */
#if 1
   dsp_rpc_recv(&reply);
   
   if(0 != reply.data[0].ret)
   {
      log_printf(LOG_ERROR "loc_frame_end: DSP process() returned error %u\n", reply.data[0].ret);
   }
#endif

   /* Swap buffers */
   //omapfb_plane_offset(1, GUARD_BAND_SIZE, screen_offset_y);// + GUARD_BAND_SIZE);
   //omapfb_plane_offset(1, 0, screen_offset_y);// + GUARD_BAND_SIZE);
   omapfb_plane_offset(1, 16, screen_offset_y);// + GUARD_BAND_SIZE);
   //omapfb_plane_offset(1, 32, screen_offset_y);// + GUARD_BAND_SIZE);

   if(b_vsync)
   {
      omapfb_vsync();
   }

}


/*--------------------------------------------------------------------------- loc_exit() */
static void loc_exit(void) {
}


/*--------------------------------------------------------------------------- loc_usage() */
static void loc_usage(void) {
   printf(
      "Usage: ./c64_age <mode> <num_iterations> [vsync]\n"
      "\n\tmode:"
      "\n\t\t0: 800x480@8bpl, static image"
      "\n\t\t1: 800x480@8bpl, scroll bpls independently"
      "\n\t\t2: 800x480@8bpl, scroll bpls independently, per scanline scroll offset"
      "\n\t\t3: 800x480@8bpl, scroll bpls independently, per scanline scroll offset + pal"
      "\n\t\t4: 800x480@8bpl, scroll bpls independently, per scanline scroll offset + pal, ysin"
      "\n"
          );
}


/*--------------------------------------------------------------------------- loc_onkey() */
static void loc_onkey(sU32 _sym, sU32 _mod, sBool _bPressed) {

   printf("[dbg] loc_onkey: sym=0x%08x mod=0x%08x bPressed=%d\n",
          _sym,
          _mod,
          _bPressed
          );

   if(_bPressed)
   {
      switch(_sym)
      {
         case 'q':
            hal_stop();
            break;

         case ' ':
            loc_randomize_angles();
            break;

         case '0':
            process_mode = 0;
            break;

         case '1':
            process_mode = 1;
            break;

         case '2':
            process_mode = 2;
            break;

         case '3':
            process_mode = 3;
            break;

         case '4':
            process_mode = 4;
            break;
      }
   }
}


/*--------------------------------------------------------------------------- loc_cycle_palettes() */
static void loc_cycle_palettes(void) {
   sU32 *pal = mem_palettes;// + ((iter & 255) << 8);
   sUI i;

   for(i=0; i<256; i++)
   {
      sUI x;
      sU32 t;

      //x = iter % 254;
      for(x=0; x<254; x++)
      {
         t = pal[x];
         pal[x] = pal[x+1];
         pal[x+1] = t;
      }

      
      pal += 256;
   }
}


/*--------------------------------------------------------------------------- main() */
int main(int argc, char**argv) {
   int ret;

   if(0)
   {
      sU16 a = 0;

      sUI i;
      for(i=0; i<256; i++)
      {
         sS32 v = S_SINX_VSCLADD_2I(a, 255, 0);
         //sS32 v = S_MULX1_3_12(S_2X1_3_12(), s_fix1_3_12_sin((sU16)(a)));
         
         //sF32 v = s_fix1_3_12_sin(a) / 4096.0f;
         //printf("a=%d, v=%f\n", a, v);

         //sS32 v = s_fix1_3_12_sin(a);
         printf("a=%d, v=%d\n", a, v);

         a += (65536 / 256);
      }
      return 0;
   }

   if(1 == argc)
   {
      loc_usage();

      /////return 0;
   }

   if(argc > 1)
   {
      if(!strcmp(argv[1], "-h"))
      {
         loc_usage();
         return 0;
      }

      sscanf(argv[1], "%d", &process_mode);

      if(process_mode >= NUM_PROCESS_MODES)
      {
         process_mode = NUM_PROCESS_MODES - 1;
      }

      if(argc > 2)
      {
         sscanf(argv[2], "%d", &num_iterations);

         if(num_iterations < 0)
         {
            num_iterations = 0;
         }
         else if(num_iterations > MAX_ITERATIONS)
         {
            num_iterations = MAX_ITERATIONS;
         }

         if(argc > 3)
         {
            sscanf(argv[3], "%d", &b_vsync);
         }
      }
   }

   /* Open client connection */
   ret = dsp_open();
         
   if(0 == ret)
   {
      log_printf(LOG_INFO " #iterations: %u\n", num_iterations);
      log_printf(LOG_INFO "       vsync: %s\n", b_vsync ? "YES" : "NO");

      srand(osal_milliseconds_get());
        
      /* Allocate contiguous memory block */
      shm = dsp_shm_alloc(DSP_CACHE_R,
                          SHM_SIZE
                          );

      if(0 != shm.size)
      {
         msp = dsp_mspace_create(shm.virt_addr, SHM_SIZE);

         if(NULL != msp)
         {
            dlist = dsp_mspace_malloc(msp, DLIST_SIZE);

            dlist_gen = dlist;
            dlist_render = dlist + DLIST_SIZE/2;

            fb_chunky = malloc(SRC_W * SRC_H);

            /* Allocate bitplanes */
            {
               sUI i;

               for(i=0; i<8; i++)
               {
                  mem_bitplanes[i] = dsp_mspace_malloc(msp, (SRC_W / 16u) * SRC_H * sizeof(sU16));
               }
            }

            /* Allocate palettes */
            mem_palette_gray = dsp_mspace_malloc(msp, 256 * sizeof(sU32));
            mem_palettes = dsp_mspace_malloc(msp, 256 * sizeof(sU32) * NUM_PALS);

            loc_bpl_and_pal_init();

            fshm_pal = dsp_l1sram_alloc(256 * sizeof(sU32));

            if(0 != fshm_pal.size)
            {
               iter = 0;
               sU32 tStart;
               sU32 tEnd;
               
               if(loc_lazy_load_components())
               {
                  if(0 == hal_init(HAL_INIT_VIDEO, DST_W, DST_H))
                  {
                     hal_event_key_fxn = &loc_onkey;
                     
                     if(loc_video_init())
                     {
                        if(loc_init())
                        {
                           
                           tStart = osal_milliseconds_get();
                           
                           while(hal_running())
                           {
                              hal_event_process();
                              
                              loc_frame_begin();
                              
                              //if(0 == i)
                              {
                                 switch(process_mode) 
                                 {
                                    default:
                                    case PROCESS_MODE_BITMAP:
                                       loc_gen_dlist_0();
                                       break;

                                    case PROCESS_MODE_BITMAP_SCROLLSCR:
                                       loc_gen_dlist_1();
                                       break;
                                       
                                    case PROCESS_MODE_BITMAP_SCROLLSCNLINES:
                                       loc_gen_dlist_2();
                                       break;
                                       
                                    case PROCESS_MODE_BITMAP_SCROLLSCNLINES_PAL:
                                       loc_gen_dlist_3();
                                       break;

                                    case PROCESS_MODE_BITMAP_SCROLLSCNLINES_PAL_YSIN:
                                       loc_gen_dlist_4();
                                       break;
                                 }
                              }
                              
                              if(iter > 0)
                              {
                                 /* Wait for DSP */
                                 loc_frame_end();
                              }
                              
                              /* Send msg to DSP */
                              {
                                 dsp_msg_t msg;
                                 
                                 DSP_MSG_INIT(&msg, compid_age, AGE_CMD_PROCESS,
                                              dsp_virt_to_phys(dlist_gen),
                                              0
                                           );
                                 
                                 dsp_rpc_send(&msg);
                              }

                              {
                                 sU32 *t = dlist_gen;
                                 
                                 dlist_gen = dlist_render;
                                 dlist_render = t;
                              }

                              if(0)
                              {
                                 loc_cycle_palettes();
                              }

                              iter++;

                              if(0 != num_iterations)
                              {
                                 if(iter >= num_iterations)
                                 {
                                    hal_stop();
                                 }
                              }
                              
                           } /* while hal_running() */
                           
                           /* Wait for DSP */
                           loc_frame_end();
                           
                           tEnd = osal_milliseconds_get();
                           
                           log_printf(LOG_INFO "%u iterations in %u millisecs.\n", iter, (tEnd - tStart));
                           
                           log_printf(LOG_INFO " ==> avg FPS=%.3f\n",
                                      (1000.0f / ((tEnd - tStart) / ((sF32)iter)))
                                   );
                           
                           loc_exit();
                        }
                        else
                        {
                           /* Failed: loc_init() */
                           log_printf(LOG_ERROR "loc_init() failed.\n");
                        }

                        loc_video_exit();

                     } /* video_init*/
                  } /* hal_init */
               }
               else
               {
                  /* Failed: loc_lazy_load_components() */
                  log_printf(LOG_ERROR "failed to load/query required DSP components.\n");
               }
               
               //usleep(1000000 * 1);
               
               dsp_l1sram_free(fshm_pal);
            }
            else
            {
               /* Failed: dsp_l1sram_alloc() */
               log_printf(LOG_ERROR "failed to allocate L1SRAM for palettes\n");
            }

            free(fb_chunky);

            dsp_mspace_destroy(msp);
         }
         else
         {
            log_printf(LOG_ERROR "failed to create mspace\n");
         }


         /* Free contiguous memory block */
         dsp_shm_free(shm);

      } /* if dsp_shm_alloc() */

      /* Disconnect client */
      dsp_close();
      
   }
   else
   {
      /* Failed: dsp_open() */
      ret = 10;
   }

   return ret;
}
