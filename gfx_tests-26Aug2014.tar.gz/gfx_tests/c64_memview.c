/* ----
 * ---- file   : memview.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          Distributed under terms of the LESSER GNU GENERAL PUBLIC LICENSE (LGPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#LGPL or COPYING_LGPL for further information.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 10Nov2013, 11Nov2013, 19Nov2013, 20Nov2013, 11Dec2013
 * ----
 * ----
 */

/// If defined, use ARGB32 overlay, RGB565 overlay otherwise.
//#define USE_ARGB32 defined

//#define USE_VSYNC defined


#include <stdio.h>
#include <string.h>

#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>

#include <inc_libc64.h>

#include <components/demo_checksum/demo_checksum.h>

#include "inc_hal.h"
#include "omapfb.h"

#define VIEW_W  (256u)
#define VIEW_H  (256u)

#ifdef USE_ARGB32
#define VIEW_BPP  (4u)
#else
#define VIEW_BPP  (2u)
#endif /* USE_ARGB32 */


#define VIEW_MEM_SIZE  (512u * 1024u * 1024u)
#define VIEW_NUM_MAPS  (VIEW_W * VIEW_H)
#define VIEW_MAP_SIZE  (VIEW_MEM_SIZE / VIEW_NUM_MAPS)



/*--------------------------------------------------------------------------- module vars */
static dsp_mem_region_t shm;

static dsp_mem_region_t shm_vid;

static dsp_component_id_t compid_demo_checksum;

#ifdef USE_ARGB32
static sU32 *fb_data;
static sU32 *old_fb;
static sU32 *new_fb;
#endif /* USE_ARGB32 */

struct mem_gpp_s {
   dsp_mem_region_t mem_pix_old;
   dsp_mem_region_t mem_pix_new;

   sU8 block_idx_tbl[128];
   sU8 block_tbl_idx;

   sU8 block_idx_delta_data[VIEW_W*VIEW_H*2];
   sU8 *block_idx_delta_new;
   sU8 *block_idx_delta_old;

   sU32 t_update_inc_gpp;
   sU32 t_update_inc_dsp;

   sBool b_inc_first_run;

   sU8 haveTbl[128];

   sU32 tStart;
   sU32 tEnd;

   sU32 updateInterval;
   sS32 milliSecUntilUpdate;
   sU32 milliSecEllapsed;

   sU32 tStart_main;

   sBool b_color_key;

};

static dsp_mem_region_t shm_gpp;

#define MEM_GPP(a)  ((struct mem_gpp_s*)shm_gpp.virt_addr)->a



/*--------------------------------------------------------------------------- loc_block_idx_tbl_init() */
static void loc_block_idx_tbl_init(void) {
   sU8 idx;

#if 0
   for(idx=0; idx<128; idx++)
   {
      MEM_GPP->block_idx_tbl[idx] = idx;
   }
#else

   {
#if 0
      MEM_GPP(tStart) = osal_milliseconds_get();
#endif

      memset(MEM_GPP(haveTbl), 0, 128);

      for(idx=0; idx<128; idx++)
      {
         sU8 c;

         for(;;)
         {
            c = (sU8) (rand()&127);

            if(!MEM_GPP(haveTbl)[c])
            {
               MEM_GPP(haveTbl)[c] = 1;
               break;
            }
         }

         MEM_GPP(block_idx_tbl)[idx] = c;
      }

#if 0
      log_printf(LOG_DEBUG "xxx create idx_tbl took %u ms\n",
                 (osal_milliseconds_get() - MEM_GPP(tStart))
                 );
#endif
   }
#endif
}


/*--------------------------------------------------------------------------- loc_lazy_load_components() */
sBool loc_lazy_load_components(void) {
   sBool ret = S_FALSE;

   /* Dynamically load "demo_checksum" DSP component */
   if(0 == dsp_component_load(NULL, COMPONENT_NAME_DEMO_CHECKSUM, &compid_demo_checksum))
   {
      /* Succeeded */
      ret = S_TRUE;
   }

   return ret;
}


/*--------------------------------------------------------------------------- loc_memview_update() */
#ifdef USE_ARGB32
static void loc_memview_update(void) {
   //sU32 *d = (sU32*) shm_vid.virt_addr;
   sUI numFailed = 0;
   int fd;

   fd = open("/dev/mem", O_RDONLY);

   if(-1 != fd)
   {
      log_printf(LOG_INFO "loc_memview_update: MEM_SIZE=0x%08x\n", VIEW_MEM_SIZE);
      log_printf(LOG_INFO "loc_memview_update: MAP_SIZE=0x%08x\n", VIEW_MAP_SIZE);
      log_printf(LOG_INFO "loc_memview_update: NUM_MAPS=%u\n", VIEW_NUM_MAPS);
      
      //printf("xxx d=0x%p\n", d);
      
      if(0)
      {
         sU32 *t = malloc(1024*1024 * 64);
         
         memset(t, rand()&255, 1024*1024*64);
         
         ///dsp_cache_wbinvall();
         
         free(t);
      }
      
     
      {
         ////dsp_mem_region_t shm = dsp_shm_alloc(DSP_CACHE_NONE, 4096);
         
         ////if(shm.size > 0)
         {
            demo_checksum_cmd_add32_dma_args_t *dsp_args = (void*) shm.virt_addr;
            
            dsp_msg_t msg;
            dsp_msg_t reply;
            
            sUI iter;
            
            sU32 offset = 0x80000000u;
            
            sU32 tStart;
            
#define VIEW_NUM_PIX_PER_ITER (1024)
#define VIEW_NUM_ITERATIONS   (VIEW_NUM_MAPS / VIEW_NUM_PIX_PER_ITER)
            
            log_printf(LOG_INFO "loc_memview_update: NUM_PIX_PER_ITER=%u\n", VIEW_NUM_PIX_PER_ITER);
            log_printf(LOG_INFO "loc_memview_update:   NUM_ITERATIONS=%u\n", VIEW_NUM_ITERATIONS);

            tStart = osal_milliseconds_get();
            
            for(iter=0; iter < VIEW_NUM_ITERATIONS; iter++)
            {
               dsp_args->phys_addr_src            = offset;
               dsp_args->num_dwords_per_iteration = (VIEW_MAP_SIZE >> 2);
               dsp_args->num_iterations           = (VIEW_NUM_PIX_PER_ITER);
               dsp_args->phys_addr_dst            = shm_vid.phys_addr + (iter * VIEW_NUM_PIX_PER_ITER * sizeof(sU32));

               //printf("xxx offset DSP=0x%08x\n", offset);
               
               /* Initialize DSP remote procedure call message */
               DSP_MSG_INIT(&msg, compid_demo_checksum, DEMO_CHECKSUM_CMD_ADD32_DMA,
                            shm.phys_addr, 0
                            );

               iter++;
               offset += (VIEW_MAP_SIZE * VIEW_NUM_PIX_PER_ITER);

               //printf("xxx offset GPP=0x%08x  iter=%u\n", offset, iter);
               
               if(0 == dsp_rpc_send(&msg))
               {
                  void *virt;
                  sU32 *d = (sU32 *) (shm_vid.virt_addr + (iter * VIEW_NUM_PIX_PER_ITER * sizeof(sU32)));
                  sUI pix;

                  virt = mmap(0,  /* addr */
                              (VIEW_MAP_SIZE * VIEW_NUM_PIX_PER_ITER),
                              (PROT_READ | PROT_WRITE),
                              MAP_PRIVATE,
                              fd,
                              offset
                              );

                  if(MAP_FAILED != virt)
                  {
                     sU32 *s = virt;
                     
                     for(pix=0; pix < VIEW_NUM_PIX_PER_ITER; pix++)
                     {
                        sUI pixIdx;

#if 0
                        sU32 avg = 0;
                        
                        for(pixIdx=0; pixIdx < (VIEW_MAP_SIZE >> 2); pixIdx++)
                        {
                           avg = (avg >> 1) + (s[pixIdx] >> 1);
                        }
                        
                        d[pix] = avg;
#else
                        sU32 add = 0;
                        
                        for(pixIdx=0; pixIdx < (VIEW_MAP_SIZE >> 2); pixIdx++)
                        {
                           add += s[pixIdx];
                        }
                        
                        d[pix] = add;
#endif

                        s += (VIEW_MAP_SIZE >> 2);
                     }

                     munmap(virt, (VIEW_MAP_SIZE * VIEW_NUM_PIX_PER_ITER));
                  }
                  else
                  {
                     numFailed++;
                  }

                  if(0 == dsp_rpc_recv(&reply))
                  {
                  }
                  else
                  {
                     numFailed++;
                  }
                        
               }
               else
               {
                  numFailed++;
               }
               
               offset += (VIEW_MAP_SIZE * VIEW_NUM_PIX_PER_ITER);

            } /* for iter */

            {
               sU32 tDelta = (osal_milliseconds_get() - tStart);

               log_printf(LOG_INFO "loc_memview_update: %.3f MBytes in %u millisecs.\n",
                          (VIEW_MEM_SIZE / (1024.0f * 1024.0f)),
                          tDelta
                          );
            }
                  
            ////dsp_shm_free(shm);
         }
      }

      close(fd);

      log_printf(LOG_INFO "loc_memview_update: done (numFailed=%u)\n", numFailed);
   }
   else
   {
      log_printf(LOG_ERROR "loc_memview:update: failed to open /dev/mem.\n");
   }

}
#endif /* USE_ARGB32 */


/*--------------------------------------------------------------------------- loc_memview_update_inc() */
static void loc_memview_update_inc(void) {

/*    log_printf(LOG_INFO "loc_memview_update_inc: MEM_SIZE=0x%08x\n", VIEW_MEM_SIZE); */
/*    log_printf(LOG_INFO "loc_memview_update_inc: MAP_SIZE=0x%08x\n", VIEW_MAP_SIZE); */
/*    log_printf(LOG_INFO "loc_memview_update_inc: NUM_MAPS=%u\n", VIEW_NUM_MAPS); */
  
   demo_checksum_cmd_addskip32_dma_args_t *args = (void*) shm.virt_addr;
   dsp_msg_t msg;
   dsp_msg_t reply;

#define AS32_NUM_BYTES_PER_BLOCK       (  64u)
#define AS32_ADV_BYTES_PER_BLOCK       (8192u)
#define AS32_NUM_BLOCKS_PER_ITERATION  ( 128u)
#define AS32_NUM_ITERATIONS            ( 512u)

   args->phys_addr_src            = 0x80000000u + (AS32_NUM_BYTES_PER_BLOCK * MEM_GPP(block_idx_tbl)[MEM_GPP(block_tbl_idx)]);
   args->num_bytes_per_block      = AS32_NUM_BYTES_PER_BLOCK;
   args->adv_bytes_per_block      = AS32_ADV_BYTES_PER_BLOCK;
   args->num_blocks_per_iteration = AS32_NUM_BLOCKS_PER_ITERATION;
   args->num_iterations           = AS32_NUM_ITERATIONS;
   args->phys_addr_dst            = MEM_GPP(mem_pix_new).phys_addr;
   args->b_add_to_dst             = 0;/////(0 != block_idx);

   /* Initialize DSP remote procedure call message */
   DSP_MSG_INIT(&msg,
                compid_demo_checksum, DEMO_CHECKSUM_CMD_ADDSKIP32_DMA,
                shm.phys_addr, 0
                );

   if(0 == dsp_rpc(&msg, &reply))
   {
   }
   else
   {
      log_printf("[---] loc_mem_view_update_inc: dsp_rpc() failed.\n");
   }
}


/*--------------------------------------------------------------------------- loc_update_and_compare_inc() */
static void loc_update_and_compare_inc(void) {

   //printf("xxx block_idx=%u\n", block_idx);
   
   MEM_GPP(tStart) = osal_milliseconds_get();

   loc_memview_update_inc();

   MEM_GPP(tEnd) = osal_milliseconds_get();

   MEM_GPP(t_update_inc_dsp) = (MEM_GPP(tEnd) - MEM_GPP(tStart));

   //log_printf("xxx DSP update_inc took %u millisec\n", t_update_inc_dsp);


   MEM_GPP(tStart) = MEM_GPP(tEnd);
   
   {
      /* Highlight changes */
#ifdef USE_ARGB32
      sU32 *d        = (sU32*) shm_vid.virt_addr;
#else
      sU16 *d        = (sU16*) shm_vid.virt_addr;
#endif /* USE_ARGB32 */
      sU32 *sNew     = (sU32*) MEM_GPP(mem_pix_new).virt_addr;
      sU8   blockIdx =         MEM_GPP(block_idx_tbl)[MEM_GPP(block_tbl_idx)];
      sU32 *sOld     = (sU32*) (MEM_GPP(mem_pix_old).virt_addr + blockIdx * (VIEW_W*VIEW_H*4));
      sUI i;

      dsp_cache_inv_virt(sNew, (VIEW_W*VIEW_H*4));

      if(MEM_GPP(b_inc_first_run))
      {
         if(MEM_GPP(b_inc_first_run))
         {
            log_printf(".");
         }

         for(i=0; i<(VIEW_W*VIEW_H); i++)
         {
            d[i] = (i & 1) ^ ((i >> 8)&1);
         }
      }
      else
      {
         for(i=0; i<(VIEW_W*VIEW_H); i++)
         {
            if(sOld[i] == sNew[i]) // unchanged now ?
            {
               if(d[i] > 1u)
               {
                  if(MEM_GPP(block_idx_delta_old)[i] == blockIdx) // set by last ?
                  {
                     if(MEM_GPP(block_idx_delta_new)[i] == 255)
                     {
                        d[i] = (i & 1) ^ ((i >> 8)&1);
                     }
                  }
               }
            }
            else
            {
#ifdef USE_ARGB32
               if(d[i] == 0xFFFF0000u)
               {
                  d[i] =  0xFFaFff00u;
               }
               else
               {
                  d[i] = 0xFFFF0000u;
               }
#else
               if(d[i] == 0xF800u)
               {
                  d[i] =  0xAFE0u;
               }
               else
               {
                  d[i] = 0xF800u;
               }
#endif /* USE_ARGB32 */

               MEM_GPP(block_idx_delta_new)[i] = blockIdx;
            }
         }
      }

      /* (todo) optimize (use copy by ref) */
      memcpy(sOld, sNew, (VIEW_W*VIEW_H*4));
   }

   MEM_GPP(tEnd) = osal_milliseconds_get();

   MEM_GPP(t_update_inc_gpp) = (MEM_GPP(tEnd) - MEM_GPP(tStart));

   //log_printf("xxx GPP update_inc took %u millisec\n", (tEnd - tStart));

   MEM_GPP(block_tbl_idx)++;

   if(128 == MEM_GPP(block_tbl_idx))
   {
      if(MEM_GPP(b_inc_first_run))
      {
         MEM_GPP(b_inc_first_run) = S_FALSE;

         log_printf("\n");
      }

      MEM_GPP(block_tbl_idx) = 0;

      loc_block_idx_tbl_init();

      /* Swap new/old buffers */
      {
         sU8 *t = MEM_GPP(block_idx_delta_old);
         
         MEM_GPP(block_idx_delta_old) = MEM_GPP(block_idx_delta_new);
         MEM_GPP(block_idx_delta_new) = t;

         memset(MEM_GPP(block_idx_delta_new), 255, VIEW_W*VIEW_H);
      }
   }
}


/*--------------------------------------------------------------------------- loc_update_and_compare() */
#ifdef USE_ARGB32
static void loc_update_and_compare(void) {
   ////memcpy(old_fb, (void*)shm_vid.virt_addr, VIEW_W*VIEW_H*4);
   
   loc_memview_update();
   
   memcpy(new_fb, (void*)shm_vid.virt_addr, VIEW_W*VIEW_H*4);

   /* Highlight changes */
   {
      sUI i;
      sU32 *d = (sU32*)shm_vid.virt_addr;
      
      for(i=0; i<(VIEW_W*VIEW_H); i++)
      {
         if(old_fb[i] != new_fb[i])
         {
            d[i] = 0xFFFF0000;
         }
         else
         {
            d[i] = 0;
         }
      }
   }

   {
      sU32 *t = old_fb;

      old_fb = new_fb;
      new_fb = t;
   }

}
#endif /* USE_ARGB32 */


/*--------------------------------------------------------------------------- loc_onkey() */
static void loc_onkey(sU32 _sym, sU32 _mod, sBool _bPressed) {

   printf("[dbg] loc_onkey: sym=0x%08x mod=0x%08x bPressed=%d\n",
          _sym,
          _mod,
          _bPressed
          );

   if(_bPressed)
   {
      if('q' == _sym)
      {
         hal_stop();
      }
      else if(' ' == _sym)
      {
#ifdef USE_ARGB32
         if(0)
         {
            loc_update_and_compare();
         }
         else
#endif /* USE_ARGB32 */
         {
            loc_update_and_compare_inc();
         }
      }
   }
}


/*--------------------------------------------------------------------------- main() */
int main(int argc, char**argv) {

   if(0 == dsp_open())
   {
      if(loc_lazy_load_components())
      {
         if(0 == hal_init(HAL_INIT_VIDEO, VIEW_W, VIEW_H))
         {
            hal_event_key_fxn = &loc_onkey;

            omapfb_set_default_plane_idx(OMAPFB_VID2);
            
            if(omapfb_init(0, 0, // position
                           VIEW_W, VIEW_H,
                           VIEW_W, VIEW_H, // zoomed size
                           ////VIEW_W*2, 480, // zoomed size
                           VIEW_W, VIEW_H, // virtual size
#ifdef USE_ARGB32
                           32,
#else
                           16,
#endif /* USE_ARGB32 */
                           S_FALSE  /* disable desktop layer */
                           )
               )
            {
               shm = dsp_shm_alloc(DSP_CACHE_R, 4096 + VIEW_W*VIEW_H*4 * (128 + 1));
                  
               if(shm.size > 0)
               {
                  memset((void*)shm.virt_addr, 0, shm.size);

                  shm_gpp = dsp_shm_alloc(DSP_CACHE_RW, 1024*1024);

                  if(shm_gpp.size > 0)
                  {
                     memset((void*)shm_gpp.virt_addr, 0, shm_gpp.size);

                     MEM_GPP(updateInterval) = 16u;

                     MEM_GPP(b_color_key) = 1;

                     if(argc > 1)
                     {
                        sscanf(argv[1], "%u", &MEM_GPP(updateInterval));
                        
                        printf("[...] memview update interval set to %u millisecs\n", MEM_GPP(updateInterval));

                        if(argc > 2)
                        {
                           sscanf(argv[2], "%d", &MEM_GPP(b_color_key));

                           printf("[...] memview b_color_key set to %d\n", MEM_GPP(b_color_key));
                        }
                     }

                     MEM_GPP(mem_pix_new).virt_addr = (shm.virt_addr + 4096);
                     MEM_GPP(mem_pix_new).phys_addr = (shm.phys_addr + 4096);
                     MEM_GPP(mem_pix_new).size      = (VIEW_W * VIEW_H * 4);
                     
                     MEM_GPP(mem_pix_old).virt_addr = MEM_GPP(mem_pix_new).virt_addr + MEM_GPP(mem_pix_new).size;
                     MEM_GPP(mem_pix_old).phys_addr = MEM_GPP(mem_pix_new).phys_addr + MEM_GPP(mem_pix_new).size;
                     MEM_GPP(mem_pix_old).size      = MEM_GPP(mem_pix_new).size * 128;
                     
                     if(MEM_GPP(b_color_key))
                     {
                        omapfb_color_key_set(0x00000000u, S_FALSE /*vidSrc*/);
                        omapfb_color_key_set(0x00000000u, S_TRUE /*vidSrc*/);
                     }
                     
                     shm_vid = omapfb_plane_get_dsp_mem(OMAPFB_VID2);
                     
                     memset((void*)shm_vid.virt_addr, 0, shm_vid.size);
                     
#ifdef USE_ARGB32
                     fb_data = malloc(VIEW_W * VIEW_H * 4 * 2);
                     
                     old_fb = fb_data;
                     new_fb = fb_data + (VIEW_W * VIEW_H);
#endif /* USE_ARGB32 */
                     
                     memset(MEM_GPP(block_idx_delta_data), 0, VIEW_W*VIEW_H*2);
                     MEM_GPP(block_idx_delta_new) = MEM_GPP(block_idx_delta_data);
                     MEM_GPP(block_idx_delta_old) = MEM_GPP(block_idx_delta_data) + (VIEW_W*VIEW_H);
                     
                     loc_block_idx_tbl_init();
                     
#ifdef USE_ARGB32
                     loc_memview_update();
#endif /* USE_ARGB32 */
                     
                     MEM_GPP(b_inc_first_run) = S_TRUE;
                     
#ifdef USE_ARGB32
                     memcpy(old_fb, (void*)shm_vid.virt_addr, VIEW_W*VIEW_H*4);
#endif /* USE_ARGB32 */
                     
                     if(0 != MEM_GPP(updateInterval))
                     {
                        MEM_GPP(milliSecUntilUpdate) = (sS32) (MEM_GPP(updateInterval));
                        
                        MEM_GPP(tStart_main) = osal_milliseconds_get();
                     }
                     else
                     {
                        /* workaround to suppress compiler warnings */
                        MEM_GPP(milliSecUntilUpdate) = 0;
                        MEM_GPP(tStart_main) = 0;
                     }
                     
                     while(hal_running())
                     {
                        hal_event_process();
                        
                        if(MEM_GPP(b_inc_first_run))
                        {
                           loc_update_and_compare_inc();
                        }
                        else
                        {
                           if(0 != MEM_GPP(updateInterval))
                           {
                              MEM_GPP(milliSecEllapsed) = (osal_milliseconds_get() - MEM_GPP(tStart_main));

                              if(MEM_GPP(milliSecEllapsed) >= MEM_GPP(milliSecUntilUpdate))
                              {
#ifdef USE_ARGB32
                                 if(0)
                                 {
                                    loc_update_and_compare();
                                 }
                                 else
#endif /* USE_ARGB32 */
                                 {
                                    loc_update_and_compare_inc();
                                 }

#ifdef USE_VSYNC
                                 hal_video_flip();
#endif
                                 
                                 MEM_GPP(tStart_main) = osal_milliseconds_get();
                              }
                              else
                              {
                                 osal_msleep(MEM_GPP(milliSecUntilUpdate) - MEM_GPP(milliSecEllapsed));
                              }
                           }
                         

                        }
                     }
                  
#ifdef USE_ARGB32
                     free(fb_data);
#endif /* USE_ARGB32 */

                     dsp_shm_free(shm_gpp);
                     
                  }

                  dsp_shm_free(shm);
               }
               else
               {
                  log_printf(LOG_ERROR "dsp_shm_alloc() failed.\n");
               }

               omapfb_exit();
            }
            
            hal_exit();
         }
      }
      else
      {
         log_printf(LOG_ERROR "failed to load required DSP components.\n");
      }
         
      dsp_close();
   }

   return 0;
}
