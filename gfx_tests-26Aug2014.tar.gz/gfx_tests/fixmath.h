/* ----
 * ---- file   : fixmath.h
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          Distributed under terms of the GNU GENERAL PUBLIC LICENSE (GPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#GPL or COPYING for further information.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 05Dec2013
 * ----          
 * ----
 * ----
 */

#ifndef __FIXMATH_H__
#define __FIXMATH_H__


typedef sS32 sX;       /* "sign bit" + 15 integer bits + 16 fractional bits (2s complement) */
//typedef sU16 sX0_16;   /* "no sign bit" / 16 fractional bits */
//typedef sS16 sX1_15;   /* "sign bit" + 15 fractional bits (2s complement) */
typedef sS16 sX1_3_12; /* "sign bit" + 3 integer bits + 12 fractional bits (2s complement) */

#define S_2X(a) ((sX)((a) * 65536))
#define S_2I(a) ((sS32)((a) >> 16))
#define S_2F(a) ((sF32)((a) / 65536.0f))

#define S_2X16U(a) ((sU16)((a) * 65536))
#define S_2X16S(a) ((sS16)((a) * 65536))

#define S_2X1_3_12(a) ((sX1_3_12)((a) * 4096))
#define S_X1_3_12_2I(a) ((sS32)((a) >> 12))
#define S_X1_3_12_2F(a) ((sF32)((a) / 4096.0f))

//#define S_2X0_16(a)   ((sX0_16) ((a) * 65536))
//#define S_2X1_15(a)   ((sX1_15) ((a) * 32768))

#define S_MULX(a, b)  ((((sS64)(a)) * (b)) >> 16)
#define S_DIVX(a, b)  ((((sS64)(a)) * 65536) / (b))

#define S_MULX1_3_12(a, b)  ((((sS32)(a)) * (b)) >> 12)
#define S_DIVX1_3_12(a, b)  ((((sS32)(a)) * 4096) / (b))

/* a = [0..65535] (0..2PI)
 * returns integer val
 */
#define S_SINX(a) (s_fix1_3_12_sin(a) << 4)

#define S_SINX_VSCLADD(a, scl, add) \
   S_2X(add) + S_MULX(S_2X(scl), s_fix1_3_12_sin((sU16)(a)) << 4)

#define S_SINX_VSCLADD_2I(a, scl, add) \
   S_2I(S_2X(add) + S_MULX(S_2X(scl), s_fix1_3_12_sin((sU16)(a)) << 4))

#define S_SINX_XSCLADD(a, scl, add) \
   (add + S_MULX(scl, s_fix1_3_12_sin((sU16)(a)) << 4))

#define S_SINX_XSCLADD_2I(a, scl, add) \
   S_2I(add + S_MULX(scl, s_fix1_3_12_sin((sU16)(a)) << 4))
      
/* angle 0..2PI to 0..65536 */
#define S_RAD2X(a) ((sS32)(((a) * (65536.0f / S_2PI))))


/* Calculate sine value
 *
 * (note) angle 0..65536 => 0..360�
 * (note) returned value is in -4096..4096 (=> -1.0 .. 1.0) range
 *
 */
S_EXTERN sX1_3_12 fix1_3_12_sintab[129];
S_INLINE sX1_3_12 s_fix1_3_12_sin(sU16 _angle) {
   sX1_3_12 r;
   sS16 lamount = (sS16) (_angle & 127);
   sU8  idx = (sU8) ( (_angle >> 7) & 127 );
   
   if(_angle & 0x4000)
   {
      /* 90..180� */
      sS16 rval = fix1_3_12_sintab[128 - idx];
      sS16 lval = fix1_3_12_sintab[127 - idx];
      r = lval + ( ( ((sX1_3_12)(rval - lval)) * ((sX1_3_12)(127 - lamount)) ) >> 7 );
   }
   else
   {
      /* 0..90� / 270..360� */
      sX lval = fix1_3_12_sintab[idx];
      sX rval = fix1_3_12_sintab[idx + 1];
      r = lval + ( ( ((sX1_3_12)(rval - lval)) * ((sX1_3_12)lamount) ) >> 7 );
   }

   if(_angle & 0x8000)
   {
      r = -r;
   }

   return r;
}


#endif /* __FIXMATH_H__ */
