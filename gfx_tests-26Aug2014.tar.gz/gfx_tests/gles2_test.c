/* ----
 * ---- file   : gles2_test.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          Distributed under terms of the LESSER GNU GENERAL PUBLIC LICENSE (LGPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#LGPL or COPYING_LGPL for further information.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 08Nov2013, 09Nov2013, 13Jan2013
 * ----
 * ----
 */

#define FB_W  800
#define FB_H  480

/// If defined, create pbuffer instead of window surface
//#define USE_PBUFFER defined

/// If defined, create RGBA FBO
#define USE_FBO defined

/// (note) SGX requires this to be POT 
#define FBO_W  (1024u)
//#define FBO_W  (256u)
//#define FBO_W  (512u)
//#define FBO_W  (64u)
//#define FBO_W  (32u)

/// (note) SGX requires this to be POT 
//#define FBO_H  (1024u)
//#define FBO_H  (256u)
#define FBO_H  (512u)
//#define FBO_H  (64u)
//#define FBO_H  (32u)

/// If defined, use a 32bits per pixel config instead of 16bit RGB565
///  (note) not supported by SGX driver, at least not when (OMAP) framebuffer is RGB565
//#define USE_ARGB32 defined

//#define NUM_FRAMES_FBO (100u)
#define NUM_FRAMES_FBO (2u)

#define NUM_FRAMES (60u * 10u)
//#define NUM_FRAMES (1000u * 1u)
//#define NUM_FRAMES (10u)


#define FG_COLOR  (0xFF0000FFu)


#include <stdio.h>
#include <string.h>

#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>

#include <EGL/egl.h>
#include <GLES2/gl2.h>
//#define GL_GLEXT_PROTOTYPES defined
//#include <GLES2/gl2ext.h>

#include "../include/types.h"
#include "../include/osal_err.h"
#include "../include/osal.h"
#include "../include/log.h"
#include "../include/dsp_common.h"
#include "omapfb.h"


#define Dcheckeglerror(s) if(S_TRUE) { GLenum err = eglGetError(); if(EGL_SUCCESS != err) printf("%s() returned EGL error %d (0x%08x) in file \"%s\", line %d.\n", #s, err, (sU32)err, __FILE__, __LINE__); } else (void)0


#define Dcheckglerror(s) if(S_TRUE) { GLenum err = glGetError(); if(0 != err) printf("%s() returned GL error %d (0x%08x) in file \"%s\", line %d.\n", #s, err, (sU32)err, __FILE__, __LINE__); } else (void)0


typedef struct {
   GLuint tex_id;
   GLuint fbo_id;
   sU32   w;
   sU32   h;
} gles_fbo_t;


typedef struct {
   GLuint vp_id;
   GLuint fp_id;
   GLuint prg_id;
} gles_shader_t;



/* ----------------------------------------------------------------------------- module vars */
NativeDisplayType native_display;
NativeWindowType  native_window;

EGLDisplay egl_display = NULL;
EGLConfig  egl_config  = NULL;
EGLContext egl_context = NULL;
EGLConfig  egl_config;

EGLSurface egl_window_surface = NULL;

#ifdef USE_PBUFFER
EGLSurface egl_pbuffer_surface = NULL;
#endif



static const EGLint egl_context_attribs[] = {
   EGL_CONTEXT_CLIENT_VERSION, 2,
   EGL_NONE, EGL_NONE
};


static const EGLint egl_window_surface_attribs[] = {
   EGL_RENDER_BUFFER, EGL_BACK_BUFFER,
   //EGL_RENDER_BUFFER, EGL_SINGLE_BUFFER,

   EGL_NONE, EGL_NONE
};


static const EGLint egl_config_attribs[] = {
   EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,

#ifdef USE_ARGB32
   EGL_BUFFER_SIZE, 32,

   EGL_ALPHA_SIZE, 8,
   EGL_RED_SIZE,   8,
   EGL_GREEN_SIZE, 8,
   EGL_BLUE_SIZE,  8,

   EGL_BIND_TO_TEXTURE_RGBA, EGL_TRUE,
#else
   //EGL_BUFFER_SIZE, 16,

   //EGL_ALPHA_SIZE, 0,
   EGL_RED_SIZE,   5,
   EGL_GREEN_SIZE, 6,
   EGL_BLUE_SIZE,  5,

   //EGL_BIND_TO_TEXTURE_RGB,  EGL_TRUE,
   //EGL_BIND_TO_TEXTURE_RGBA, EGL_TRUE,
#endif /* USE_ARGB32 */


   //EGL_STENCIL_SIZE, 0,
   //EGL_DEPTH_SIZE, 0,

   //EGL_NATIVE_RENDERABLE, EGL_TRUE,
   //EGL_NATIVE_RENDERABLE, EGL_FALSE,

   //EGL_MIN_SWAP_INTERVAL, 1,

   EGL_NONE, EGL_NONE
};


#ifdef USE_PBUFFER
static const EGLint egl_pbuffer_attribs[] = {
   EGL_WIDTH,  1024,
   EGL_HEIGHT, 1024,

   EGL_LARGEST_PBUFFER, EGL_TRUE,

   EGL_TEXTURE_TARGET, EGL_TEXTURE_RGBA,
   EGL_TEXTURE_FORMAT, EGL_TEXTURE_2D,

};
#endif /* USE_PBUFFER */


#ifdef USE_FBO
static gles_fbo_t fbo[2];
#else
static GLuint tex_id;

static const GLubyte tex_data[4* 4*4] = {
   0xFF, 0x88, 0xFF, 0xFF,
   0xFF, 0x88, 0xFF, 0xFF,
   0xFF, 0x88, 0xFF, 0xFF,
   0xFF, 0x88, 0xFF, 0xFF,

   0xFF, 0x88, 0xFF, 0xFF,
   0xFF, 0x88, 0xFF, 0xFF,
   0xFF, 0x88, 0xFF, 0xFF,
   0xFF, 0x88, 0xFF, 0xFF,

   0xFF, 0x88, 0xFF, 0xFF,
   0xFF, 0x88, 0xFF, 0xFF,
   0xFF, 0x88, 0xFF, 0xFF,
   0xFF, 0x88, 0xFF, 0xFF,

   0xFF, 0x88, 0xFF, 0xFF,
   0xFF, 0x88, 0xFF, 0xFF,
   0xFF, 0x88, 0xFF, 0xFF,
   0xFF, 0x88, 0xFF, 0xFF,
};


#endif


static struct {
   gles_shader_t shader;

   GLuint uid_color;

   GLuint aid[1]; // 0=position

} shader_solid;

#define SHADER_SOLID_AID_POSITION  (0u)



static struct {
   gles_shader_t shader;

   GLuint aid[2]; // 0=position, 1=color

} shader_varcol;

#define SHADER_VARCOL_AID_POSITION  (0u)
#define SHADER_VARCOL_AID_COLOR     (1u)



static struct {
   gles_shader_t shader;

   GLuint uid_sampler;

   GLuint aid[2]; // 0=position, 1=texcoord

} shader_textured;

#define SHADER_TEXTURED_AID_POSITION  (0u)
#define SHADER_TEXTURED_AID_TEXCOORD  (1u)



/* ----------------------------------------------------------------------------- shaders */

static const char *shader_solid_vp_src = 
   ////"#version 120\n" // => "not supported in this language version (100)"
   "//precision mediump float;  // set default precision\n"
   "\n"
   "attribute highp vec3 attr_position;\n"
   "\n"
   "void main() {\n"
   "   gl_Position = vec4(attr_position.x, attr_position.y, attr_position.z, 1.0);\n"
   "}\n  "
   ;

static const char *shader_solid_fp_src = 
   "precision mediump float;  // set default precision\n"
   "\n"
   "uniform vec4 color;\n"
   "\n"
   "void main() {\n"
   "   gl_FragColor = color;\n"
   //"   gl_FragColor = vec4(0.0, 1.0, 0.0, 1.0);\n"
   "}\n  "
   ;


/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
static const char *shader_varcol_vp_src =
   "#version 100\n"
   "\n"
   "attribute highp vec3 attr_position;\n"
   "attribute mediump vec4 attr_color;\n"
   "\n"
   "varying vec4 var_color;\n"
   "\n"
   "void main() {\n"
   "   gl_Position = vec4(attr_position.x, attr_position.y, attr_position.z, 1.0);\n"
   "   var_color = attr_color;\n"
   "}\n"
   ;

static const char *shader_varcol_fp_src = 
   "precision mediump float;  // set default precision\n"
   "\n"
   "varying vec4 var_color;\n"
   "\n"
   "void main() {\n"
   "   gl_FragColor = var_color;\n"
   "}\n  "
   ;



/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
static const char *shader_textured_vp_src = 
   "#version 100\n"
   "\n"
   "//precision mediump float;  // set default precision\n"
   "\n"
   "attribute highp vec3 attr_position;\n"
   "attribute highp vec2 attr_texcoord;\n"
   "\n"
   "varying vec2 var_texcoord;\n"
   "\n"
   "void main() {\n"
   //"   gl_Position = vec4(attr_position.x, attr_position.y, attr_position.z, 1.0);\n"
   "   gl_Position = vec4(attr_position.xyz, 1.0);\n"
   "   var_texcoord = attr_texcoord;\n"
   "}\n  "
   ;

static const char *shader_textured_fp_src = 
   "#version 100\n"
   "\n"
   "precision mediump float;  // set default precision\n"
   "\n"
   ///"uniform vec4 color;\n"
   "uniform sampler2D sampler;\n"
   "\n"
   "varying vec2 var_texcoord;\n"
   "\n"
   "void main() {\n"
   //"   gl_FragColor = vec4(1.0, 1.0, 0.0, 1.0);\n"
   "   gl_FragColor = texture2D(sampler, var_texcoord);\n"
   //"   gl_FragColor = texture2D(sampler, vec2(0.0, 0.0));\n"
   "}\n  "
   ;




/* ----------------------------------------------------------------------------- gles_shader_destroy() */
void gles_shader_destroy(gles_shader_t *_prg) {

   glUseProgram(0);
   Dcheckglerror(glUseProgram);

   glDetachShader(_prg->prg_id, _prg->fp_id);
   Dcheckglerror(glDetachShader);

   glDetachShader(_prg->prg_id, _prg->vp_id);
   Dcheckglerror(glDetachShader);

   glDeleteProgram(_prg->prg_id);
   Dcheckglerror(glDeleteProgram);
   _prg->prg_id = 0;

   glDeleteShader(_prg->fp_id);
   Dcheckglerror(glDeleteShader);
   _prg->fp_id = 0;

   glDeleteShader(_prg->vp_id);
   Dcheckglerror(glDeleteShader);
   _prg->vp_id = 0;
}


/* ----------------------------------------------------------------------------- gles_shader_bind() */
void gles_shader_bind(gles_shader_t *_prg) {

   glUseProgram(_prg->prg_id);
   Dcheckglerror(glUseProgram);
}


/* ----------------------------------------------------------------------------- gles_shader_uid_get() */
int gles_shader_uid_get(gles_shader_t *_prg,
                        const char *_uniformName,
                        GLuint *_retUniformId
                        ) {

   *_retUniformId = glGetUniformLocation(_prg->prg_id,
                                         _uniformName
                                         );
   Dcheckglerror(glGetUniformLocation);

   return 0;
}


/* ----------------------------------------------------------------------------- gles_shader_create() */
int gles_shader_create(gles_shader_t *_prg,
                       const char *_vpSource,
                       const char *_fpSource,
                       const char *_attribInfos,
                       GLuint *_retAttribIds
                       ) {
   int ret;

   /* Create vertex shader */
   _prg->vp_id = glCreateShader(GL_VERTEX_SHADER);
   Dcheckglerror(glCreateShader);

   glShaderSource(_prg->vp_id, 1, &_vpSource, NULL /* lengths */);
   Dcheckglerror(glShaderSource);

   //printf("xxx vp source:\n\"%s\"\n", _vpSource);


   /* Create fragment shader */
   _prg->fp_id = glCreateShader(GL_FRAGMENT_SHADER);
   Dcheckglerror(glCreateShader);

   glShaderSource(_prg->fp_id, 1, &_fpSource, NULL /* lengths */);
   Dcheckglerror(glShaderSource);


   /* Create program */
   _prg->prg_id = glCreateProgram();
   Dcheckglerror(glCreateProgram);

   glAttachShader(_prg->prg_id, _prg->vp_id);
   Dcheckglerror(glAttachShader);

   glAttachShader(_prg->prg_id, _prg->fp_id);
   Dcheckglerror(glAttachShader);

   /* Compile and attach shaders */
   glCompileShader(_prg->vp_id);
   Dcheckglerror(glCompileShader);

   {
      GLint val;
      char buf[4096];

      glGetShaderiv(_prg->vp_id, GL_COMPILE_STATUS, &val);
      Dcheckglerror(glGetShaderiv);
      
      glGetShaderInfoLog(_prg->vp_id, 4096, NULL, buf);
      Dcheckglerror(glGetShaderInfoLog);
      
      log_printf(LOG_DEBUG "gles_shader_create: glGetShaderInfoLog[VS] returned:\n");
      log_puts(buf);
   }

   glCompileShader(_prg->fp_id);
   Dcheckglerror(glCompileShader);

   {
      GLint val;
      char buf[4096];

      glGetShaderiv(_prg->fp_id, GL_COMPILE_STATUS, &val);
      Dcheckglerror(glGetShaderiv);
      
      glGetShaderInfoLog(_prg->fp_id, 4096, NULL, buf);
      Dcheckglerror(glGetShaderInfoLog);
      
      log_printf(LOG_DEBUG "gles_shader_create: glGetShaderInfoLog[FS] returned:\n");
      log_puts(buf);
   }

 
  
   /* Bind attributes */
   if(NULL != _attribInfos)
   {
      sUI nextAttribIdx = 0;
      sUI numAttribs = 0;
      const char *info = _attribInfos;
      sBool bDone = S_FALSE;
      
      while(!bDone)
      {
         const char *infoStart = info;
         sUI attribSize = 0;
         char attribName[128];
         char attribSizeString[16];

         /* Find start of attrib name */
         attribSizeString[0] = 0;
         attribName[0] = 0;

         while(!bDone)
         {
            char c = *info;

            //printf("xxx off=%u, parse c=\'%c\'\n", (info - _attribInfos), c);

            if(0 == c)
            {
               bDone = S_TRUE;
               break;
            }

            if(':' == c)
            {
               sUI szLen = (sUI) (info - infoStart);

               strncpy(attribSizeString, infoStart, szLen);
               attribSizeString[szLen] = 0;

               sscanf(attribSizeString, "%u", &attribSize);

               _retAttribIds[numAttribs] = nextAttribIdx;

               //printf("xxx attribSize=%u\n", attribSize);

               info++;

               {
                  const char *infoNameStart = info;
               
                  /* Find end of attrib name */
                  for(;;)
                  {
                     c = *info;
                     
                     if(0 == c)
                     {
                        bDone = S_TRUE;
                        break;
                     }


                     if('\n' == c)
                     {
                        break;
                     }

                     info++;
                  }

                  szLen = (info - infoNameStart);

                  //printf("xxx szLen=%u infoNameStart=\"%s\"\n", szLen, infoNameStart);

                  if(szLen > 0)
                  {
                     strncpy(attribName, infoNameStart, szLen);
                     attribName[szLen] = 0;

                     log_printf(LOG_DEBUG "gles_shader_create: binding attrib \"%s\" to location %u.\n",
                                attribName,
                                nextAttribIdx
                                );

                     glBindAttribLocation(_prg->prg_id,
                                          nextAttribIdx,
                                          attribName);
                     Dcheckglerror(glBindAttribLocation);
                  }

                  info++;
               }


               nextAttribIdx += attribSize;
               ////nextAttribIdx ++;
               numAttribs++;

               break;

            } /* if (':' == c) */
            else
            {
               info++;
            }
            
         } /* while(!bDone) (find attrib size start)*/

      } /* while(!bDone) (iterate attribs) */    
   }

  
   /* Link program */
   glLinkProgram(_prg->prg_id);
   Dcheckglerror(glLinkProgram);

   {
      GLint val;

      glGetProgramiv(_prg->prg_id, GL_LINK_STATUS, &val);

      if(GL_TRUE == val)
      {
         log_printf(LOG_INFO "gles_shader_create: ok, program linked successfully.\n");

         /* Succeeded */
         ret = 0;
      }
      else
      {
         log_printf(LOG_ERROR "gles_shader_create: FAILED to link program.\n");

         {
            char buf[4096];

            glGetProgramInfoLog(_prg->prg_id, 4096, NULL, buf);

            log_printf(LOG_DEBUG "gles_shader_create: glGetProgramInfoLog returned:\n");
            log_puts(buf);
         }

         /* Failed */
         ret = 10;
      }
   }

   return ret;
}


/* ----------------------------------------------------------------------------- gles_fbo_destroy() */
#ifdef USE_FBO
static void gles_fbo_destroy(gles_fbo_t *_fbo) {

   /* Unbind FBO */
   glBindFramebuffer(GL_FRAMEBUFFER, 0);

   /* Delete FBO texture */
   glDeleteTextures(1, &_fbo->tex_id);
   _fbo->tex_id = 0;

   /* Delete FBO */
   glDeleteFramebuffers(1, &_fbo->fbo_id);
   _fbo->fbo_id = 0;
}


/* ----------------------------------------------------------------------------- gles_fbo_bind() */
static void gles_fbo_bind(gles_fbo_t *_fbo) {

   if(NULL != _fbo)
   {
      glBindTexture(GL_TEXTURE_2D, 0);
      Dcheckglerror(glBindTexture);
      
      glBindFramebuffer(GL_FRAMEBUFFER, _fbo->fbo_id);
      Dcheckglerror(glBindFramebuffer);
      
      glViewport(0, 0, _fbo->w, _fbo->h);
   }
   else
   {
      glBindTexture(GL_TEXTURE_2D, 0);

      glBindFramebuffer(GL_FRAMEBUFFER, 0);
      Dcheckglerror(glBindFramebuffer);

      glViewport(0, 0, FB_W, FB_H);
      Dcheckglerror(glViewport);
   }
}


/* ----------------------------------------------------------------------------- gles_fbo_create() */
static int gles_fbo_create(gles_fbo_t *_fbo, sU32 _w, sU32 _h, GLenum _format, GLenum _type) {
   GLint fbStatus;
   int ret;

   /*
    *  format: GL_RGB, GL_RGBA
    *    type: GL_UNSIGNED_BYTE, GL_UNSIGNED_SHORT_4_4_4_4, GL_UNSIGNED_SHORT_5_5_5_1, GL_UNSIGNED_SHORT_5_6_5
    */

   glGenTextures(1, &_fbo->tex_id);
   Dcheckglerror(glGenTextures);

   glBindTexture(GL_TEXTURE_2D, _fbo->tex_id);
   Dcheckglerror(glBindTexture);
   
   /* (note) MUST set texture parameters or texture will not be rendered at all! 
    *
    *         Also see www.opengl.org/wiki/Common_Mistakes
    */
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
   glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

      
   glTexImage2D(GL_TEXTURE_2D,
                0,                 /* level */
                _format,           /* internalformat */
                _w,                /* width */
                _h,                /* height */
                0,                 /* border */
                _format,           /* format */
                GL_UNSIGNED_BYTE,  /* type */
                NULL               /* ==> alloc memory */
                );
   Dcheckglerror(glTexImage2D);

   glBindTexture(GL_TEXTURE_2D, 0);
   Dcheckglerror(glBindTexture);

   glGenFramebuffers(1, &_fbo->fbo_id);
   Dcheckglerror(glGenFramebuffers);

   glBindFramebuffer(GL_FRAMEBUFFER, _fbo->fbo_id);
   Dcheckglerror(glBindFramebuffer);

   glFramebufferTexture2D(GL_FRAMEBUFFER,
                          GL_COLOR_ATTACHMENT0,
                          GL_TEXTURE_2D,
                          _fbo->tex_id,
                          0 /* level */
                          );
   Dcheckglerror(glFramebufferTexture2D);

   fbStatus = glCheckFramebufferStatus(GL_FRAMEBUFFER);
   Dcheckglerror(glCheckFramebufferStatus);

   if(GL_FRAMEBUFFER_COMPLETE == fbStatus)
   {
      printf("[...] gles_fbo_create: OK, framebuffer status is COMPLETE.\n");

      //glViewport(0, 0, _w, _h);
      //Dcheckglerror(glViewport);

      _fbo->w = _w;
      _fbo->h = _h;

      /* Succeeded */
      ret = 0;
   }
   else
   {
      printf("[---] gles_fbo_create: ERROR, framebuffer status is %d.\n", fbStatus);

      /* Failed */
      ret = 10;
   }

   return ret;
}
#endif /* USE_FBO */


/* ----------------------------------------------------------------------------- gles_query_print_int() */
static void gles_query_print_int(GLenum _type, const char *_msg) {
   char buf[1024];
   GLenum glErr;
   GLint val;

   /* (todo) check whether _msg contains format string (%d, %u, ..) */

   int l = strlen(_msg);

   if(l > 1000)
   {
      l = 1000;
   }
   
   strncpy(buf, _msg, 900);

   glGetIntegerv(_type, &val);

   glErr = glGetError();

   if(0 == glErr)
   {
      strncpy(buf + l, "%d\n", 123);

      printf(buf, val);
   }
   else
   {
      strncpy(buf + l, "<GL error 0x%08x>\n", 123);

      printf(buf, (sU32)glErr);
   }
}


/* ----------------------------------------------------------------------------- gles_query_print_int2() */
static void gles_query_print_int2(GLenum _type, const char *_msg) {
   char buf[1024];
   GLenum glErr;
   GLint val[2];

   /* (todo) check whether _msg contains format string (%d, %u, ..) */

   int l = strlen(_msg);

   if(l > 1000)
   {
      l = 1000;
   }
   
   strncpy(buf, _msg, 900);

   glGetIntegerv(_type, val);

   glErr = glGetError();

   if(0 == glErr)
   {
      strncpy(buf + l, "(%d; %d)\n", 123);

      printf(buf, val[0], val[1]);
   }
   else
   {
      strncpy(buf + l, "<GL error 0x%08x>\n", 123);

      printf(buf, (sU32)glErr);
   }
}


/* ----------------------------------------------------------------------------- gles_ext_init() */
int gles_ext_init(void) {
   int ret;

   ret = 0;

   return ret;
}


/* ----------------------------------------------------------------------------- gles_exit() */
void gles_exit(void) {

   if(NULL != egl_display)
   {
      eglMakeCurrent(egl_display, NULL, NULL, EGL_NO_CONTEXT);
      Dcheckeglerror(eglMakeCurrent);

      if(NULL != egl_context)
      {
         eglDestroyContext(egl_display, egl_context);
         Dcheckeglerror(eglDestroyContext);

         egl_context = NULL;
      }

#ifdef USE_PBUFFER
      if(NULL != egl_pbuffer_surface)
      {
         eglDestroySurface(egl_display, egl_pbuffer_surface);
         Dcheckeglerror(eglDestroySurface);

         egl_pbuffer_surface = NULL;
      }
#endif

      if(NULL != egl_window_surface)
      {
         eglDestroySurface(egl_display, egl_window_surface);
         Dcheckeglerror(eglDestroySurface);

         egl_window_surface = NULL;
      }

      eglTerminate(egl_display);

      egl_display = NULL;
   }
}


/* ----------------------------------------------------------------------------- gles_init() */
int gles_init(void) {
   int ret;
   EGLBoolean r;
   EGLint eglVerMaj;
   EGLint eglVerMin;

   egl_display = eglGetDisplay(EGL_DEFAULT_DISPLAY);

   printf("[dbg] egl_display=0x%08x\n", (sU32) egl_display);

   r = eglInitialize(egl_display,
                     &eglVerMaj,
                     &eglVerMin
                     );

   if(0 != r)
   {
      EGLint numCfg = 0;

      printf("[dbg] eglInitialize() returned eglVerMaj=%d eglVerMin=%d\n",
             eglVerMaj, eglVerMin
             );
      Dcheckeglerror(eglInitialize);

      r = eglChooseConfig(egl_display, egl_config_attribs, &egl_config, 1, &numCfg);
      Dcheckeglerror(eglChooseConfig);

      if(0 != r)
      {
         if(numCfg >= 1)
         {
            printf("xxx eglChooseConfig returned numCfg=%u\n", numCfg);

            egl_window_surface = eglCreateWindowSurface(egl_display,
                                                        egl_config,
                                                        NULL,  /* window */
                                                        egl_window_surface_attribs  /* window_attribs */
                                                        );
            Dcheckeglerror(eglCreateWindowSurface);

            if(EGL_NO_SURFACE != egl_window_surface)
            {
               printf("[...] gles_init: ok, got egl_window_surface=0x%08x\n", (sU32)egl_window_surface);

#ifdef USE_PBUFFER
               egl_pbuffer_surface = eglCreatePbufferSurface(egl_display,
                                                             egl_config,
                                                             NULL  /* pbuffer_attribs */
                                                             );
               Dcheckeglerror(eglCreatePbufferSurface);
               
               if(EGL_NO_SURFACE != egl_pbuffer_surface)
               {
                  printf("[...] gles_init: ok, got egl_pbuffer_surface=0x%08x\n", (sU32)egl_pbuffer_surface);
#endif /* USE_PBUFFER */
                  
                  egl_context = eglCreateContext(egl_display,
                                                 egl_config,
                                                 EGL_NO_CONTEXT,
                                                 egl_context_attribs
                                                 );
                  Dcheckeglerror(eglCreateContext);
                  
                  if(EGL_NO_CONTEXT != egl_context)
                  {
                     printf("[...] gles_init: ok, got egl_context=0x%08x\n", (sU32)egl_context);
                     
                     eglMakeCurrent(egl_display, egl_window_surface, egl_window_surface, egl_context);

#ifdef USE_PBUFFER
                     //eglMakeCurrent(egl_display, egl_pbuffer_surface, egl_pbuffer_surface, egl_context);
#endif
                     Dcheckeglerror(eglMakeCurrent);
                     
#if 0
                     /* (note) does not work / no effect */
                     eglSwapInterval(egl_display, 1);
                     Dcheckeglerror(eglSwapInterval);
#endif
                     
                     /* Do some queries */
                     {
                        const GLubyte *str;
                        
                        str = glGetString(GL_VENDOR);
                        Dcheckglerror(glGetString);
                       
                        printf("gles_init: GL_VENDOR = \"%s\".\n", str);
                        

                        str = glGetString(GL_RENDERER);
                        Dcheckglerror(glGetString);
                       
                        printf("gles_init: GL_RENDERER = \"%s\".\n", str);


                        str = glGetString(GL_VERSION);
                        Dcheckglerror(glGetString);
                       
                        printf("gles_init: GL_VERSION = \"%s\".\n", str);

                        // pvr-specific version info:
                        {
                           char buf[1024];

                           FILE *fh;

                           fh = fopen("/proc/pvr/version", "rb");

                           if(NULL != fh)
                           {
                              size_t numRead = fread(buf, 1, 1023, fh);

                              buf[numRead]=0;

                              log_printf("gles_init: PowerVR version:\n");
                              log_puts(buf);

                              fclose(fh);
                           }
                        }


                        str = glGetString(GL_EXTENSIONS);
                        Dcheckglerror(glGetString);
                       
                        printf("gles_init: GL_EXTENSIONS = \"%s\".\n", str);

                        
                        gles_query_print_int(GL_ALPHA_BITS,
                                             "gles_init:        GL_ALPHA_BITS = "
                                             );
                        
                        
                        gles_query_print_int(GL_RED_BITS, 
                                             "gles_init:          GL_RED_BITS = "
                                             );
                        
                        gles_query_print_int(GL_GREEN_BITS, 
                                             "gles_init:        GL_GREEN_BITS = "
                                             );
                        
                        gles_query_print_int(GL_BLUE_BITS, 
                                             "gles_init:         GL_BLUE_BITS = "
                                             );
                        
                        gles_query_print_int(GL_STENCIL_BITS, 
                                             "gles_init:      GL_STENCIL_BITS = "
                                             );
                        
                        gles_query_print_int(GL_DEPTH_BITS,
                                             "gles_init:        GL_DEPTH_BITS = "
                                             );
                        
                        gles_query_print_int(GL_SAMPLE_BUFFERS, 
                                             "gles_init:    GL_SAMPLE_BUFFERS = "
                                             );
                        
                        gles_query_print_int(GL_SAMPLES, 
                                             "gles_init:           GL_SAMPLES = "
                                             );
                        
                        gles_query_print_int2(GL_MAX_VIEWPORT_DIMS, 
                                              "gles_init: GL_MAX_VIEWPORT_DIMS = "
                                              );

#if 0                       
                        gles_query_print_int(GL_MAX_TEXTURE_UNITS, 
                                             "gles_init: GL_MAX_TEXTURE_UNITS = "
                                             );
#endif

                        gles_query_print_int(GL_SHADER_COMPILER, 
                                             "gles_init:   GL_SHADER_COMPILER = "
                                             );
                     }
                  
                     /* Succeeded */
                     
                     {
                        EGLenum eglErr;
                        GLenum glErr;
                        
                        eglErr = eglGetError();
                        glErr  =  glGetError();
                        
                        printf("[dbg] gles_init: ok, eglGetError()=%d (0x%08x), glGetError=%d (0x%08x)\n",
                               eglErr, eglErr,
                               glErr, glErr
                               );
                     }

                     //glViewport(0, 0, FB_W, FB_H);
                     //glViewport(0, 20, FB_W, FB_H-20);
                     
                     ret = 0;
                  }
                  else
                  {
                     printf("[---] gles_init: eglCreateContext() returned EGL_NO_CONTEXT.\n");
                     
#ifdef USE_PBUFFER
                     eglDestroySurface(egl_display, egl_pbuffer_surface);
                     Dcheckeglerror(eglDestroySurface);
                     egl_pbuffer_surface = NULL;
#endif
                     
                     eglDestroySurface(egl_display, egl_window_surface);
                     Dcheckeglerror(eglDestroySurface);
                     egl_window_surface = NULL;
                     
                     eglTerminate(egl_display);
                     egl_display = NULL;
                     
                     ret = 50;
                  }
#ifdef USE_PBUFFER
               }
               else
               {
                  printf("[---] gles_init: eglCreatePbufferSurface() returned EGL_NO_SURFACE.\n");

                  eglDestroySurface(egl_display, egl_window_surface);
                  Dcheckeglerror(eglDestroySurface);
                  egl_window_surface = NULL;
                  
                  eglTerminate(egl_display);
                  egl_display = NULL;

                  ret = 40;
               }
#endif /* USE_PBUFFER */
            }
            else
            {
               printf("[---] gles_init: "
                      "eglCreateWindowSurface()"
                      " returned EGL_NO_SURFACE.\n"
                      );
               
               eglTerminate(egl_display);
               egl_display = NULL;

               ret = 30;
            }
         }
         else
         {
            printf("[---] gles_init: eglChooseConfig() returned numCfg=%d.\n", numCfg);

            eglTerminate(egl_display);
            egl_display = NULL;

            ret = 20;
         }
      }
      else
      {
         printf("[---] gles_init: eglChooseConfig() failed.\n");

         eglTerminate(egl_display);
         egl_display = NULL;

         ret = 10;
      }

   }
   else
   {
      printf("[---] gles_init: eglInitialize() failed.\n");

      ret = 10;
   }

   return ret;
}


/* ----------------------------------------------------------------------------- loc_find_fbo_addr_hack() */
#if 0
//#ifdef USE_FBO
static sU32 loc_find_fbo_addr_hack(sU32 _argb32) {
   sU32 ret = 0;
   int fd;
   sU32 abgr32 =
      (((_argb32 >> 24) & 255u) << 24)  |
      (((_argb32 >>  0) & 255u) << 16)  |
      (((_argb32 >>  8) & 255u) <<  8) |
      (((_argb32 >> 16) & 255u) <<  0) ;

#if 1
   sF32 fa = ((_argb32 >> 24) & 255u) / 255.0f;
   sF32 fr = ((_argb32 >> 16) & 255u) / 255.0f;
   sF32 fg = ((_argb32 >>  8) & 255u) / 255.0f;
   sF32 fb = ((_argb32      ) & 255u) / 255.0f;
#endif

   printf("xxx ARGB32=0x%08x ABGR32=0x%08x\n", _argb32, abgr32);

#if 1
   /* Clear FBO #2 */
   gles_fbo_bind(&fbo[1]);
   glClearColor(fa, fb, fr, fg); // other color
   Dcheckglerror(glClear);

   glFinish();
   Dcheckglerror(glFinish);

   /* Clear FBO #1 */
   gles_fbo_bind(&fbo[0]);

   glClearColor(fr, fg, fb, fa);
   Dcheckglerror(glClearColor);
      
   glClear(GL_COLOR_BUFFER_BIT);
   Dcheckglerror(glClear);
#endif

   glFinish();
   Dcheckglerror(glFinish);
   
   eglWaitGL();

   {
      union {
         GLubyte u8[4];
         GLuint  u32;
      } col;
      
      col.u32 = 0xCCddCCddu;
      
     
      glReadPixels(0, 0,              /* x/y    */
                   1, 1,              /* w/h    */
                   GL_RGBA,           /* format */
                   GL_UNSIGNED_BYTE,  /* type   */
                   col.u8
                   );
      Dcheckglerror(glReadPixels);

      printf("[dbg] glReadPixels()[HACK] returned col ARGB=0x%02x%02x%02x%02x\n",
             col.u8[3],
             col.u8[0],
             col.u8[1],
             col.u8[2]
             );
   }


   fd = open("/dev/mem", O_RDONLY);

   if(-1 != fd)
   {
      void *virt;

#define FBOHACK_MAP_SIZE  ( 32u * 1024u * 1024u)
#define FBOHACK_MEM_SIZE  (512u * 1024u * 1024u)
#define FBOHACK_NUM_MAPS  (FBOHACK_MEM_SIZE / FBOHACK_MEM_SIZE)

      sUI mapIdx;
      sUI numFailed = 0;

      sU32  offset = 0x80000000u + FBOHACK_MEM_SIZE - FBOHACK_MAP_SIZE;

      for(mapIdx=0; mapIdx < FBOHACK_NUM_MAPS; mapIdx++)
      {
         virt = mmap(0,  /* addr */
                     FBOHACK_MAP_SIZE,
                     (PROT_READ),
                     MAP_PRIVATE,
                     fd,
                     offset
                     );
         
         if(MAP_FAILED != virt)
         {
            sU32 *s = virt;
            sUI pixIdx;

            for(pixIdx=0; pixIdx < ((FBOHACK_MAP_SIZE / sizeof(sU32)) - 8); pixIdx++)
            {
               if(
#if 0
                  (s[pixIdx + 0] == _argb32) &&
                  (s[pixIdx + 1] == _argb32) &&
                  (s[pixIdx + 2] == _argb32) &&
                  (s[pixIdx + 3] == _argb32) &&
                  (s[pixIdx + 4] == _argb32) &&
                  (s[pixIdx + 5] == _argb32) &&
                  (s[pixIdx + 6] == _argb32) &&
                  (s[pixIdx + 7] == _argb32) 
#else
                  (s[pixIdx + 0] == abgr32) &&
                  (s[pixIdx + 1] == abgr32) &&
                  (s[pixIdx + 2] == abgr32) &&
                  (s[pixIdx + 3] == abgr32) &&
                  (s[pixIdx + 4] == abgr32) &&
                  (s[pixIdx + 5] == abgr32) &&
                  (s[pixIdx + 6] == abgr32) &&
                  (s[pixIdx + 7] == abgr32) 
#endif
                  )
               {
                  printf("xxx ARGB32 found @ virt=0x%08x, phys=0x%08x\n",
                         (sU32) &s[pixIdx],
                         offset + (pixIdx * sizeof(sU32))
                         );

                  ret = offset + (pixIdx * sizeof(sU32));
                  break;
               }
            }

            munmap(virt, FBOHACK_MAP_SIZE);
         }
         else
         {
            numFailed++;
         }

         offset -= FBOHACK_MAP_SIZE;
      }

      if(numFailed > 0)
      {
         log_printf(LOG_DEBUG "loc_find_fbo_addr_hack: numFailed=%u\n", numFailed);
      }

      close(fd);
   }
   else
   {
      log_printf(LOG_ERROR "loc_find_fbo_addr_hack: failed to open /dev/mem.\n");

      ret = 0;
   }

   return ret;
}
#endif /* USE_FBO */


/* ----------------------------------------------------------------------------- loc_test() */
static void loc_test(void) {
   sUI frameNr;
   sU32 tStart;
   sU32 tEnd;
   sF32 ccR = 1.0f;
   sF32 ccG = 1.0f;
   sF32 ccB = 1.0f;
   sF32 ccA = 1.0f;


   sF32 tcR = 1.0f / NUM_FRAMES_FBO;
   sF32 tcG = 1.0f / NUM_FRAMES_FBO;
   sF32 tcB = 1.0f / NUM_FRAMES_FBO;
   sF32 tcA = 1.0f / NUM_FRAMES_FBO;
  

   //glViewport(0, 20, 64, 64);
   //Dcheckglerror(glViewport);

   glViewport(0, 0, FB_W, FB_H);
   Dcheckglerror(glViewport);

   glFrontFace(GL_CW);
   ////glFrontFace(GL_CCW);
   Dcheckglerror(glFrontFace);

   glCullFace(GL_BACK);
   Dcheckglerror(glCullFace);
   
   tStart = osal_milliseconds_get();

   //for(frameNr=0; frameNr < NUM_FRAMES_FBO; frameNr++)
   for(frameNr=0; frameNr < 1; frameNr++)
   {
#ifdef USE_FBO
      gles_fbo_bind(&fbo[frameNr & 1u]);
#endif

      //gles_shader_bind(&shader_solid.shader);
      gles_shader_bind(&shader_varcol.shader);

      glClearColor(ccR, ccG, ccB, ccA);
      //glClearColor(1.0f, 0.0f, 0.0f, 0.0f);
      Dcheckglerror(glClearColor);
      
      glClear(GL_COLOR_BUFFER_BIT);
      Dcheckglerror(glClear);

      ////glColor4f(0.0f, 1.0f, 1.0f, 1.0f);
      ////loc_zglColorARGB(FG_COLOR);
      //glUniform4f(shader_solid.uid_color, tcR, tcG, tcB, tcA);

#if 1
      {
         GLfloat vtx[] = {
            -1.0f,  1.0f, 0.0f,  // left/top
             1.0f,  1.0f, 0.0f,  // right/top
             1.0f, -1.0f, 0.0f,  // right/bottom

            -1.0f,  1.0f, 0.0f,  // left/top
            -1.0f, -1.0f, 0.0f,  // left/bottom
             1.0f, -1.0f, 0.0f,  // right/bottom
         };

         GLfloat col[] = {
            1.0f, 0.0f, 0.0f, 1.0f,
            0.0f, 1.0f, 0.0f, 0.0f,
            0.0f, 0.0f, 1.0f, 0.0f,

            1.0f, 0.0f, 0.0f, 1.0f,
            1.0f, 1.0f, 0.0f, 1.0f,
            0.0f, 0.0f, 1.0f, 0.0f,
         };

         glVertexAttribPointer(shader_varcol.aid[SHADER_VARCOL_AID_POSITION],
                               3, GL_FLOAT,
                               GL_FALSE,    /* normalize */
                               0,           /* stride */
                               vtx
                               );
         Dcheckglerror(glVertexAttribPointer);

         glEnableVertexAttribArray(shader_varcol.aid[SHADER_VARCOL_AID_POSITION]);
         Dcheckglerror(glEnableVertexAttribArray);


         glVertexAttribPointer(shader_varcol.aid[SHADER_VARCOL_AID_COLOR],
                               4, GL_FLOAT,
                               GL_FALSE,    /* normalize */
                               0,           /* stride */
                               col
                               );
         Dcheckglerror(glVertexAttribPointer);

         glEnableVertexAttribArray(shader_varcol.aid[SHADER_VARCOL_AID_COLOR]);
         Dcheckglerror(glEnableVertexAttribArray);


         glDrawArrays(GL_TRIANGLES, 0, 3 * 2);
         Dcheckglerror(glDrawArrays);


         glDisableVertexAttribArray(shader_varcol.aid[SHADER_VARCOL_AID_POSITION]);
         Dcheckglerror(glDisableClientState);

         glDisableVertexAttribArray(shader_varcol.aid[SHADER_VARCOL_AID_COLOR]);
         Dcheckglerror(glDisableClientState);
      }
#endif

     
      if(0)
      //if(0 == frameNr)
      {
         union {
            GLubyte u8[4];
            GLuint  u32;
         } col;

         col.u32 = 0xCCddCCddu;
         
         glFinish();
         Dcheckglerror(glFinish);

         eglWaitGL();

#if 1
         /* (note) returns garbage (buggy SGX GLES1 driver, GLES2 works..) */
         glReadPixels(0, 0,              /* x/y    */
                      1, 1,              /* w/h    */
                      GL_RGBA,           /* format */
                      GL_UNSIGNED_BYTE,  /* type   */
                      col.u8
                      );
         Dcheckglerror(glReadPixels);
#else
         /* INVALID_OPERATION */
         glReadPixels(0, 0,              /* x/y    */
                      1, 1,              /* w/h    */
                      GL_BGRA,           /* format */
                      GL_UNSIGNED_BYTE,  /* type   */
                      col.u8
                      );
         Dcheckglerror(glReadPixels);
#endif
        
#if 0
         printf("[dbg] glReadPixels() returned col ARGB=0x%02x%02x%02x%02x\n",
                col.u8[3],
                col.u8[0],
                col.u8[1],
                col.u8[2]
                );
#endif

      }
      
#ifndef USE_FBO               
#ifdef USE_PBUFFER
      glFlush();
      Dcheckglerror(glFlush);
      
      printf("[trc] pbuffer rendered, frameNr=%u\n", frameNr);
#else
      glFinish();
      Dcheckglerror(glFinish);

      //glFlush();
      //Dcheckglerror(glFlush);
      
      eglSwapBuffers(egl_display, egl_window_surface);
      Dcheckeglerror(eglSwapBuffers);
      
      //printf("[trc] buffers swapped, frameNr=%u\n", frameNr);
#endif /* USE_PBUFFER */
#else
      //printf("[trc] FBO buffer rendered, frameNr=%u\n", frameNr);
#endif


      ccR -= (1.0f / NUM_FRAMES);
      ccG -= (1.0f / NUM_FRAMES);
      ccB -= (1.0f / NUM_FRAMES);
      ccA -= (1.0f / NUM_FRAMES);

      tcR += (1.0f / NUM_FRAMES_FBO);
      tcG += (1.0f / NUM_FRAMES_FBO);
      tcB += (1.0f / NUM_FRAMES_FBO) / 8.0f;
      tcA += (1.0f / NUM_FRAMES_FBO) / 2.0f;
   }

   tEnd = osal_milliseconds_get();

   log_printf(LOG_INFO "loc_test: %u (r2t) frames in %u milliseconds\n",
              NUM_FRAMES_FBO,
              (tEnd - tStart)
              );

//#if 1
#ifdef USE_FBO
   gles_fbo_bind(NULL);
#else

   {
      glGenTextures(1, &tex_id);
      Dcheckglerror(glGenTextures);

      glBindTexture(GL_TEXTURE_2D, tex_id);
      Dcheckglerror(glBindTexture);

      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

      glTexImage2D(GL_TEXTURE_2D,
                   0,
                   GL_RGBA,
                   4, 4,
                   0,
                   GL_RGBA,
                   GL_UNSIGNED_BYTE,
                   tex_data
                   );
      Dcheckglerror(glTexImage2D);
   }
#endif

   tStart = osal_milliseconds_get();

   for(frameNr=0; frameNr<NUM_FRAMES; frameNr++)
   {
      glScissor(0, 0, FB_W/2, FB_H/2);
      glEnable(GL_SCISSOR_TEST);

      glViewport(0, 0, FB_W/2, FB_H/2);
      Dcheckglerror(glViewport);

      gles_shader_bind(&shader_textured.shader);

      glActiveTexture(GL_TEXTURE0);
      Dcheckglerror(glActiveTexture);

      glDisable(GL_DEPTH_TEST);
      glDisable(GL_STENCIL_TEST);

#ifdef USE_FBO
      //glBindTexture(GL_TEXTURE_2D, fbo[frameNr&1].tex_id);
      glBindTexture(GL_TEXTURE_2D, fbo[0].tex_id);
#else
      glBindTexture(GL_TEXTURE_2D, tex_id);
#endif
      Dcheckglerror(glBindTexture);

      glUniform1i(shader_textured.uid_sampler,
                  0 /* texture unit */
                  );

      glClearColor(0.2f, 0.2f, 0.6f, 1.0f);
      Dcheckglerror(glClearColor);
      
      glClear(GL_COLOR_BUFFER_BIT);
      Dcheckglerror(glClear);

      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
      glEnable(GL_BLEND);

      {
         GLfloat vtx[] = {
            -0.9f, -0.9f, 0.0f,
             0.9f, -0.9f, 0.0f,
             0.9f,  0.9f, 0.0f,

            -0.9f, -0.9f, 0.0f,
            -0.9f,  0.9f, 0.0f,
             0.9f,  0.9f, 0.0f,
         };

         GLfloat uv[] = {
            0.0f, 0.0f,
            1.0f, 0.0f,
            1.0f, 1.0f,

            0.0f, 0.0f,
            0.0f, 1.0f,
            1.0f, 1.0f
         };

#if 0
         printf("xxx aids=%u, %u\n",
                shader_textured.aid[SHADER_TEXTURED_AID_POSITION],
                shader_textured.aid[SHADER_TEXTURED_AID_TEXCOORD]
                );

         printf("xxx getattribloc=%u, %u\n",
                glGetAttribLocation(shader_textured.shader.prg_id, "attr_position"),
                glGetAttribLocation(shader_textured.shader.prg_id, "attr_texcoord")
                );
#endif

         glVertexAttribPointer(shader_textured.aid[SHADER_TEXTURED_AID_POSITION],
                               3, GL_FLOAT,
                               GL_FALSE,    /* normalize */
                               0,           /* stride */
                               vtx
                               );
         Dcheckglerror(glVertexAttribPointer);

         glEnableVertexAttribArray(shader_textured.aid[SHADER_TEXTURED_AID_POSITION]);
         Dcheckglerror(glEnableVertexAttribArray);

         glVertexAttribPointer(shader_textured.aid[SHADER_TEXTURED_AID_TEXCOORD],
                               2, GL_FLOAT,
                               GL_FALSE,    /* normalize */
                               0,           /* stride */
                               uv
                               );
         Dcheckglerror(glVertexAttribPointer);

         glEnableVertexAttribArray(shader_textured.aid[SHADER_TEXTURED_AID_TEXCOORD]);
         Dcheckglerror(glEnableVertexAttribArray);

         glDrawArrays(GL_TRIANGLES, 0, 3 * 2);
         Dcheckglerror(glDrawArrays);

         glDisableVertexAttribArray(shader_textured.aid[SHADER_TEXTURED_AID_TEXCOORD]);
         Dcheckglerror(glDisableClientState);

         glDisableVertexAttribArray(shader_textured.aid[SHADER_TEXTURED_AID_POSITION]);
         Dcheckglerror(glDisableClientState);



         //glFinish();
         //Dcheckglerror(glFinish);

         //glFlush();
         //Dcheckglerror(glFlush);
         
         eglSwapBuffers(egl_display, egl_window_surface);
         Dcheckeglerror(eglSwapBuffers);

         //omapfb_vsync();

      }

   }

   tEnd = osal_milliseconds_get();

   log_printf(LOG_INFO "loc_test: %u (screen) frames in %u milliseconds\n",
              NUM_FRAMES,
              (tEnd - tStart)
              );

   //usleep(1000000 * 2);

#if 0
   if(1)
   {
      sU32 fboPhysAddr;
      
      fboPhysAddr = loc_find_fbo_addr_hack(FG_COLOR);
      printf("xxx fboPhysAddr=0x%08x\n", fboPhysAddr);
     
      glFlush();
      Dcheckglerror(glFlush);
      
      ////eglSwapBuffers(egl_display, egl_window_surface);
      ////Dcheckeglerror(eglSwapBuffers);
   }
#endif



}


/* ----------------------------------------------------------------------------- loc_shaders_init() */
static int loc_shaders_init(void) {
   int ret = 0;

   /* shader_solid */
   ret = gles_shader_create(&shader_solid.shader,
                            shader_solid_vp_src,
                            shader_solid_fp_src,
                            "1:attr_position",
                            shader_solid.aid
                            );

   if(0 == ret)
   {
      /* Succeeded */
      (void)gles_shader_uid_get(&shader_solid.shader,
                                "color",
                                &shader_solid.uid_color
                                );
      
   }


   /* shader_varcol */
   ret = gles_shader_create(&shader_varcol.shader,
                            shader_varcol_vp_src,
                            shader_varcol_fp_src,
                            "1:attr_position\n"
                            "1:attr_color\n",
                            shader_varcol.aid
                            );


   if(0 == ret)
   {
      /* shader_textured */
      ret = gles_shader_create(&shader_textured.shader,
                               shader_textured_vp_src,
                               shader_textured_fp_src,
                               "1:attr_position\n"
                               "1:attr_texcoord",
                               shader_textured.aid
                               );
      
      if(0 == ret)
      {
         /* Succeeded */
         (void)gles_shader_uid_get(&shader_textured.shader,
                                   "sampler",
                                   &shader_textured.uid_sampler
                                   );
         
      }
   }
      
   return ret;
}


/* ----------------------------------------------------------------------------- loc_shaders_exit() */
static void loc_shaders_exit(void) {

   gles_shader_destroy(&shader_textured.shader);

   gles_shader_destroy(&shader_varcol.shader);

   gles_shader_destroy(&shader_solid.shader);
}


/* ----------------------------------------------------------------------------- main() */
int main(int argc, char**argv) {

   (void)argc;
   (void)argv;

   if(0 == osal_init(S_FALSE/*non-root*/))
   {
      //if(omapfb_init(0,0, 0,0, 0,0, 0,0, 16, S_FALSE))
      {
         if(0 == gles_init())
         {
            if(0 == gles_ext_init())
            {
#ifdef USE_FBO
               if(0 == gles_fbo_create(&fbo[0], FBO_W, FBO_H, GL_RGBA, GL_UNSIGNED_BYTE))
               {
                  if(0 == gles_fbo_create(&fbo[1], FBO_W, FBO_H, GL_RGBA, GL_UNSIGNED_BYTE))
                  {
#endif
                     if(0 == loc_shaders_init())
                     {
                        loc_test();
                        
                        loc_shaders_exit();
                     }
                     
#ifdef USE_FBO
                     gles_fbo_destroy(&fbo[1]);
                  }
                  
                  gles_fbo_destroy(&fbo[0]);
               }
#endif
            }
            
            //usleep(NUM_FRAMES * 16 * 1000);
            
            gles_exit();
         }
      }
   }

   return 0;
}
