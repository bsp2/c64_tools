/* ----
 * ---- file   : vid2_test.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          Distributed under terms of the LESSER GNU GENERAL PUBLIC LICENSE (LGPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#LGPL or COPYING_LGPL for further information.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 10Dec2013, 13Dec2013
 * ----
 * ----
 */

#include <stdio.h>
#include <string.h>

#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>

#include "../include/inc_libc64.h"

#include "inc_hal.h"
#include "omapfb.h"

//#define VIEW_W  (256u)
//#define VIEW_H  (256u)
#define VIEW_W  (800u)
#define VIEW_H  (480)


/*--------------------------------------------------------------------------- module vars */
static dsp_mem_region_t shm_vid;


/* static sU32 tStart; */
/* static sU32 tEnd; */

static sU32 updateInterval;
static sS32 milliSecUntilUpdate;
static sU32 milliSecEllapsed;

static sU32 tStart_main;


/*--------------------------------------------------------------------------- loc_onkey() */
static void loc_onkey(sU32 _sym, sU32 _mod, sBool _bPressed) {

   printf("[dbg] loc_onkey: sym=0x%08x mod=0x%08x bPressed=%d\n",
          _sym,
          _mod,
          _bPressed
          );

   if(_bPressed)
   {
      if('q' == _sym)
      {
         hal_stop();
      }
      else if(' ' == _sym)
      {
      }
   }
}


/*--------------------------------------------------------------------------- main() */
int main(int argc, char**argv) {

   //if(1)///if(0 == dsp_open())
   if(0 == osal_init(S_FALSE))
   {
      if(1)//loc_lazy_load_components())
      {
         if(0 == hal_init(HAL_INIT_VIDEO, VIEW_W, VIEW_H))
         {
            hal_event_key_fxn = &loc_onkey;

            omapfb_set_default_plane_idx(OMAPFB_VID2);
            
            if(omapfb_init(0, 0, // position
                           VIEW_W, VIEW_H,
                           VIEW_W, VIEW_H, // zoomed size
                           VIEW_W, VIEW_H, // virtual size
                           32,
                           S_FALSE  /* disable desktop layer */
                           )
               )
            {
               updateInterval = 16u;

               shm_vid = omapfb_plane_get_dsp_mem(OMAPFB_VID2);
                     
               memset((void*)shm_vid.virt_addr, 0, shm_vid.size);
                     
               if(0 != updateInterval)
               {
                  milliSecUntilUpdate = (sS32) updateInterval;
                        
                  tStart_main = osal_milliseconds_get();
               }
               else
               {
                  /* workaround to suppress compiler warnings */
                  milliSecUntilUpdate = 0;
                  tStart_main = 0;
               }
                     
               while(hal_running())
               {
                  hal_event_process();
                  
                  if(0 != updateInterval)
                  {
                     milliSecEllapsed = (osal_milliseconds_get() - tStart_main);
                        
                     if(milliSecEllapsed >= milliSecUntilUpdate)
                     {
                        ///////////////////hal_video_flip();
                        
                        tStart_main = osal_milliseconds_get();
                     }
                     else
                     {
                        osal_msleep(milliSecUntilUpdate - milliSecEllapsed);
                     }
                  }
               }
                  

               omapfb_exit();
            }
            
            hal_exit();
         }
      }
      else
      {
         log_printf(LOG_ERROR "failed to load required DSP components.\n");
      }
      
      ////////dsp_close();
   }
   
   return 0;
}
