/* ----
 * ---- file   : gles_test.c
 * ---- author : Bastian Spiegel <bs@tkscript.de>
 * ---- legal  : (c) 2013 by Bastian Spiegel. 
 * ----          Distributed under terms of the LESSER GNU GENERAL PUBLIC LICENSE (LGPL). See 
 * ----          http://www.gnu.org/licenses/licenses.html#LGPL or COPYING_LGPL for further information.
 * ----
 * ---- info   : This is part of the "c64_tools" package examples.
 * ----
 * ---- changed: 08Nov2013
 * ----
 * ----
 */

#define FB_W  800
#define FB_H  480

/// If defined, create pbuffer instead of window surface
//#define USE_PBUFFER defined

/// If defined, create RGBA FBO
#define USE_FBO defined

/// (note) SGX requires this to be POT 
#define FBO_W  (1024u)  
//#define FBO_W  (256u)  

/// (note) SGX requires this to be POT 
#define FBO_H  (1024u)
//#define FBO_H  (256u)

/// If defined, use a 32bits per pixel config instead of 16bit RGB565
///  (note) not supported by SGX driver, at least not when (OMAP) framebuffer is RGB565
//#define USE_ARGB32 defined

#define NUM_FRAMES (60u * 1u)
//#define NUM_FRAMES (1000u * 1u)
//#define NUM_FRAMES (10u)

#define FG_COLOR  (0x8000FFFFu)


#include <stdio.h>
#include <string.h>

#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>

#include <GLES/egl.h>
#include <GLES/gl.h>
//#define GL_GLEXT_PROTOTYPES defined
#include <GLES/glext.h>

#include "../include/types.h"
#include "../include/osal_err.h"
#include "../include/osal.h"
#include "../include/log.h"


#define Dcheckeglerror(s) if(S_TRUE) { GLenum err = eglGetError(); if(EGL_SUCCESS != err) printf("%s() returned EGL error %d (0x%08x)\n", #s, err, (sU32)err); } else (void)0


#define Dcheckglerror(s) if(S_TRUE) { GLenum err = glGetError(); if(0 != err) printf("%s() returned GL error %d (0x%08x)\n", #s, err, (sU32)err); } else (void)0


typedef struct {
   GLuint tex_id;
   GLuint fbo_id;
   sU32   w;
   sU32   h;
} fbo_t;


/* ----------------------------------------------------------------------------- module vars */
NativeDisplayType native_display;
NativeWindowType  native_window;

EGLDisplay egl_display = NULL;
EGLConfig  egl_config  = NULL;
EGLContext egl_context = NULL;
EGLConfig  egl_config;

EGLSurface egl_window_surface = NULL;

#ifdef USE_PBUFFER
EGLSurface egl_pbuffer_surface = NULL;
#endif



static const EGLint egl_context_attribs[] = {
   EGL_NONE, EGL_NONE
};


static const EGLint egl_window_surface_attribs[] = {
   EGL_RENDER_BUFFER, EGL_BACK_BUFFER,
   //EGL_RENDER_BUFFER, EGL_SINGLE_BUFFER,

   EGL_NONE, EGL_NONE
};


static const EGLint egl_config_attribs[] = {
#ifdef USE_ARGB32
   EGL_BUFFER_SIZE, 32,

   EGL_ALPHA_SIZE, 8,
   EGL_RED_SIZE,   8,
   EGL_GREEN_SIZE, 8,
   EGL_BLUE_SIZE,  8,

   EGL_BIND_TO_TEXTURE_RGBA, EGL_TRUE,
#else
   EGL_BUFFER_SIZE, 16,

   EGL_ALPHA_SIZE, 0,
   EGL_RED_SIZE,   5,
   EGL_GREEN_SIZE, 6,
   EGL_BLUE_SIZE,  5,

   //EGL_BIND_TO_TEXTURE_RGB,  EGL_TRUE,
   //EGL_BIND_TO_TEXTURE_RGBA, EGL_TRUE,
#endif /* USE_ARGB32 */


   EGL_STENCIL_SIZE, 0,
   EGL_DEPTH_SIZE, 0,

   //EGL_NATIVE_RENDERABLE, EGL_TRUE,
   //EGL_NATIVE_RENDERABLE, EGL_FALSE,

   //EGL_MIN_SWAP_INTERVAL, 1,

   EGL_NONE, EGL_NONE
};


#ifdef USE_PBUFFER
static const EGLint egl_pbuffer_attribs[] = {
   EGL_WIDTH,  1024,
   EGL_HEIGHT, 1024,

   EGL_LARGEST_PBUFFER, EGL_TRUE,

   EGL_TEXTURE_TARGET, EGL_TEXTURE_RGBA,
   EGL_TEXTURE_FORMAT, EGL_TEXTURE_2D,

};
#endif /* USE_PBUFFER */


static PFNGLGENFRAMEBUFFERSOESPROC         proc_glGenFramebuffersOES        = NULL;
static PFNGLBINDFRAMEBUFFEROESPROC         proc_glBindFramebufferOES        = NULL;
static PFNGLDELETEFRAMEBUFFERSOESPROC      proc_glDeleteFramebuffersOES     = NULL;
static PFNGLCHECKFRAMEBUFFERSTATUSOESPROC  proc_glCheckFramebufferStatusOES = NULL;
static PFNGLFRAMEBUFFERTEXTURE2DOESPROC    proc_glFramebufferTexture2DOES   = NULL;

//void   (*proc_glGenFramebuffersOES)        (GLsizei n, GLuint* framebuffers);
//void   (*proc_glBindFramebuffersOES)       (GLenum target, GLuint framebuffer);
//void   (*proc_glDeleteFramebuffersOES)     (GLsizei n, const GLuint* framebuffers);
//GLenum (*proc_glCheckFramebufferStatusOES) (GLenum target);
 

#ifdef USE_FBO
static fbo_t fbo[2];
#endif


/* ----------------------------------------------------------------------------- loc_gles_fbo_destroy() */
#ifdef USE_FBO
static void loc_gles_fbo_destroy(fbo_t *_fbo) {

   /* Unbind FBO */
   proc_glBindFramebufferOES(GL_FRAMEBUFFER_OES, 0);

   /* Delete FBO texture */
   glDeleteTextures(1, &_fbo->tex_id);
   _fbo->tex_id = 0;

   /* Delete FBO */
   proc_glDeleteFramebuffersOES(1, &_fbo->fbo_id);
   _fbo->fbo_id = 0;
}


/* ----------------------------------------------------------------------------- loc_gles_fbo_bind() */
static void loc_gles_fbo_bind(fbo_t *_fbo) {

   if(NULL != _fbo)
   {
      glBindTexture(GL_TEXTURE_2D, 0);
      Dcheckglerror(glBindTexture);
      
      proc_glBindFramebufferOES(GL_FRAMEBUFFER_OES, _fbo->fbo_id);
      Dcheckglerror(glBindFramebufferOES);
      
      glViewport(0, 0, _fbo->w, _fbo->h);
   }
   else
   {
      glBindTexture(GL_TEXTURE_2D, 0);

      proc_glBindFramebufferOES(GL_FRAMEBUFFER_OES, 0);
      Dcheckglerror(glBindFramebufferOES);

      glViewport(0, 0, FB_W, FB_H);
      Dcheckglerror(glViewport);
   }
}


/* ----------------------------------------------------------------------------- loc_gles_fbo_create() */
static int loc_gles_fbo_create(fbo_t *_fbo, sU32 _w, sU32 _h) {
   GLint fbStatus;
   int ret;

   glGenTextures(1, &_fbo->tex_id);
   Dcheckglerror(glGenTextures);

   glBindTexture(GL_TEXTURE_2D, _fbo->tex_id);
   Dcheckglerror(glBindTexture);
   
   //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAPS, GL_REPEAT);
   //Dcheckglerror(glTexParameteri);

   //glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAPU, GL_REPEAT);
   //Dcheckglerror(glTexParameteri);
      
   glTexImage2D(GL_TEXTURE_2D,
                0,                 /* level */
                //GL_RGBA8_OES,      /* internalformat */
                //GL_RGB,            /* internalformat */
                GL_RGB8_OES,       /* internalformat */
                _w,                /* width */
                _h,                /* height */
                0,                 /* border */
                GL_RGB,            /* format */
                GL_UNSIGNED_BYTE,  /* type */
                NULL               /* ==> alloc memory */
                );
   Dcheckglerror(glTexImage2D);

   glBindTexture(GL_TEXTURE_2D, 0);
   Dcheckglerror(glBindTexture);

   proc_glGenFramebuffersOES(1, &_fbo->fbo_id);
   Dcheckglerror(glGenFramebuffersOES);

   proc_glBindFramebufferOES(GL_FRAMEBUFFER_OES, _fbo->fbo_id);
   Dcheckglerror(glBindFramebufferOES);

   proc_glFramebufferTexture2DOES(GL_FRAMEBUFFER_OES,
                                  GL_COLOR_ATTACHMENT0_OES,
                                  GL_TEXTURE_2D,
                                  _fbo->tex_id,
                                  0 /* level */
                                  );
   Dcheckglerror(glFramebufferTexture2DOES);

   fbStatus = proc_glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES);
   Dcheckglerror(glCheckFramebufferStatusOES);

   if(GL_FRAMEBUFFER_COMPLETE_OES == fbStatus)
   {
      printf("[...] loc_gles_fbo_create: OK, framebuffer status is COMPLETE.\n");

      //glViewport(0, 0, _w, _h);
      //Dcheckglerror(glViewport);

      _fbo->w = _w;
      _fbo->h = _h;

      /* Succeeded */
      ret = 0;
   }
   else
   {
      printf("[---] loc_gles_fbo_create: OK, framebuffer status is %d.\n", fbStatus);

      /* Failed */
      ret = 10;
   }

   return ret;
}
#endif /* USE_FBO */


/* ----------------------------------------------------------------------------- loc_gles_query_print_int() */
static void loc_gles_query_print_int(GLenum _type, const char *_msg) {
   char buf[1024];
   GLenum glErr;
   GLint val;

   /* (todo) check whether _msg contains format string (%d, %u, ..) */

   int l = strlen(_msg);

   if(l > 1000)
   {
      l = 1000;
   }
   
   strncpy(buf, _msg, 900);

   glGetIntegerv(_type, &val);

   glErr = glGetError();

   if(0 == glErr)
   {
      strncpy(buf + l, "%d\n", 123);

      printf(buf, val);
   }
   else
   {
      strncpy(buf + l, "<GL error 0x%08x>\n", 123);

      printf(buf, (sU32)glErr);
   }
}


/* ----------------------------------------------------------------------------- loc_gles_query_print_int2() */
static void loc_gles_query_print_int2(GLenum _type, const char *_msg) {
   char buf[1024];
   GLenum glErr;
   GLint val[2];

   /* (todo) check whether _msg contains format string (%d, %u, ..) */

   int l = strlen(_msg);

   if(l > 1000)
   {
      l = 1000;
   }
   
   strncpy(buf, _msg, 900);

   glGetIntegerv(_type, val);

   glErr = glGetError();

   if(0 == glErr)
   {
      strncpy(buf + l, "(%d; %d)\n", 123);

      printf(buf, val[0], val[1]);
   }
   else
   {
      strncpy(buf + l, "<GL error 0x%08x>\n", 123);

      printf(buf, (sU32)glErr);
   }
}


/* ----------------------------------------------------------------------------- loc_glext_init() */
static int loc_glext_init(void) {
   int ret;

   proc_glGenFramebuffersOES        = (PFNGLGENFRAMEBUFFERSOESPROC)        eglGetProcAddress("glGenFramebuffersOES");
   proc_glBindFramebufferOES        = (PFNGLBINDFRAMEBUFFEROESPROC)        eglGetProcAddress("glBindFramebufferOES");
   proc_glDeleteFramebuffersOES     = (PFNGLDELETEFRAMEBUFFERSOESPROC)     eglGetProcAddress("glDeleteFramebuffersOES");
   proc_glCheckFramebufferStatusOES = (PFNGLCHECKFRAMEBUFFERSTATUSOESPROC) eglGetProcAddress("glCheckFramebufferStatusOES");
   proc_glFramebufferTexture2DOES   = (PFNGLFRAMEBUFFERTEXTURE2DOESPROC)   eglGetProcAddress("glFramebufferTexture2DOES");

   if(NULL != proc_glGenFramebuffersOES)
   {
      if(NULL != proc_glBindFramebufferOES)
      {
         if(NULL != proc_glDeleteFramebuffersOES)
         {
            if(NULL != proc_glCheckFramebufferStatusOES)
            {
               if(NULL != proc_glFramebufferTexture2DOES)
               {
                  /* Succeeded */
                  ret = 0;
               }
               else
               {
                  printf("[---] loc_glext_init: failed to resolve \"glFramebufferTexture2DOES\".\n");
                  
                  ret = 50;
               }
            }
            else
            {
               printf("[---] loc_glext_init: failed to resolve \"glCheckFramebufferStatusOES\".\n");

               ret = 40;
            }
         }
         else
         {
            printf("[---] loc_glext_init: failed to resolve \"glDeleteFramebuffersOES\".\n");

            ret = 30;
         }
      }
      else
      {
         printf("[---] loc_glext_init: failed to resolve \"glBindFramebufferOES\".\n");

         ret = 20;
      }
   }
   else
   {
      printf("[---] loc_glext_init: failed to resolve \"glGenFramebuffersOES\".\n");

      ret = 10;
   }

   return ret;
}


/* ----------------------------------------------------------------------------- loc_gles_exit() */
static void loc_gles_exit(void) {

   if(NULL != egl_display)
   {
      eglMakeCurrent(egl_display, NULL, NULL, EGL_NO_CONTEXT);
      Dcheckeglerror(eglMakeCurrent);

      if(NULL != egl_context)
      {
         eglDestroyContext(egl_display, egl_context);
         Dcheckeglerror(eglDestroyContext);

         egl_context = NULL;
      }

#ifdef USE_PBUFFER
      if(NULL != egl_pbuffer_surface)
      {
         eglDestroySurface(egl_display, egl_pbuffer_surface);
         Dcheckeglerror(eglDestroySurface);

         egl_pbuffer_surface = NULL;
      }
#endif

      if(NULL != egl_window_surface)
      {
         eglDestroySurface(egl_display, egl_window_surface);
         Dcheckeglerror(eglDestroySurface);

         egl_window_surface = NULL;
      }

      eglTerminate(egl_display);

      egl_display = NULL;
   }
}


/* ----------------------------------------------------------------------------- loc_gles_init() */
static int loc_gles_init(void) {
   int ret;
   EGLBoolean r;
   EGLint eglVerMaj;
   EGLint eglVerMin;

   egl_display = eglGetDisplay(0);

   printf("[dbg] egl_display=0x%08x\n", (sU32) egl_display);

   r = eglInitialize(egl_display,
                     &eglVerMaj,
                     &eglVerMin
                     );

   if(0 != r)
   {
      EGLint numCfg = 0;

      printf("[dbg] eglInitialize() returned eglVerMaj=%d eglVerMin=%d\n",
             eglVerMaj, eglVerMin
             );
      Dcheckeglerror(eglInitialize);

      r = eglChooseConfig(egl_display, egl_config_attribs, &egl_config, 1, &numCfg);
      Dcheckeglerror(eglChooseConfig);

      if(0 != r)
      {
         if(numCfg >= 1)
         {
            egl_window_surface = eglCreateWindowSurface(egl_display,
                                                        egl_config,
                                                        NULL,  /* window */
                                                        egl_window_surface_attribs  /* window_attribs */
                                                        );
            Dcheckeglerror(eglCreateWindowSurface);

            if(EGL_NO_SURFACE != egl_window_surface)
            {
               printf("[...] loc_gles_init: ok, got egl_window_surface=0x%08x\n", (sU32)egl_window_surface);

#ifdef USE_PBUFFER
               egl_pbuffer_surface = eglCreatePbufferSurface(egl_display,
                                                             egl_config,
                                                             NULL  /* pbuffer_attribs */
                                                             );
               Dcheckeglerror(eglCreatePbufferSurface);
               
               if(EGL_NO_SURFACE != egl_pbuffer_surface)
               {
                  printf("[...] loc_gles_init: ok, got egl_pbuffer_surface=0x%08x\n", (sU32)egl_pbuffer_surface);
#endif /* USE_PBUFFER */
                  
                  egl_context = eglCreateContext(egl_display,
                                                 egl_config,
                                                 EGL_NO_CONTEXT,
                                                 egl_context_attribs
                                                 );
                  Dcheckeglerror(eglCreateContext);
                  
                  if(EGL_NO_CONTEXT != egl_context)
                  {
                     printf("[...] loc_gles_init: ok, got egl_context=0x%08x\n", (sU32)egl_context);
                     
                     eglMakeCurrent(egl_display, egl_window_surface, egl_window_surface, egl_context);

#ifdef USE_PBUFFER
                     //eglMakeCurrent(egl_display, egl_pbuffer_surface, egl_pbuffer_surface, egl_context);
#endif
                     Dcheckeglerror(eglMakeCurrent);
                     
                     //eglSwapInterval(egl_display, 1);
                     //Dcheckeglerror(eglSwapInterval);
                     
                     /* Do some queries */
                     {
                        const GLubyte *str;
                        
                        str = glGetString(GL_VENDOR);
                        Dcheckglerror(glGetString);
                       
                        printf("loc_gles_init: GL_VENDOR = \"%s\".\n", str);
                        

                        str = glGetString(GL_RENDERER);
                        Dcheckglerror(glGetString);
                       
                        printf("loc_gles_init: GL_RENDERER = \"%s\".\n", str);


                        str = glGetString(GL_EXTENSIONS);
                        Dcheckglerror(glGetString);
                       
                        printf("loc_gles_init: GL_EXTENSIONS = \"%s\".\n", str);

                        
                        loc_gles_query_print_int(GL_ALPHA_BITS,
                                                 "loc_gles_init:        GL_ALPHA_BITS = "
                                                 );
                        
                        
                        loc_gles_query_print_int(GL_RED_BITS, 
                                                 "loc_gles_init:          GL_RED_BITS = "
                                                 );
                        
                        loc_gles_query_print_int(GL_GREEN_BITS, 
                                                 "loc_gles_init:        GL_GREEN_BITS = "
                                                 );
                        
                        loc_gles_query_print_int(GL_BLUE_BITS, 
                                                 "loc_gles_init:         GL_BLUE_BITS = "
                                                 );
                        
                        loc_gles_query_print_int(GL_STENCIL_BITS, 
                                                 "loc_gles_init:      GL_STENCIL_BITS = "
                                                 );
                        
                        loc_gles_query_print_int(GL_DEPTH_BITS,
                                                 "loc_gles_init:        GL_DEPTH_BITS = "
                                                 );
                        
                        loc_gles_query_print_int(GL_MULTISAMPLE, 
                                                 "loc_gles_init:       GL_MULTISAMPLE = "
                                                 );
                        
                        loc_gles_query_print_int(GL_SAMPLE_BUFFERS, 
                                                 "loc_gles_init:    GL_SAMPLE_BUFFERS = "
                                                 );
                        
                        loc_gles_query_print_int(GL_SAMPLES, 
                                                 "loc_gles_init:           GL_SAMPLES = "
                                                 );
                        
                        loc_gles_query_print_int2(GL_MAX_VIEWPORT_DIMS, 
                                                  "loc_gles_init: GL_MAX_VIEWPORT_DIMS = "
                                                  );
                        
                        loc_gles_query_print_int(GL_MAX_LIGHTS,
                                                 "loc_gles_init:        GL_MAX_LIGHTS = "
                                                 );
                        
                        loc_gles_query_print_int(GL_MAX_TEXTURE_UNITS, 
                                                 "loc_gles_init: GL_MAX_TEXTURE_UNITS = "
                                                 );
                     }
                  
                     /* Succeeded */
                     
                     {
                        EGLenum eglErr;
                        GLenum glErr;
                        
                        eglErr = eglGetError();
                        glErr  =  glGetError();
                        
                        printf("[dbg] loc_gles_init: ok, eglGetError()=%d (0x%08x), glGetError=%d (0x%08x)\n",
                               eglErr, eglErr,
                               glErr, glErr
                               );
                     }

                     //glViewport(0, 0, FB_W, FB_H);
                     //glViewport(0, 20, FB_W, FB_H-20);
                     
                     ret = 0;
                  }
                  else
                  {
                     printf("[---] loc_gles_init: eglCreateContext() returned EGL_NO_CONTEXT.\n");
                     
#ifdef USE_PBUFFER
                     eglDestroySurface(egl_display, egl_pbuffer_surface);
                     Dcheckeglerror(eglDestroySurface);
                     egl_pbuffer_surface = NULL;
#endif
                     
                     eglDestroySurface(egl_display, egl_window_surface);
                     Dcheckeglerror(eglDestroySurface);
                     egl_window_surface = NULL;
                     
                     eglTerminate(egl_display);
                     egl_display = NULL;
                     
                     ret = 50;
                  }
#ifdef USE_PBUFFER
               }
               else
               {
                  printf("[---] loc_gles_init: eglCreatePbufferSurface() returned EGL_NO_SURFACE.\n");

                  eglDestroySurface(egl_display, egl_window_surface);
                  Dcheckeglerror(eglDestroySurface);
                  egl_window_surface = NULL;
                  
                  eglTerminate(egl_display);
                  egl_display = NULL;

                  ret = 40;
               }
#endif /* USE_PBUFFER */
            }
            else
            {
               printf("[---] loc_gles_init: "
                      "eglCreateWindowSurface()"
                      " returned EGL_NO_SURFACE.\n"
                      );
               
               eglTerminate(egl_display);
               egl_display = NULL;

               ret = 30;
            }
         }
         else
         {
            printf("[---] loc_gles_init: eglChooseConfig() returned numCfg=%d.\n", numCfg);

            eglTerminate(egl_display);
            egl_display = NULL;

            ret = 20;
         }
      }
      else
      {
         printf("[---] loc_gles_init: eglChooseConfig() failed.\n");

         eglTerminate(egl_display);
         egl_display = NULL;

         ret = 10;
      }

   }
   else
   {
      printf("[---] loc_gles_init: eglInitialize() failed.\n");

      ret = 10;
   }

   return ret;
}


/* ----------------------------------------------------------------------------- loc_zglColorARGB() */
static void loc_zglColorARGB(sU32 _argb32) {
   sF32 fa = ((_argb32 >> 24) & 255u) / 255.0f;
   sF32 fr = ((_argb32 >> 16) & 255u) / 255.0f;
   sF32 fg = ((_argb32 >>  8) & 255u) / 255.0f;
   sF32 fb = ((_argb32      ) & 255u) / 255.0f;

   glColor4f(fr, fg, fb, fa);
   Dcheckglerror(glColor4f);
}


/* ----------------------------------------------------------------------------- loc_find_fbo_addr_hack() */
#ifdef USE_FBO
static sU32 loc_find_fbo_addr_hack(sU32 _argb32) {
   sU32 ret = 0;
   int fd;
   sU32 rgba32 =
      (((_argb32 >> 16) & 255u) << 0)  |
      (((_argb32 >>  8) & 255u) << 8)  |
      (((_argb32 >>  0) & 255u) << 16) |
      (((_argb32 >> 24) & 255u) << 24) ;

#if 0      
   sF32 fa = ((_argb32 >> 24) & 255u) / 255.0f;
   sF32 fr = ((_argb32 >> 16) & 255u) / 255.0f;
   sF32 fg = ((_argb32 >>  8) & 255u) / 255.0f;
   sF32 fb = ((_argb32      ) & 255u) / 255.0f;
#endif

   printf("xxx ARGB32=0x%08x RGBA32=0x%08x\n", _argb32, rgba32);

#if 0
   /* Clear FBO #2 */
   loc_gles_fbo_bind(&fbo[1]);
   glClearColor(fa, fb, fr, fg); // other color
   Dcheckglerror(glClear);

   glFinish();
   Dcheckglerror(glFinish);

   /* Clear FBO #1 */
   loc_gles_fbo_bind(&fbo[0]);

   glClearColor(fr, fg, fb, fa);
   Dcheckglerror(glClearColor);
      
   glClear(GL_COLOR_BUFFER_BIT);
   Dcheckglerror(glClear);
#endif

   glFinish();
   Dcheckglerror(glFinish);

   //eglWaitGL();

   fd = open("/dev/mem", O_RDONLY);

   if(-1 != fd)
   {
      void *virt;

#define FBOHACK_MAP_SIZE  ( 32u * 1024u * 1024u)
#define FBOHACK_MEM_SIZE  (512u * 1024u * 1024u)
#define FBOHACK_NUM_MAPS  (FBOHACK_MEM_SIZE / FBOHACK_MEM_SIZE)

      sUI mapIdx;
      sUI numFailed = 0;

      sU32  offset = 0x80000000u + FBOHACK_MEM_SIZE - FBOHACK_MAP_SIZE;

      for(mapIdx=0; mapIdx < FBOHACK_NUM_MAPS; mapIdx++)
      {
         virt = mmap(0,  /* addr */
                     FBOHACK_MAP_SIZE,
                     (PROT_READ),
                     MAP_PRIVATE,
                     fd,
                     offset
                     );
         
         if(MAP_FAILED != virt)
         {
            sU32 *s = virt;
            sUI pixIdx;

            for(pixIdx=0; pixIdx < ((FBOHACK_MAP_SIZE / sizeof(sU32)) - 8); pixIdx++)
            {
               if(
#if 1
                  (s[pixIdx + 0] == _argb32) &&
                  (s[pixIdx + 1] == _argb32) &&
                  (s[pixIdx + 2] == _argb32) &&
                  (s[pixIdx + 3] == _argb32) &&
                  (s[pixIdx + 4] == _argb32) &&
                  (s[pixIdx + 5] == _argb32) &&
                  (s[pixIdx + 6] == _argb32) &&
                  (s[pixIdx + 7] == _argb32) 
#else
                  (s[pixIdx + 0] == rgba32) &&
                  (s[pixIdx + 1] == rgba32) &&
                  (s[pixIdx + 2] == rgba32) &&
                  (s[pixIdx + 3] == rgba32) &&
                  (s[pixIdx + 4] == rgba32) &&
                  (s[pixIdx + 5] == rgba32) &&
                  (s[pixIdx + 6] == rgba32) &&
                  (s[pixIdx + 7] == rgba32) 
#endif
                  )
               {
                  printf("xxx ARGB32 found @ virt=0x%08x, phys=0x%08x\n",
                         (sU32) &s[pixIdx],
                         offset + (pixIdx * sizeof(sU32))
                         );

                  ret = offset + (pixIdx * sizeof(sU32));
                  break;
               }
            }

            munmap(virt, FBOHACK_MAP_SIZE);
         }
         else
         {
            numFailed++;
         }

         offset -= FBOHACK_MAP_SIZE;
      }

      if(numFailed > 0)
      {
         log_printf(LOG_DEBUG "loc_find_fbo_addr_hack: numFailed=%u\n", numFailed);
      }

      close(fd);
   }
   else
   {
      log_printf(LOG_ERROR "loc_find_fbo_addr_hack: failed to open /dev/mem.\n");

      ret = 0;
   }

   return ret;
}
#endif /* USE_FBO */


/* ----------------------------------------------------------------------------- loc_test() */
static void loc_test(void) {
   sUI frameNr;
   sU32 tStart;
   sU32 tEnd;
   sF32 ccR = 1.0f;
   sF32 ccG = 1.0f;
   sF32 ccB = 1.0f;
   sF32 ccA = 1.0f;

   //glViewport(0, 20, 64, 64);
   //Dcheckglerror(glViewport);

   glViewport(0, 0, FB_W, FB_H);
   Dcheckglerror(glViewport);

   glFrontFace(GL_CW);
   ////glFrontFace(GL_CCW);
   Dcheckglerror(glFrontFace);

   glCullFace(GL_BACK);
   Dcheckglerror(glCullFace);
   
   tStart = osal_milliseconds_get();

   for(frameNr=0; frameNr < NUM_FRAMES; frameNr++)
   {
#ifdef USE_FBO
      loc_gles_fbo_bind(&fbo[frameNr & 1u]);
#endif

      glMatrixMode(GL_PROJECTION);
      Dcheckglerror(glMatrixMode);

      glLoadIdentity();
      Dcheckglerror(glLoadIdentity);

      glOrthof(-1.0f,  /* left */
                1.0f,  /* right */
               -1.0f,  /* bottom */
                1.0f,  /* top */
               0.01f,  /* znear */
               10.0f   /* zfar */
               );
      Dcheckglerror(glOrthof);

      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();

      glTranslatef(0, 0, -1.0f);

      //glClearColor(ccR, ccG, ccB, ccA);
      glClearColor(1.0f, 0.0f, 0.0f, 0.0f);
      Dcheckglerror(glClearColor);
      
      glClear(GL_COLOR_BUFFER_BIT);
      Dcheckglerror(glClear);

      glColor4f(0.0f, 1.0f, 1.0f, 1.0f);
      //loc_zglColorARGB(FG_COLOR);

      {
         GLfloat vtx[] = {
            -1.0f, 1.0f,
            1.0f, 1.0f,
            1.0f, -1.0f,

            -1.0f, -1.0f,
            -1.0f, 1.0f,
            1.0f, -1.0f,
         };

         glVertexPointer(2, GL_FLOAT, 0, vtx);
         Dcheckglerror(glVertexPointer);

         glEnableClientState(GL_VERTEX_ARRAY);
         Dcheckglerror(glEnableClientState);

         glDrawArrays(GL_TRIANGLES, 0, 3 * 2);
         Dcheckglerror(glDrawArrays);

         glDisableClientState(GL_VERTEX_ARRAY);
         Dcheckglerror(glDisableClientState);
      }

     
      if(0)
         //if(0 == frameNr)
      {
         union {
            GLubyte u8[4];
            GLuint  u32;
         } col;

         col.u32 = 0xCCddCCddu;
         
         glFinish();
         Dcheckglerror(glFinish);

         eglWaitGL();

#if 1
         /* (note) returns garbage (buggy SGX driver..) */
         glReadPixels(0, 0,              /* x/y    */
                      1, 1,              /* w/h    */
                      GL_RGBA,           /* format */
                      GL_UNSIGNED_BYTE,  /* type   */
                      col.u8
                      );
         Dcheckglerror(glReadPixels);
#else
         /* INVALID_OPERATION */
         glReadPixels(0, 0,              /* x/y    */
                      1, 1,              /* w/h    */
                      GL_BGRA,           /* format */
                      GL_UNSIGNED_BYTE,  /* type   */
                      col.u8
                      );
         Dcheckglerror(glReadPixels);
#endif
        
         printf("[dbg] glReadPixels() returned col ARGB=0x%02x%02x%02x%02x\n",
                col.u8[3],
                col.u8[0],
                col.u8[1],
                col.u8[2]
                );

      }
      
#ifndef USE_FBO               
#ifdef USE_PBUFFER
      glFlush();
      Dcheckglerror(glFlush);
      
      printf("[trc] pbuffer rendered, frameNr=%u\n", frameNr);
#else
      glFinish();
      Dcheckglerror(glFinish);

      //glFlush();
      //Dcheckglerror(glFlush);
      
      eglSwapBuffers(egl_display, egl_window_surface);
      Dcheckeglerror(eglSwapBuffers);
      
      //printf("[trc] buffers swapped, frameNr=%u\n", frameNr);
#endif /* USE_PBUFFER */
#else
      //printf("[trc] FBO buffer rendered, frameNr=%u\n", frameNr);
#endif


      ccR -= (1.0f / NUM_FRAMES);
      ccG -= (1.0f / NUM_FRAMES);
      ccB -= (1.0f / NUM_FRAMES);
      ccA -= (1.0f / NUM_FRAMES);
   }

   tEnd = osal_milliseconds_get();

   log_printf(LOG_INFO "loc_test: %u frames in %u milliseconds\n",
              NUM_FRAMES,
              (tEnd - tStart)
              );

//#if 0
#ifdef USE_FBO
   loc_gles_fbo_bind(NULL);

   for(frameNr=0; frameNr<100; frameNr++)
   {
      glViewport(0, 0, FB_W, FB_H);
      Dcheckglerror(glViewport);

      glEnable(GL_TEXTURE_2D);
      Dcheckglerror(glEnable);

      glBindTexture(GL_TEXTURE_2D, fbo[frameNr&1].tex_id);
      Dcheckglerror(glBindTexture);

      //glDisable(GL_TEXTURE_2D);

      glMatrixMode(GL_PROJECTION);
      Dcheckglerror(glMatrixMode);

      glLoadIdentity();
      Dcheckglerror(glLoadIdentity);

      glOrthof(-1.0f,  /* left */
                1.0f,  /* right */
               -1.0f,  /* bottom */
                1.0f,  /* top */
               0.01f,  /* znear */
               10.0f   /* zfar */
               );
      Dcheckglerror(glOrthof);

      glMatrixMode(GL_MODELVIEW);
      glLoadIdentity();

      glTranslatef(0, 0, -1.0f);

      glClearColor(0.2f, 0.2f, 0.6f, 1.0f);
      Dcheckglerror(glClearColor);
      
      glClear(GL_COLOR_BUFFER_BIT);
      Dcheckglerror(glClear);

      //glColor4f(0.0f, 1.0f, 1.0f, 1.0f);
      loc_zglColorARGB(0xfFFFFFFFu);

      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
      glEnable(GL_BLEND);

      {
         GLfloat vtx[] = {
            -0.9f, 0.9f,
            0.9f, 0.9f,
            0.9f, -0.9f,

            -0.9f, -0.9f,
            -0.9f, 0.9f,
            0.9f, -0.9f,
         };

         GLfloat uv[] = {
            0.0f, 0.0f,
            1.0f, 0.0f,
            1.0f, 1.0f,

            0.0f, 1.0f,
            0.0f, 0.0f,
            1.0f, 0.0f
         };

         glVertexPointer(2, GL_FLOAT, 0, vtx);
         Dcheckglerror(glVertexPointer);

         glEnableClientState(GL_VERTEX_ARRAY);
         Dcheckglerror(glEnableClientState);

         glTexCoordPointer(2, GL_FLOAT, 0, uv);
         Dcheckglerror(glTexCoordPointer);

         glEnableClientState(GL_TEXTURE_COORD_ARRAY);
         Dcheckglerror(glEnableClientState);

         glDrawArrays(GL_TRIANGLES, 0, 3 * 2);
         Dcheckglerror(glDrawArrays);

         glDisableClientState(GL_TEXTURE_COORD_ARRAY);
         Dcheckglerror(glDisableClientState);

         glDisableClientState(GL_VERTEX_ARRAY);
         Dcheckglerror(glDisableClientState);

         glFinish();
         Dcheckglerror(glFinish);
         
         eglSwapBuffers(egl_display, egl_window_surface);
         Dcheckeglerror(eglSwapBuffers);

      }

   }

   usleep(1000000 * 2);

   if(0)
   {
      sU32 fboPhysAddr;
      
      fboPhysAddr = loc_find_fbo_addr_hack(FG_COLOR);
      printf("xxx fboPhysAddr=0x%08x\n", fboPhysAddr);
     
      glFlush();
      Dcheckglerror(glFlush);
      
      ////eglSwapBuffers(egl_display, egl_window_surface);
      ////Dcheckeglerror(eglSwapBuffers);
   }
#endif /* USE_FBO */

}


/* ----------------------------------------------------------------------------- main() */
int main(int argc, char**argv) {

   (void)argc;
   (void)argv;

   if(0 == osal_init(S_FALSE/*non-root*/))
   {
      if(0 == loc_gles_init())
      {
         if(0 == loc_glext_init())
         {
#ifdef USE_FBO
            if(0 == loc_gles_fbo_create(&fbo[0], FBO_W, FBO_H))
            {
               if(0 == loc_gles_fbo_create(&fbo[1], FBO_W, FBO_H))
               {
#endif
                  loc_test();
               
#ifdef USE_FBO
                  loc_gles_fbo_destroy(&fbo[1]);
               }

               loc_gles_fbo_destroy(&fbo[0]);
            }
#endif
         }
         
         //usleep(NUM_FRAMES * 16 * 1000);
         
         loc_gles_exit();
      }
   }

   return 0;
}
