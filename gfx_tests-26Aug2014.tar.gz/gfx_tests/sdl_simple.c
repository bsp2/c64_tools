#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <SDL/SDL.h>


static SDL_Surface *sdl_surf_screen;


int main(int argc, char**argv) {
   (void)argc;
   (void)argv;

#if 1
   setenv("SDL_VIDEODRIVER",     "omapdss", 1);  // select notaz' Pandora SDL driver
#endif

   setenv("SDL_OMAP_VSYNC",      "1", 1);

   if(SDL_Init(SDL_INIT_VIDEO) >= 0)
   {
      //sdl_surf_screen = SDL_SetVideoMode(800, 480, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
      sdl_surf_screen = SDL_SetVideoMode(800, 480, 32, SDL_HWSURFACE);
      //sdl_surf_screen = SDL_SetVideoMode(800, 480, 32, 0);
         
      if(NULL != sdl_surf_screen)
      {
         printf("SDL_SetVideoMode() ok. w=%d h=%d pixels=0x%p pitch=%u\n",
                sdl_surf_screen->w,
                sdl_surf_screen->h,
                sdl_surf_screen->pixels,
                sdl_surf_screen->pitch
                );
         
         printf("ok, calling SDL_Quit()\n");
         
         SDL_Quit();
      }
      else
      {
         printf("SDL_SetVideoMode() failed.\n");
      }
   }
   else
   {
      printf("SDL_Init() failed.\n");
   }

   return 0;
}
